<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="biodata_heading">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#biodata" aria-expanded="false" aria-controls="biodata">Biodata</a>
      </h4>
    </div>
    <div id="biodata" class="panel-collapse collapse" role="tabpanel" aria-labelledby="biodata_heading">
      <div class="panel-body">
        <?php 
			include_once('biodata.php');
			
		?>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Health Information
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
		 <?php 
			include_once('helth_info.php'); 
		 
		 ?>  
      </div>
    </div>
  </div>
  
   <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingacadamic">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#acadamic" aria-expanded="false" aria-controls="acadamic">
          Academic Record
        </a>
      </h4>
    </div>
    <div id="acadamic" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingacadamic">
      <div class="panel-body">
		 <?php 
			//include_once('acadamic.php'); 
		?>  
      </div>
    </div>
  </div>

</div>