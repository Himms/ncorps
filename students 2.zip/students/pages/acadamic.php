 <?php
	if($_SESSION['student_portal_login_id']){
		$userType= $_SESSION['student_user_type'];
	$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
	include_once("../include/connections.php");
	include_once("../php/get_user_profile.php");
	}
	
		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
 
	

 ?>
 
 
 <div class="col-md-6">

 <div class="form-group">
		<label for="email">Hostel</label>
			<input type="text" class="form-control" value="<?php echo $hostelname; ?>" id="program" placeholder="Hostel" readonly>
		</div>

   <div class="form-group">
		<label for="phonenumber">Hostel Room</label>
		<input type="text" class="form-control" value="<?php echo $bedspace; ?>" id="department" placeholder="Bedspace" readonly>
		</div>
		
		 <div class="form-group">
		<label for="email">Platoon Number</label>
		
			<input type="text" class="form-control" value="Platoon <?php echo $platoon; ?>" id="program" placeholder="Platoon Number" readonly>
		
		
		</div>


		<div class="form-group">
		<label for="email">SEAD</label>
			<input type="text" class="form-control" value="<?php echo $seadname; ?>" readonly>
		</div>

		<div class="form-group">
		<label for="email">Bank</label>
			<input type="text" class="form-control" value="<?php echo $bankname; ?>" readonly>
		</div>

  </div>
 
 