		<div class="list-group">
			<ul class="list-group">
				<li class="list-group-item list-group-iteam">
					<div class="row">
					
						<div class="col-md-4" style="padding-top:2px; padding-left:2px; padding-right:2px;">
							<label>Status</label>
							<select id="H_status" class="form-control">
								<option id=""><?php echo $H_status;?></option>
								<option id="">Normal</option>
								<option id="">Disabled</option>
							</select>
						</div>
						<div class="col-md-4" style="padding-top:2px; padding-left:2px; padding-right:2px;">
							<label>Disability</label>
							<select id="disability" class="form-control">
								<option id=""><?php echo $disability ?></option>
								<option id="">Blind</option>
								<option id="">Normal</option>
							</select>
						</div>
						<div class="col-md-4" style="padding-top:2px; padding-left:2px; padding-right:2px;">
							<label>Blood Group</label>
							<select id="blood_type" class="form-control">
								<option id=""><?php echo $blood_group ?></option>
								<option id="">A</option>
								<option id="">B</option>
								<option id="">AB</option>
								<option id="">O</option>
							</select>
						</div>
						<div class="col-md-12" style="padding-top:10px; padding-left:2px; padding-right:2px;">
							<label for="address">Medication</label><br/>
							<input value="<?php echo $medication; ?>" type="text" class="form-control" id="medication">
						</div>
						
					</div>
				</li>
			</ul>
		</div>