<?php
	session_start();
	
	if(!isset($_SESSION['student_portal_login_id'])){
	
		header("location:index.php");
	}
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
?>
<div class="col-md-12" style="padding-left:0px; padding-right:0px;" id="p">
		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>PAYMENTS</h4>
					</li>
				</ul>
				
		</div>
		<?php
		$sn=1;
			//get user payment
			include_once("../include/connections.php");
			$sql_get_payment=mysqli_query($con,"SELECT *FROM payments WHERE student_id='$student_portal_login_id'");
			if($sql_get_payment){
				$sql_get_payment_row=mysqli_num_rows($sql_get_payment);
				if($sql_get_payment_row > 0){
					while($get_payment=mysqli_fetch_array($sql_get_payment)){
						
						$payment_for=$get_payment['payment_for'];
						$amont_paid=$get_payment['amont_paid'];
						$transaction_id=$get_payment['transaction_id'];
						$payment_status=$get_payment['payment_status'];
						$payment_date=$get_payment['payment_date'];
						$date_generated=$get_payment['date_generated'];
						
						
				echo '
<div class="list-group">
  <a href="#" class="list-group-item">
    <table class="table">
		<tr>
			<th >SN</th>
			<th >Payment Type</th>
			<th >TID</th>
			<th >Date Generated</th>
			<th >Amount</th>
			<th >Status</th>
			<th >Payment Date</th>
			<th ></th>
		<tr>
		<tr>
			<td >'.$sn.'</td>
			<td > '.$payment_for.'</td>
			<td >'.$transaction_id.'</td>
			<td >'.$date_generated.'</td>
			<td >'.$amont_paid.'</td>
			<td >';
			
				if($payment_status ==1){
					echo '<h5 style="color:green">PAID<h5>';
					$PaymentDate=$PaymentDate;
				}else{
					echo '<h5 style="color:red">NOT PAID<h5>';
					$PaymentDate="Nil";
				}
			echo'</td>
			<td >'.$PaymentDate.'</td>
			<td ></td>
		<tr>
	</table>
  </a>
</div>
				';
				$sn=$sn + 1;		
					}
				}
			}
		
		?>
</div>