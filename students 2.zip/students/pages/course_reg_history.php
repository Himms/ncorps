<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Course Registration History</h4>
      </div>
      <div class="modal-body" id="view_courses" style="height:400px;overflow:auto">
 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<div class="col-md-12" id="view">

<table class="table table-bordered">
<thead>
<tr>
<td align="center">SESSION</td>
<td align="center">ACTION</td>
</tr>
</thead>
<tbody>
<?php
include_once("../include/connections.php");
$sql="SELECT * FROM sessions WHERE current_session<>'1'";
$query=mysqli_query($con,$sql);
if(mysqli_num_rows($query)>0)
{
while($row=mysqli_fetch_assoc($query)){
    echo 
    '<tr>
    <td align="center">'.$row['title'].'</td>
    <td align="center"><button class="btn btn-default" data-toggle="modal"  onclick="history('.$row['id'].')" >view</button></td>

    </tr>
    ';
}
}
else{
    echo '<tr><td colspan="1" align="center"><p style="color:red">no history </p><td></tr>';
}



?>

</tbody>
</table>

</div>
