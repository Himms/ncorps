<?php
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	include_once("../include/functions.php");

       
	
?>
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>Notifications</h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  
	<?php
	
	  echo '<div class="col-md-12" id="load_reprt">
                        <h3>General Notification</h3>';
                        $sqlGetNotification=mysqli_query($con,"SELECT *FROM general_notifications WHERE type='all' OR type='$email' ORDER BY id DESC") or die(mysqli_error($con));
                        if($sqlGetNotification){
                            $sqlGetNotification_row=mysqli_num_rows($sqlGetNotification);
                            if($sqlGetNotification_row > 0){
                                //already applied
                                while($r=mysqli_fetch_array($sqlGetNotification)){
                                $title=$r['title'];
                                $description=$r['description'];
                                $datetime=$r['datetime'];

                                $ago =get_time_ago( strtotime($datetime));

                                echo '
                                <div class="row">
  <div class="col-md-12">
    <a href="#" class="thumbnail">
     <p><b style="color:green;">'.$title.'</b></p>
     <p style="color:#000;">'.$description.'</p>
     <p>'.$ago.'</p>
    </a>
  </div>
</div>
                                ';
                                }
                            }else{
                                echo '
                                <div class="row">
  <div class="col-md-12">
    <a href="#" class="thumbnail">
     <p><b style="color:green;">Error</b></p>
     <p>No Notification at the moment</p>
    </a>
  </div>
</div>
                                ';
                            }
                        }
	?>
      
 </div>
   
   