<?php
//error_reporting(0);
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
  $student_id=$student_portal_login_id;
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	

  ?>
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>Election</h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
	<div class="col-md-12">
		<div class="col-md-3 thumbnail">
			<div class="list-group">
  <a href="#" class="list-group-item disabled">
    Offices
  </a>
 
  <?php
		//get all the offices
		$sql_get_office=mysqli_query($con,"SELECT *FROM offices WHERE status='1' ORDER BY sorting");
	if($sql_get_office){
		$sql_get_officeRow=mysqli_num_rows($sql_get_office);
		if($sql_get_officeRow > 0){
			while($get_rows=mysqli_fetch_assoc($sql_get_office)){
				$title=$get_rows['title'];
				$office_id=$get_rows['offices_id'];
				
				echo ' <a href="#" class="list-group-item" onclick="get_candidates('.$office_id.')">'.$title.'</a>';
			}
		}
	}
   ?>
</div>
		</div>
		<div class="col-md-9 thumbnail" id="load_candidate">
			<div class="alert alert-info" role="alert">Please click on any of the Office you want to vote for</div>
		</div>
	</div>
  
</div>
</div>
</div>