<div class="col-md-12" style="padding-left:0px; padding-right:0px;" id="p">
		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>APPLICATION FORM</h4>
					</li>
				</ul>
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

   <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingacadamic">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#acadamic" aria-expanded="false" aria-controls="acadamic">
          Application Form
        </a>
      </h4>
    </div>
    <div id="acadamic" class="panel-collapse" role="tabpanel" aria-labelledby="headingacadamic">
      <div class="panel-body">
		 <?php 
			include_once('uniapplicationform.php'); 
			//get applic
		?>  
      </div>
    </div>
  </div> 

</div>
</div>
</div>