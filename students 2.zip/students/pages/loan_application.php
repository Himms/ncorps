 <?php
	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	include_once("../php/get_student_profile.php");
	}
	
	//get total loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number'");
if($sql_student_loan_application){
	$loan_no=mysqli_num_rows($sql_student_loan_application);
	
	}
	
	
	//get total pending loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number' AND approval_status='0'");
if($sql_student_loan_application){
	$loan_pending=mysqli_num_rows($sql_student_loan_application);
	
	}
	
		//get total approved loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number' AND approval_status='1'");
if($sql_student_loan_application){
	$loan_approved=mysqli_num_rows($sql_student_loan_application);
	
	}
	
	//get total rejected loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number' AND approval_status='2'");
if($sql_student_loan_application){
	$loan_rejected=mysqli_num_rows($sql_student_loan_application);
	
	}
 
 ?>

<div class="col-md-12" style="padding-left:0px; padding-right:0px;" id="p">
		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>LOAN APPLICATION</h4>
					</li>
				</ul>
		

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="biodata_heading">
      <h4 class="panel-title">
			Loan Summary
      </h4>
	 
	  <button onclick="load_add_load()" style="float:right;background-color:green;" type="button" class="btn btn-default" aria-label="Left Align">
  <span class="glyphicon glyphicon glyphicon-plus" aria-hidden="true"></span>
</button>
    </div>
    <div id="biodata" class="panel-collapse" role="tabpanel" aria-labelledby="biodata_heading">
      <div class="panel-body">
			<div class="col-md-12">
				<ul class="nav nav-pills" role="tablist">
  <li role="presentation" class="active" ><a href="#">Total Loan <span class="badge"><?php echo $loan_no; ?></span></a></li>
  <li role="presentation" class="active" ><a style="background-color:green;" href="#">Approved <span class="badge"><?php echo $loan_approved; ?></span></a></li>
  <li role="presentation" class="active" ><a style="background-color:#CCC;" href="#">Pending <span class="badge"><?php echo $loan_pending; ?></span></a></li>
   <li role="presentation" class="active" ><a style="background-color:red;" href="#">Disapproved <span class="badge"><?php echo $loan_rejected; ?></span></a></li>
</ul>
			</div>
			
			<div class="col-md-12" id="loan_notification" style="padding:0px;margin:0px;">
			 <div class="panel-heading">My Loan History</div>
			  <div class="panel panel-default"> <table class="table">
 <tr>
		<th class="active">SN</th>
		<th class="active">Session</th>
		<th class="active">Loan Type</th>
		<th class="active">Amount Needed</th>
		<th class="active">Amount Approved</th>
		<th class="active">Date Applied</th>

		<th class="active"></th>
  
</tr>
				<?php
				
					//get all user loan from student_loan_application
					include_once("../include/connections.php");
$sn=1;
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number'");
if($sql_student_loan_application){
	$sql_student_loan_application_row=mysqli_num_rows($sql_student_loan_application);
	if($sql_student_loan_application_row > 0){
		while($data_row=mysqli_fetch_assoc($sql_student_loan_application)){
			$loan_id=$data_row['loan_id'];
			$loan_title=$data_row['loan_title'];
			$session=$data_row['session'];
			$amount_needed=$data_row['amount_needed'];
			$amount_given=$data_row['amount_given'];
			$date_applied=$data_row['date_applied'];
			$approval_status=$data_row['approval_status'];
			$date_approved=$data_row['date_approved'];

		if($approval_status==0){
			echo'<tr>
		<td class="active">'.$sn.'</td>
		<td class="active">'.$session.'</td>
		<td class="active">'.$loan_title.'</td>
		<td class="active">N'.$amount_needed.'</td>
		<td class="active">N'.$amount_given.'</td>
		<td class="active">'.$date_applied.'</td>

		<td class="active"><a href="#" onclick="delete_loan('.$loan_id.')"> <span class="glyphicon glyphicon glyphicon-trash" aria-hidden="true"></span></a></td>
  
</tr>';
		}elseif($approval_status==1){
			echo'<tr>
		<td class="success">'.$sn.'</td>
		<td class="success">'.$session.'</td>
		<td class="success">'.$loan_title.'</td>
		<td class="success">N'.$amount_needed.'</td>
		<td class="success">N'.$amount_given.'</td>
		<td class="success">'.$date_applied.'</td>

		<td class="success"><span class="label label-success">Approved</span></td>
  
</tr>';
		}else{
			echo'<tr>
		<td class="danger">'.$sn.'</td>
		<td class="danger">'.$session.'</td>
		<td class="danger">'.$loan_title.'</td>
		<td class="danger">N'.$amount_needed.'</td>
		<td class="danger">N'.$amount_given.'</td>
		<td class="danger">'.$date_applied.'</td>

		<td class="danger"><span class="label label-danger">Disapproved</span></td>
  
</tr>';
		}
 
  echo'

			';
			
			
			$sn=$sn+1;
			
		}
	echo '</table></div>';	
	}else{
		echo '
			<div class="well">
				<div class="alert alert-info" role="alert">You do not have any loan history, Click on Add button to Apply for new Loan</div>
			
			</div>
		';
	}
}
				
				
				?>
			</div>
      </div>
    </div>
  </div>
  
 
</div>

 

</div>


</div>

	
	