<?php
	session_start();
	if(isset($_SESSION['applicant_portal_login_id'])){
		$student_portal_login_id= $_SESSION['applicant_portal_login_id'];
	
		$student_id = $student_portal_login_id;
	}
?>
<div class="col-md-12">

		<div class="list-group panel-primary">
				<ul class="list-group">
					<li class="list-group-item panel-primary">
						<h4>Academic Records</h4>
					</li>
				</ul>
		</div>
		
				<div id="result_info" style='width:80%;margin:10px auto;'>
						<div class="well" style='padding:10px'> My O Level Result </div>
							<div class="col-md-12">
							<label for="subject">Exam Number </label><br>
								<input type="text" id="exam_number" class="form-control">
							</div>
								<div class="form-inline">
									  <div class="form-group">
										<label for="subject">Exam Type </label><br>
										<select class="form-control" id="exam_type">
												<option value=''></option>
												<option value='WASSCE'>WASSCE</option>
												<option value='NECO'>NECO</option>
												<option value='NABTEB'>NABTEB</option>
												<option value='Grade II Cert.'>Grade II Cert.</option>
										</select>
									  </div>
									  
										  <div class="form-group">
											<label for="subject">Exam Year </label><br>
										<select class="form-control" id="exam_year">
												<option value=''></option>
												<?php 
													$start_yr = 1950;
													$current_yr = date('Y');
													for($i = $start_yr;$i <= $current_yr;$i++){
														echo '<option value='.$i.'>'.$i.'</option>';
													}
												?>
										</select>
									  </div>
									  
									  	  <div class="form-group">
											<label for="exam_month">Exam Month </label><br>
										<select class="form-control" id="exam_month">
												<option value=''></option>
												<option value='Jan'>January</option>
												<option value='Feb'>Febrary</option>
												<option value='Mar'>March</option>
												<option value='Apr'>April</option>
												<option value='May'>May</option>
												<option value='Jun'>June</option>
												<option value='Jul'>July</option>
												<option value='Aug'>August</option>
												<option value='Sep'>September</option>
												<option value='Oct'>October</option>
												<option value='Nov'>November</option>
												<option value='Dec'>December</option>
												
										</select>
									  </div>
									  
									  	  <div class="form-group">
										<label for="subject">Subject </label><br>
										<select class="form-control" id="subject_id">
												<option value=''></option>
												<?php 
													include_once('../include/connections.php');
													$sql_query = mysqli_query($con,"SELECT * FROM subjects");
														while($sub_array = mysqli_fetch_array($sql_query)){
															$subject_id = $sub_array['subject_id'];
															$subject_title = $sub_array['title'];
															echo '<option value="'.$subject_id.'">'.$subject_title.'</option>';
															
														}
												
												?>
											
										</select>
									  </div>
									    	  <div class="form-group" style="margin:20px;">
										<label for="sub_grade">Grade Obtained </label><br>
										<select class="form-control" id="sub_grade">
												<option value=''></option>
												<option value='A1'>A1</option>
												<option value='B2'>B2</option>
												<option value='B3'>B3</option>
												<option value='C4'>C4</option>
												<option value='C5'>C5</option>
												<option value='C6'>C6</option>
												<option value='D7'>D7</option>
												<option value='E8'>E8</option>
												<option value='F9'>F9</option>
												
										</select>
									  </div>
									  
									   <div class="form-group" style="padding-top:20px">
											<a class="btn btn-default" href="#" onclick="addNewResult()">Add New</a>
											
									  </div>
										
									</div>
						
							<div id="result_uploaded_table_wrap">
								<?php include_once('../php/result_uploaded_table.php');?>
							</div>
						<div class="">
							<strong>Note : </strong> you can not combine more than two results. Click on add to Upload Information 
						</div>
						
						<?php
							include_once('../include/connections.php');
							include_once("../include/GetCurrentSession.php");
							$current_session=str_replace("/","_",$session_title);
							$sql="SELECT * FROM applicant_qualification_".$current_session." WHERE applicant_id='$student_id'";
							$sql_query = mysqli_query($con,$sql);
									while($sub_array = mysqli_fetch_array($sql_query)){
										$qualification = $sub_array['qualification'];
										$institution = $sub_array['institution'];
										$year_of_graduation = $sub_array['year_of_graduation'];
										$class_of_result = $sub_array['class_of_result'];
										$specify = $sub_array['specify'];
									}
						?>
						
						<div class="well" style='padding:10px'>Higher Qualification </div>
						<div class="col-md-12">
							<div class="col-md-6">
							<label for="subject">Qualification </label>
							<select class="form-control" id="qualification">
								<option><?php echo $qualification; ?></option>
								<option>PhD</option>
								<option>M.sc.</option>
								<option>B.sc.</option>
								<option>B.Tech.</option>
								<option>B.Eng.</option>
								<option>Hnd.</option>
								<option>Nd.</option>
								<option>Others</option>
							</select>
							</div>
							<div class="col-md-6">
								<input class="form-control" type="text" id="specify" placeholder="For Others, Specify"/>
							</select>
							</div>
						</div>
						<div class="col-md-12">
							<label for="subject">Class of qualification</label>
							<input class="form-control" type="text" id="class_off_qualification" placeholder="Class of qualification" value="<?php echo $class_of_result; ?>"/>
						</div>
						<div class="col-md-12">
							<div class="col-md-6">
							<label for="subject">Institution </label>
							<input class="form-control" type="text" id="institution" placeholder="Institution" value="<?php echo $institution; ?>"/>
							</div>
							<div class="col-md-6">
							<label for="subject">Year of graduation </label>
							<select class="form-control" id="yearOfGraduation">
								<option><?php echo $year_of_graduation; ?></option>
								<?php
									for($i=1980;$i<=2019;$i++){
										echo '<option>'.$i.'</option>';
									}
								
								?>
								
							</select>
							</div>
						</div>
						
						<div class="col-md-12">
						<div class="col-md-12" id="saveError" style="color:red;"></div>
						<button onclick="saveUpdateQualification(<?php echo $student_id; ?>)" class="btn btn-success" type="submit" id="btnupdateprofile">Save Changes</button>
							
						</div>
					</div>
		
</div>