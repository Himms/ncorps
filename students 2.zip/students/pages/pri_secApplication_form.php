 <?php
 session_start();
	if($_SESSION['student_portal_login_id']){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	include_once("../include/connections.php");
	
	$programme_title="";
	$department_title="";
	
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$sql = "SELECT *FROM user_login_info ulog INNER JOIN user_information uinfo ON ulog.user_info_id=uinfo.id WHERE uinfo.id='$student_portal_login_id'";
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 $usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 
			 $department_id=$get_Acc_detail['department_id'];
			 $programme_id=$get_Acc_detail['programme_id'];
			 
			 
			
		
		$sql_get_department_detail=mysqli_query($con,"SELECT *FROM students_departments WHERE id='$department_id'");
				if($sql_get_department_detail){
					$sql_get_department_detail_row=mysqli_num_rows($sql_get_department_detail);
					if($sql_get_department_detail_row > 0){
						$get_department=mysqli_fetch_array($sql_get_department_detail);
						$department_title=$get_department['title'];
					}
				}
		
		
			 
		}
	}
	
 
 ?>
 <div class="col-md-12">
 <div class="form-group">
		<label for="email">Class</label>
		<select id="program" class="form-control" onchange="get_course_of_study_details()">
			<option>---- Select Class Applying for-----</option>
		<?php
			//get program
			$sgl_get_programme=mysqli_query($con,"SELECT *FROM programmes WHERE project_id='$project_id'");
			if($sgl_get_programme){
				$sgl_get_programme_row=mysqli_num_rows($sgl_get_programme);
				if($sgl_get_programme_row > 0){
					while($get_programme=mysqli_fetch_array($sgl_get_programme)){
						$course_id=$get_programme['id'];
						$course_title=$get_programme['title'];
						
						if($programme_id==$course_id){
							echo '<option selected value='.$course_id.'>'.$course_title.'</option>';
						}else{
							echo '<option value='.$course_id.'>'.$course_title.'</option>';
						}
						
					}
				}
			}
			
		?>
		</select>
		</div>
	 <div class="form-group">
		<label for="level">Class</label>
			<input type="text" class="form-control" value="Applicant" id="level" placeholder="Level" readonly >
		</div>	 
  </div>
   <div class="col-md-12">
      <div class="form-group">
		<label for="phonenumber">Section</label>
		<input type="text" class="form-control"  id="department" placeholder="Department" value="<?php echo $department_title; ?>" readonly>
	</div>
		
   <div class="form-group">
		<label for="phonenumber">Registration Number</label>
		<input type="text" class="form-control"  id="reg_no" placeholder="Registration Number" readonly >
	</div>	
  </div>
  <div class="col-md-12"><div id="courseofstudiesdetails"></div>
  <p style="color:red;">Note: Application number will be generated when you submit your Application and your Application form fee is confirmed<p>
  <div><button onclick="save_application_form()" class="btn btn-success" type="submit" >Submit Application</button></div>