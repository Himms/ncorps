<div class="col-md-12">

		<div class="list-group panel-primary">
				<ul class="list-group">
					<li class="list-group-item panel-primary">
						<h4>OTHER INFORMATION</h4>
					</li>
				</ul>
		</div>
		<div id="result_info" style='width:100%;margin:10px auto;'>
						<div class="well" style='padding:10px;background:red'> Make sure you upload all your Certificates </div>
						
								<div class="form-inline text-left">

<a style="float:right;" href="docware.php" class="btn btn-primary">Add</a>

									</div>
						
							<div id="document_uploaded_table" style="margin:30px 0px;height:400px;overflow:auto">
										<?php include_once('../php/document_uploaded_table.php');?>
							</div>
						
					</div>
</div>