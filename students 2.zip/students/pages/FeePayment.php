<?php
session_start();
		if($_SESSION['student_portal_login_id']){
			$userType= $_SESSION['student_user_type'];
			$project_id= $_SESSION['project_id'];
			$email= $_SESSION['email'];
			$student_portal_login_id= $_SESSION['student_portal_login_id'];
	include_once("../include/connections.php");
	include_once("../php/get_user_profile.php");
	}
	
		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
 
	$ref=md5($number);
	
	
?>
<div class="col-md-12">

		<div class="list-group panel-primary">
				<ul class="list-group">
					<li class="list-group-item panel-primary">
						<h4>Fee Payments</h4>
					</li>
				</ul>
				
		</div>
			
		<?php
		
			//get all the payment
		$sqlPayment="SELECT *FROM payments_2019_2020 WHERE number='$number' AND payment_type='Accommodation Fee'";
		$sqlPaymentRun=mysqli_query($con,$sqlPayment) or die(mysqli_error($con));
		$sqlPaymentRunRow=mysqli_num_rows($sqlPaymentRun);
		if($sqlPaymentRunRow > 0){
			while($r=mysqli_fetch_array($sqlPaymentRun)){
				$payment_type=$r['payment_type'];
				$payment_info=$r['id'];
				$payment_id=$r['id'];
				$amount=$r['amount'];
				$status=$r['status'];
				$payment_type=$r['payment_type'];
				
				if($status=="0"){
					$c="red";
					$s="Pending";
				}else{
					$c="green";
					$s="Paid";
				}
				echo '<div class="col-md-4" >
					<div class="list-group">
  <a href="#" class="list-group-item " style="background-color:'.$c.';">
    '.$payment_type.'
  </a>
  <a href="#" class="list-group-item">Amount Due: N'.$amount.'</a>
  <a href="#" class="list-group-item">Payment Status :'.$s.'</a>';
  
  $total=$amount + 0;
  if($status=="0"){
	   echo '<a href="#" onClick="payWithRave('.$total.','.$student_portal_login_id.','.$payment_info.')" class="list-group-item btn btn-success"><center><b>Pay Now</b><center></a>';
 
  }
  
 
echo'</div>
				</div>';
			}
		}else{
			
			echo'<div class="row">
			<div class="col-md-12">
			  <a href="#" class="thumbnail">
			   <p><b style="color:green;">Error</b></p>
			   <p><b style="color:red">You do not have any pending Payment to Make</b></p>
			  </a>
			</div>
		  </div>';
		}
		
		
		?>
			
</div>