<?php
session_start();
	include_once("../include/connections.php");
	$student_id=$_SESSION['student_portal_login_id'];
	include_once("../php/get_student_profile.php");
	//include_once("../include/get_project_details_with_id.php");
	include_once("../include/connections.php");
	$sqlget=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sqlget){
			$sql_get_row=mysqli_num_rows($sqlget);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sqlget)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					
					
					
				}
			}
		}
	if(empty($img)){
			
			$pic='0.png';
		}else{
			
			$pic=$img;
			
		}
?>
<table width="100%" border="1px">
	<tr>
		<td valign="top" width="75%">
			<center>
		<img src="images/<?php echo $project_sm_logo; ?>" height="90px" width="90px"><br/><b>
		 <?php echo $projects_title ?>
		<br/>(Office of the Registrar)<br/>
		
		2017/2018 Academic Session<br/>
		STUDENT BIODATA FORM.
		
		</b>
		<hr/>
		</center>
		</td >
		<td width="15%">
			<img src="uploads/<?php echo $pic; ?>" class="img-circle" width="150px" height="200px" />
		</td>
	</tr>
	</table>
		
	<?php	
		
		echo'<p>
				<blockquote><b>Bio. Data</b></blockquote>
			</p>
	<table width="100%">
		<tr>
			<td width="40%">
				<div class="col-md-12" style="border-color:green; border:double;">Number: '.$number.'</div>
			</td>
			<td width="40%">
				<div class="col-md-12" style="border-color:green; border:double;">Name: '.$first_name.'</div>
			</td>
			<td width="20%">
				<div class="col-md-12" style="border-color:green; border:double;">G: '.$gender.'</div>
			</td>
		</tr>
	</table>
	<table width="100%">
		<tr>
			<td width="40%">
				<div class="col-md-12" style="border-color:green; border:double;">DOB: '.$std_date.'</div>
			</td>
			<td width="40%">
				<div class="col-md-12" style="border-color:green; border:double;">Marital Status: '.$maritalstatus.'</div>
			</td>
	
		</tr>
	</table>
	<table width="100%">
		<tr>
			<td width="40%">
				<div class="col-md-12" style="border-color:green; border:double;">Nationality: Nigeria</div>
			</td>
			<td width="40%">
				<div class="col-md-12" style="border-color:green; border:double;">State: '.$state.'</div>
			</td>
			<td width="20%">
				<div class="col-md-12" style="border-color:green; border:double;">L.G.A: '.$lga.'</div>
			</td>
		</tr>
	</table>
	
	
<hr/>
				
	<p><blockquote><b>Contact Information</b></blockquote></p>
	
	<table width="100%">
		<tr>
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Telphone: '.$phone_no.'</div>
			</td>
		</tr>
		<tr>
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Address: '.$address.'</div>
			</td>
		</tr>
		<tr>
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Email: '.$email.'</div>
			</td>
		</tr>
	</table>
	
	<p><blockquote><b>Health Information</b></blockquote></p>
	
	<table width="100%">
		<tr>
			<td width="25%">
				<div class="col-md-12" style="border-color:green; border:double;">Status: '.$H_status.'</div>
			</td>
			<td width="25%">
				<div class="col-md-12" style="border-color:green; border:double;">Disability: '.$disability.'</div>
			</td>
			<td width="50%">
				<div class="col-md-12" style="border-color:green; border:double;">Blood Group: '.$blood_group.'</div>
			</td>
			
		</tr>
		
	</table>
	<table width="100%">
		<tr>
		
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Medication: '.$medication.'</div>
			</td>
		</tr>
		
	</table>
	<p><blockquote><b>Academic Record</b></blockquote></p>
	
	<table width="100%">
		<tr>
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Department: '.$department.'</div>
			</td>
		</tr>
		<tr>
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Course: '.$course.'</div>
			</td>
		</tr>
		<tr>
			<td width="100%">
				<div class="col-md-12" style="border-color:green; border:double;">Level: '.$level.'</div>
			</td>
		</tr>
	</table>';
	
	
	?>
	
	<a class="btn btn-default pull-left modal-content" href="student_biodata_form.php"><i class="glyphicon glyphicon-print"></i>Print Biodata</a>