<?php
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND status='1'";
	

		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			 $level=$get_Acc_detail['level'];
			 
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $level=$get_Acc_detail['level'];
		
			 $full_name=$surname.' '.$first_name.' '.$other_names;
			 $mat_year=substr($number,0,3);
			 
			 if($image=='0.jpg'){
				 $pic='0.jpg';
			 }else{
				 $pic=$student_portal_login_id.'.jpg';
			 }
			
		}

        $sqlChk=mysqli_query($con,"SELECT *FROM sewis_programme WHERE student_email='$email' AND status='1'");
        if($sqlChk){
            $sqlChk_row=mysqli_num_rows($sqlChk);
            if($sqlChk_row > 0){
                //already applied
                $r=mysqli_fetch_array($sqlChk);
                $status=$r['status'];
                $siwes_org_id=$r['siwes_org_id'];
            }
        }
	
	
?>
<div class="panel panel-default">
  <div class="panel-heading">Change of SIWES Placement Application</div>
  <div class="panel-body">
    <div class="col-md-12">
    <div class="form-group">
    <label for="exampleInputEmail1">Company/Organization</label>
    <select class="form-control" id="organization">
        <option></option>
<?php
        $sql=mysqli_query($con,"SELECT *FROM sewis_organizations");
   	if($sql){
   		$sql_row=mysqli_num_rows($sql);
   		if($sql_row > 0){
   			//get the student detals
   			while($row=mysqli_fetch_array($sql)){
               $organizasion_name=$row['organizasion_name'];
               $organizasion_id=$row['id'];
                if($siwes_org_id==$organizasion_id){
                    echo '<option selected value="'. $organizasion_id.'">'.$organizasion_name.'</option>';
                }else{
                    echo '<option value="'. $organizasion_id.'">'.$organizasion_name.'</option>';
                }
              
        }
    }
    }
    ?>
    </select>
  </div>
  
        <div class="col-md-12">
        <div class="col-md-12" id="errorSubmit"></div>
        <button type="submit" class="btn btn-success" onclick="changeAppication()">Submit Application</button>
        </div>
    </div>
  </div>
</div>