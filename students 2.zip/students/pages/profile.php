<?php

	session_start();
	include_once("../include/connections.php");
	//get user_acc_details
	
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	//$userType= $_SESSION['student_user_type'];
	//$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
	
	
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	include_once("../include/functions.php");
	
	
	
$sql = "SELECT *FROM student_".$current_session." WHERE email='$email' AND user_status='1'";
	
		
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $id=$get_Acc_detail['id'];
			 
			 if($image==''){
				 $pic='0.jpg';
			 }else{
				 $pic=$image;
			 }
			
		}
?>
<div class="col-md-12" style="padding-left:0px; padding-right:0px;" id="p">
		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>PROFILE</h4>
					</li>
				</ul>
	
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="biodata_heading">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#biodata" aria-expanded="false" aria-controls="biodata">Biodata</a>
      </h4>
    </div>
    <div id="biodata" class="panel-collapse collapse" role="tabpanel" aria-labelledby="biodata_heading">
      <div class="panel-body">
        <?php 
			include_once('biodata.php');
			
		?>
      </div>
    </div>
  </div>

  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Health Information
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
		 <?php 
			include_once('helth_info.php'); 
		 
		 ?>  
      </div>
    </div>
  </div>


  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThreee">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThreee" aria-expanded="false" aria-controls="collapseThree">
          Educational Background
        </a>
      </h4>
    </div>
    <div id="collapseThreee" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThreee">
      <div class="panel-body">
		 <?php 
			include_once('educational_background.php'); 
		 
		 ?>  
      </div>
    </div>
  </div>
  
   <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingacadamic">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#acadamic" aria-expanded="false" aria-controls="acadamic">
          Camp Information
        </a>
      </h4>
    </div>
    <div id="acadamic" class="panel-collapse " role="tabpanel" aria-labelledby="headingacadamic">
      <div class="panel-body">
		
		 <?php 
			include_once('acadamic.php'); 
		?>  
      </div>
    </div>
  </div> 

</div>



 

</div>


</div>
  <div class="col-md-12" style="padding-left:0px; padding-right:0px;">
	<div id="profile_error"></div>
		<button onclick="update_student_profile(<?php echo $userType; ?>)" class="btn btn-success" type="submit" id="btnupdateprofile">Save Changes</button>
		
	</div>

	