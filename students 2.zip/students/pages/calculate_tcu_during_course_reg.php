<?php
	//calculate the tcu
					$get_all_course_id = mysqli_query($con,"SELECT distinct course_id FROM students_courses WHERE  student_id='$student_id' AND session = '$session_id' AND semester='$semester' and status='1'") or die(mysqli_error($con));
					if(mysqli_num_rows($get_all_course_id)> 0){
						while($course_rows = mysqli_fetch_array($get_all_course_id)){
							
							$course_c_id = $course_rows['course_id'];
								$get_course_details = mysqli_query($con,"SELECT * FROM courses WHERE id = '$course_c_id' ");
								if(mysqli_num_rows($get_course_details)> 0){
									while($course_details_rows = mysqli_fetch_array($get_course_details)){
										
										$credit_unit = $course_details_rows['unit'];
										$total_cu = $total_cu + $credit_unit;
										
									}
								}
							
						}
					}
					$check_result_summary = mysqli_query($con,"SELECT * FROM result_summary WHERE student_id='$student_id'  AND session = '$session_id' AND semester='$semester' ") or die(mysqli_error($con));
								if($check_result_summary){
									if(mysqli_num_rows($check_result_summary)> 0){
									
											$result_summary_insert_q1 = mysqli_query($con,"update result_summary set TCU = '$total_cu' WHERE student_id='$student_id'  AND session = '$session_id' AND semester='$semester'") or die(mysqli_error($con));
											if(!$result_summary_insert_q1){
												echo '#error : 10';
											}
									}else{
											$result_summary_insert_q = mysqli_query($con,"insert into result_summary (student_id,TCU,TGP,GPA,CGPA,session,semester) values('$student_id','$total_cu','','','','$session_id','$semester')") or die(mysqli_error($con));
											if(!$result_summary_insert_q){
												echo '#error : 20';
											}
									}
								}else{
									echo '#error : 30';
								}
								
	?>