<?php
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND status='1'";
	

		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			 $level=$get_Acc_detail['level'];
			 
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $level=$get_Acc_detail['level'];
		
			 $full_name=$surname.' '.$first_name.' '.$other_names;
			 $mat_year=substr($number,0,3);
			 
			 if($image=='0.jpg'){
				 $pic='0.jpg';
			 }else{
				 $pic=$student_portal_login_id.'.jpg';
			 }
			
		}

        function get_time_ago( $time )
        {
            $time_difference = time() - $time;
        
            if( $time_difference < 1 ) { return 'less than 1 second ago'; }
            $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                        30 * 24 * 60 * 60       =>  'month',
                        24 * 60 * 60            =>  'day',
                        60 * 60                 =>  'hour',
                        60                      =>  'minute',
                        1                       =>  'second'
            );
        
            foreach( $condition as $secs => $str )
            {
                $d = $time_difference / $secs;
        
                if( $d >= 1 )
                {
                    $t = round( $d );
                    return $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
                }
            }
        }
	
?>
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>SIWES PROGRAMME</h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  
	<?php
	
		//get the current session
		$get_session=mysqli_query($con,"SELECT *FROM sessions WHERE current_session='1'");
		if($get_session){
			$get_session_row=mysqli_num_rows($get_session);
			if($get_session_row > 0){
				$get_row=mysqli_fetch_array($get_session);
				$session_id=$get_row['id'];
				$session_title=$get_row['title'];

	 
			}
		}
        
        //chk if student has applied for siwes programme or not
        $sqlChk=mysqli_query($con,"SELECT *FROM sewis_programme WHERE student_email='$email'");
        if($sqlChk){
            $sqlChk_row=mysqli_num_rows($sqlChk);
            if($sqlChk_row > 0){
                //already applied
                $r=mysqli_fetch_array($sqlChk);
                $status=$r['status'];
                if($status=="1"){

                    echo '<div class="col-md-12">
                    
                    <div class="btn-group">
                    <a href="siwes_form.php" target="_blank" type="button" class="btn btn-primary">Print Form</a>
                    <button type="button" class="btn btn-info" onclick="changeofsiwesplacement()">Apply for Change of SIWES Placement</button>
                  </div>
                    </div>';
                    echo '<div class="col-md-12" id="load_reprt">
                        <h3>General Notification</h3>';
                        $sqlGetNotification=mysqli_query($con,"SELECT *FROM siwes_notifications WHERE type='all' OR type='$email' ORDER BY id DESC");
                        if($sqlGetNotification){
                            $sqlGetNotification_row=mysqli_num_rows($sqlGetNotification);
                            if($sqlGetNotification_row > 0){
                                //already applied
                                while($r=mysqli_fetch_array($sqlGetNotification)){
                                $title=$r['title'];
                                $description=$r['description'];
                                $datetime=$r['datetime'];

                                $ago =get_time_ago( strtotime($datetime));

                                echo '
                                <div class="row">
  <div class="col-md-12">
    <a href="#" class="thumbnail">
     <p><b style="color:green;">'.$title.'</b></p>
     <p>'.$description.'</p>
     <p>'.$ago.'</p>
    </a>
  </div>
</div>
                                ';
                                }
                            }
                        }
                   echo'</div>';
                }else{
                    echo '<b class="alert alert-info" role="alert">We are reviewing your Application, We will notify you as soon as posible</b>';
                }
            }else{
                //not applied yet
                echo '
                <div class="alert alert-info" role="alert">
                    <b style="color:red;">Please read the instructions and tearms and condition befor you proceed.</b>
                    <p><a href="#">Read more</a></p>
                </div>
<div class="panel panel-default">
  <div class="panel-heading">Application Form</div>
  <div class="panel-body">
    <div class="col-md-12">
    <div class="form-group">
    <label for="exampleInputEmail1">Company/Organization</label>
    <select class="form-control" id="organization">
        <option></option>';

        $sql=mysqli_query($con,"SELECT *FROM sewis_organizations");
   	if($sql){
   		$sql_row=mysqli_num_rows($sql);
   		if($sql_row > 0){
   			//get the student detals
   			while($row=mysqli_fetch_array($sql)){
               $organizasion_name=$row['organizasion_name'];
               $organizasion_id=$row['id'];
            
               echo '<option value="'. $organizasion_id.'">'.$organizasion_name.'</option>';
        }
    }
    }
    echo'</select>
  </div>
  
        <div class="col-md-12">
            <div class="col-md-6">
                
            <div class="form-group">
                <label for="exampleInputPassword1">Start Date</label>
                <input type="date" class="form-control" id="startDate">
            </div>

            </div>

      <div class="col-md-6">
                
        <div class="form-group">
        <label for="exampleInputPassword1">End Date</label>
        <input type="date" class="form-control" id="endDate">
      </div>


      </div>
            <div class="col-md-12">
            <div class="form-group">
            <label for="exampleInputPassword1">Description of what you will be learning</label>
                <textarea id="description" class="form-control"></textarea>
            </div>
            </div>
        </div>
 
        <div class="col-md-12">
        <div class="col-md-12" id="errorSubmit"></div>
        <button type="submit" class="btn btn-success" onclick="submitAppication()">Submit Application</button>
        </div>
    </div>
  </div>
</div>


                ';
            }
        }
?>
</div>

<div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      ...
    </div>
  </div>
</div>
   
   