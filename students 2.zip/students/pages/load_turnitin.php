<?php
error_reporting(0);
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
  $student_id=$student_portal_login_id;
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
  $sql = "SELECT *FROM student_".$current_session." WHERE email='$email'";
		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $phone_no=$get_Acc_detail['phone_no'];
			
			 $number=$get_Acc_detail['number'];
       $email=$get_Acc_detail['email'];
       $TID=$student_portal_login_id.rand(10,99);
       $first_name=$get_Acc_detail['first_name'];
        $other_names=$get_Acc_detail['other_names'];
      $surname=$get_Acc_detail['surname'];
       $number=$get_Acc_detail['number'];
                                        
       $fullname=$first_name .' '.$other_names.' '.$surname;
    }

     //get project details
     $sql_get=mysqli_query($con,"SELECT *FROM student_project WHERE student_id='$student_portal_login_id'");
     if($sql_get){
         $sql_getRow=mysqli_num_rows($sql_get);
         if($sql_getRow > 0){
             $data=mysqli_fetch_array($sql_get);
             $topic=$data['topic'];
             $file=$data['file'];
 
             $similarityIndex=$data['similarityIndex'];
             $internetSources=$data['internetSources'];
             $publications=$data['publications'];
             $studentPapers=$data['studentPapers'];
             $sup_status=$data['sup_status'];
             $abstract=$data['abstract'];
             
             $turnitin_status=$data['turnitin_status'];
             
         }
     }

     //get student supp
     $sqlget=mysqli_query($con,"SELECT *FROM student_supervisor WHERE student_id='$student_portal_login_id'");
     if($sqlget){
         $sqlgetRow=mysqli_num_rows($sqlget);
         if($sqlgetRow > 0){
             $dataa=mysqli_fetch_array($sqlget);
             $staff_IDD=$dataa['staff_id'];
             
             //get the detail of the staff
             $sqlStaff=mysqli_query($con,"SELECT *FROM staff_biodata WHERE id='$staff_IDD'");
             if($sqlStaff){
                 $sqlStaffRow=mysqli_num_rows($sqlStaff);
                 if($sqlStaffRow > 0){
                     $dataa=mysqli_fetch_array($sqlStaff);
                     $staff_fn =$dataa['first_name'] .' '.$dataa['other_names'].' '.$dataa['other_names'];
                     $fno=$dataa['number'];
                     $staffe=$dataa['email'];
                     $staffp=$dataa['phone_number'];
                   }
             }
         }
     }
  ?>
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>Turnitin</h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
    <?php 
        //chk if the student has made payment or not, 
        $sql_getSup=mysqli_query($con,"SELECT *FROM turnitin_payments WHERE student_id='$student_portal_login_id'");
			
        if($sql_getSup){
            $sql_getSup_row=mysqli_num_rows($sql_getSup);
            if($sql_getSup_row > 0){

              echo'<div class="col-md-12">
                  <div class="col-md-12">
                  <a class="btn btn-success" role="button" data-toggle="collapse" href="#supervisor" aria-expanded="false" aria-controls="collapseExample">
                    My Supervisor
                </a>
                
                <div class="collapse" id="supervisor">
                  <div class="well">';
                      if($sqlgetRow > 0){
                        echo'<ul class="list-group">
  <li class="list-group-item">'.$staff_fn.'</li>
  <li class="list-group-item">'.$staffe.'</li>
  
</ul>';

                      }else{
                          echo '<div class="alert alert-danger" role="alert">Suppervisor has not been assigned yet</div>';
                      }
                  echo'</div>
                </div>
                  <form action="desktop.php" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                  <input type="text" class="form-control" placeholder="Project Topic" name="project_topic" id="project_topic" value="'.$topic.'">
                  <textarea class="form-control" rows="3" placeholder="Enter Project Abstract" id="abstract" name="abstract">'.$abstract.'</textarea>
                  
                  <label for="fileToUpload">Upload Project file</label>
                    <input type="file" id="fileToUpload" name="fileToUpload">
                  </div>
                  <button name="submit" type="submit" class="btn btn-default">Submit</button>
                </form>
                  </div>

                  <div class="col-md-12">
                      <table class="table" style="background-color:green;color:#fff;">
                          <tr>
                              <td>Similarity Index </td>
                              <td>Internet Sources </td>
                              <td>Publications</td>
                              <td>Student Papers</td>
                          </tr>
                          <tr>
                          <td>'.$similarityIndex.'</td>
                          <td>'.$internetSources.'</td>
                          <td>'.$publications.'</td>
                          <td>'.$studentPapers.'</td>
                      </tr>
                      </table>
                  </div>
              </div>';
                
                
                    if($turnitin_status=="2"){
                         echo '<div class="padding-left:10px;margin-top:3px;margin-buttom:5px;">
            <a href="print_turnitin_certificate.php" class="btn btn-info"target="_blank">Print Turnitin Certificate</a>
                </div>';
                    }
                
               

           echo' <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title">My Project</h3>
              </div>
              <div class="panel-body">
                  <div class="col-md-12">
                     <div class="col-md-12">';
                    
                  if($file !=""){
                      echo '<iframe src="http://turnitin.ibbuapps.com/uploads/'.$file.'" style="width:100%; height:400px;"/>';
                  }else{
                      echo '<div class="alert alert-danger" role="alert">No file Uploaded</div>';

                  }
                     echo'</div>
                    
                  </div>
              </div>
            </div>

            
                ';
             
            }else{
              $total="10";
              //make payment
              echo'<div >
              <div class="panel panel-default">
              <div class="panel-heading">
                <h3 class="panel-title">Turnitin Payment</h3>
              </div>
              <div class="panel-body">
                <div class="col-md-4">
                <div class="list-group">
                <a href="#" class="list-group-item active">
                  <h4 class="list-group-item-heading">Payment Details</h4><hr/>
                    <p class="list-group-item-text">TID :<br/>'.$TID.'</p>
                    <p class="list-group-item-text">Phone :<br/>'.$phone_no.'</p>
                    <p class="list-group-item-text">Email :<br/>'.$email.'</p>
                    <p class="list-group-item-text">Amount :<br/>'.$total.'</p>

                    <br/><hr/>
                    <p class="list-group-item-text"><div class="btn-group btn-group-lg" role="group" aria-label="" onclick="payWithRavee('.$total.','.$TID.')">Pay Now</div></p>
                </a>
              </div>
                </div>
              </div>
            </div>
              </div>';
            }
        }

    ?>
</div>
</div>
</div>