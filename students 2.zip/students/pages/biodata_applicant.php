 <?php
	session_start();
	if($_SESSION['applicant_portal_login_id']){
		$student_portal_login_id= $_SESSION['applicant_portal_login_id'];
	include_once("../include/connections.php");
	include_once("../php/get_applicant_profile.php");
	}
	
	
 
 ?>
 
  
 <div class="list-group">
				<ul class="list-group">
				<li class="list-group-item list-group-iteam">
				<div class="row">
				
  <div class="col-md-4">
         <div class="form-group">
		<label for="surname">Name </label>
		<input value="<?php echo $first_name;?>" type="text" class="form-control" id="first_name" readonly>
		</div>
  </div>
  <div class="col-md-4">
        <div class="form-group">
		<label for="First name">Othername</label>
		<input value="<?php echo $other_names;?>" type="text" class="form-control" id="other_name" readonly>
		</div>
  </div>
   <div class="col-md-4">
  <div class="form-group">	
  <label for="middlename">Marital status</label>
			<select id="maritalstatus" value="" class="form-control">
				<?php
					if($maritalstatus =="Married"){
					echo '
						<option ></option>
				<option selected id="married">Married</option>
				<option id="single">Single</option>
						';
					}elseif($maritalstatus =="Single"){
					echo '
						<option ></option>
				<option id="married">Married</option>
				<option selected id="single">Single</option>
						';
					}else{
						echo '
						<option ></option>
				<option id="married">Married</option>
				<option id="single">Single</option>
						';
					}
				?>
				
				</select>
			</div>
			</div>
  
   <div class="col-md-4">
		<div class="form-group">	
			<label for="gender">Gender</label>
			<select id="gender" class="form-control">
				<?php
					if($gender =="Male"){
					echo '
						<option ></option>
				<option selected>Male</option>
				<option>Female</option>
						';
				}elseif($gender =="Female"){
					echo '
				<option ></option>
				<option>Male</option>
				<option selected>Female</option>
						';
					}else{
					echo '
				<option ></option>
				<option>Male</option>
				<option>Female</option>
						';
					}
				?>
				
				</select>
		</div>
	</div>
  
   <div class="col-md-12">
   <hr/>  Date of Birth
   </div>
   <div class="col-md-12">
		<div class="container">
    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
				
				<input value="<?php echo $std_date;?>" type="date" class="form-control" id="dob">
            </div>
        </div>
		</div>
    </div>
		
		
		
		
	<div class="col-md-12"><hr/></div>
	
	
   <div class="col-md-6">
   <div class="form-group">
		<label for="phonenumber">Phone number</label>
		<input type="text" class="form-control" value="<?php echo $phone_no;?>" id="phone_no" placeholder="phone no">
		</div>
		
		 <div class="form-group">
		<label for="email">Email</label>
		<input type="text" class="form-control" value="<?php echo $email;?>" id="email" placeholder="email">
		</div>
  </div>
  
   <div class="col-md-12">
		<div class="col-md-6">
			<div class="form-group">
		<label for="state">State</label>
			<select onchange="load_lga()" id="state" class="form-control">
					<option><?php echo $state; ?></option>
					
																	<?php
	include_once("../include/connections.php");
$con = new mysqli($servername, $username, $password, $db);
	$chk_state=mysqli_query($con,"SELECT * FROM state");
if($chk_state){
	$chk_state_row=mysqli_num_rows($chk_state);
	if($chk_state_row > 0){
		while($data_row=mysqli_fetch_assoc($chk_state)){
			$title=$data_row['title'];
			
			echo'<option>'.$title.'</option>';
		}
		
	}
}
?>		
																		</select>
		</div>
		</div>
		<div class="col-md-6">
			 <div class="form-group">
		<label for="address">LGA</label>
			<select id="lga" class="form-control">
				<option><?php echo $lga; ?></option>															
			</select>
			</div>
		</div>
  </div>
  
   <div class="col-md-12">
   <div class="form-group">
		<label for="address">Address</label>
		<textarea class="form-control" id="address" width="80%"><?php echo $address; ?></textarea>
		</div>
  </div>
  
  <div class="col-md-12">
   <div class="form-group">
		<label for="address">Permanat Address</label>
		<textarea class="form-control" id="permenat_address" width="80%"><?php echo $permenat_address; ?></textarea>
		</div>
  </div>
	
			</div>
			
			 <div class="col-md-12">
   <div class="form-group">
		<label for="phonenumber">Name of Guardian</label>
		<input type="text" class="form-control" value="<?php echo $sponsorship_name;?>" id="name_of_guardian" placeholder="Name of Guardian">
		</div>
		
		 <div class="form-group">
		<label for="email">Phone Number of Guardian</label>
		<input type="text" class="form-control" value="<?php echo $sponsorship_number;?>" id="no_guardian" placeholder="Phone Number of Guardian">
		</div>
  </div>
  <div>
   <div class="col-md-12">
   <div class="form-group">
		<label for="address">Address of Guardian</label>
		<textarea class="form-control" id="address_gaurdian" width="80%"><?php echo $sponsorship_address; ?></textarea>
   </div>
  </div>
  

   	<div class="col-md-12">
   		<div class="form-group">
		<label for="address">Next of Kin</label>
		<input value="<?php echo $kin_name;?>" type="text" class="form-control" id="kin_name">
   </div>
   
   <div class="col-md-12">
   		<div class="form-group">
		<label for="address">Next of Kin Relationship</label>
		<input value="<?php echo $kin_relationship;?>" type="text" class="form-control" id="kin_relationship">
   </div>
  
   <div class="col-md-12">
   		<div class="form-group">
		<label for="address">Next of Kin Phone Number</label>
		<input value="<?php echo $kin_phone_number;?>" type="text" class="form-control" id="kin_phone_number">
   </div>
   </div>	
   	
   <div class="col-md-12">
   <div class="form-group">
		<label for="address">Next of Kin Address</label>
		<textarea class="form-control" id="kin_address" width="80%"><?php echo $kin_address; ?></textarea>
   </div>
  </div>

  </li>
  </ul>
</div>
 

  
 
 
  



			
			