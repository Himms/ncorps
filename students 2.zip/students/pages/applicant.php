 <?php
	if($_SESSION['student_portal_login_id']){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	include_once("../include/connections.php");
	include_once("../php/get_student_profile.php");
	}
	
 
 ?>
 <div class="col-md-6">
   <div class="form-group">
		<label for="phonenumber">Department</label>
		<input type="text" class="form-control" value="<?php echo $department;?>" id="department" placeholder="Department" readonly>
		</div>
		
		 <div class="form-group">
		<label for="email">Course of Study</label>
		<?php
		if($course !=""){
			echo '<input type="text" class="form-control" value="'.$course.'" id="program" placeholder="Programm" readonly>';
		}else{
			echo'<select class="form-control" id="program">
		<option><option>
			<option>Diploma in Mass Communication</option><option>Professional Certificate in Mass Communication</option><option>Diploma in Public Administration</option><option>Diploma in Sharia and Civil Law</option><option>Advanced Diploma in Law</option><option>Certificate in Law</option><option>Diploma in Arabic/Hausa Language and Education</option><option>Diploma in Arabic/Islamic Studies and Education</option><option>Diploma in Hausa Language/Islamic Studies and Education</option><option>Diploma in Islamic Studies/English Language and Education</option><option>Diploma in English Language/Islamic Studies and Education</option><option>Certificate in Arabic Language</option><option>Diploma in Islamic Studies/Arabic/Education</option><option>Diploma in Islamic Studies/Hausa Education</option><option>Diploma in Quranic Science</option><option>Diploma in Hausa Language/Arabic and Education</option><option>Diploma in Education Management</option><option>Diploma in Local Government Administration</option><option>Diploma in Criminology</option><option>Diploma in Computer Studies</option><option>Diploma in Public Administration</option><option>Diploma in Business Administration</option><option>Diploma in Library and Information Studies</option><option>Diploma in Business and Commercial Law</option><option>Diploma in Public Accounting and Auditing</option><option>Diploma in Entrepreneurship Studies</option><option>Advanced Diploma in Law</option><option>Advanced Diploma in Public Administration</option><option>Pre-Diploma for Consultancy Services courses</option><option>Remedial Programme for O/L Examination</option><option>Diploma in Quranic Science and Arabic</option><option>Certificate in Arabic Language</option><option>Diploma in Banking and Finance</option><option>Diploma in English-Hausa Education</option><option>Diploma in English-Arabic Education</option><option>Guidance and Counselling</option><option>Diploma in Public Administration (Consult)</option>	
		</select>';
		}
		?>
		
		</div>
  </div>
  
   <div class="col-md-6">
   <div class="form-group">
		<label for="phonenumber">Registration Number</label>
		<input type="text" class="form-control" value="<?php echo $number;?>" id="reg_no" placeholder="Registration Number" readonly >
		</div>
		
		 <div class="form-group">
		<label for="email">level</label>
		
			<?php
				if($level !=""){
					echo '
					<input type="text" class="form-control" value="'.$level.'" id="level" placeholder="Level" readonly >
					';
				}else{
					echo '
					<select class="form-control" id="level">
					<option><option>
					<option>100 Level<option>
					<option>200 Level<option>
					</select>
					';
				}
			?>
			
		
		
		</div>
  </div>