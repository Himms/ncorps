<?php

	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	
	include_once("../include/connections.php");
	include_once("../php/get_user_profile.php");
	
	
}

?>
<div class="col-md-12" style="padding-left:0px; padding-right:0px;">
			<div class="list-group">
				<ul class="list-group">
					<li class="list-group-item list-group-item-success">
						<h4>My Bed Space</h4>
					</li>
				</ul>
			
			</div>
			
			<?php
			
				//chk if the student already has bedspace, if yes chk if the student has paid for the space, if yes, display the space
				$check_my_acc = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE std_id='$number' ") or die(mysql_error());
				if($check_my_acc){
					$check_my_acc_row=mysqli_num_rows($check_my_acc);
					if($check_my_acc_row > 0){
						$get_my_room_info = mysqli_fetch_array($check_my_acc);
						$room_info_room_id = $get_my_room_info['room_id'];
						$room_info_site_id = $get_my_room_info['hostel_site'];
						$room_info_block_id = $get_my_room_info['hostel_categories'];
						
						
				
						$mm = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_info_room_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_room = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_categories  WHERE id='$room_info_block_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_block = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$room_info_site_id' ");
						$ronn = mysqli_fetch_array($mm);
							$site_title = strtoupper($ronn ['title']);
echo'<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Hostel Bedspace Information</h3>
  </div>
  <div class="panel-body">';
  
		//if the student has paid for the space
		$sql_chk=mysqli_query($con,"SELECT *FROM payments WHERE number ='$number' AND status='1' AND payment_type='Accommodation Fee'") or die(mysqli_error($con));
		if($sql_chk){
			$sql_chk_row=mysqli_num_rows($sql_chk);
			if($sql_chk_row > 0){
				echo '
				<ul class="list-group">
  <li class="list-group-item">
    <span class="badge">'.$site_title.'</span>
		Hostel Site
  </li>
  <li class="list-group-item">
    <span class="badge">'.$title_block.'</span>
		Hostel Category
  </li>
  <li class="list-group-item">
    <span class="badge">'.$title_room.'</span>
		Room Number
  </li>
</ul>
<br/><br/>
	
				';
			}else{
				
				echo'<div class="col-lg-12 well alert-danger">You have 6H to make payment, Your space will be unbooked if you fail to pay.</div>';
			}
		}
  echo'</div>
</div>';
					}else{
						//chk if the student is eligible or not
						if($hostel_eligibility ==1){
						    
						    //cont start
						    
						    
							//book for room, display all rooms that has not been booked
							$check_blocks = mysqli_query($con,"SELECT *FROM hostel_categories WHERE gender='$gender'") or die(mysql_error());
						if($check_blocks){
							$row=mysqli_num_rows($check_blocks);
							if($row > 0){
							while($rows_blocks = mysqli_fetch_array($check_blocks)){
								$block_name = $rows_blocks['title'];
								$block_id = $rows_blocks['id'];
								//echo '<div class="col-md-12">'.$block_name.'</div>';
								
								echo '
								
								
								<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">'.$block_name.'</h3>
  </div>
  <div class="panel-body">';
   
   $get_rooms = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE hostel_categories='$block_id' AND reserved='1'");
								if($get_rooms){
									if(mysqli_num_rows($get_rooms) > 0){
										while($rooms_get_row = mysqli_fetch_array($get_rooms) ){
											$room_title = $rooms_get_row['title'];
											$room_id = $rooms_get_row['id'];
											$hostel_categories_id = $rooms_get_row['hostel_categories'];
											$bedspace_no = $rooms_get_row['bedspace'];
											
							$check_my_alllll = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE room_id='$room_id' AND status !='0'") or die(mysql_error());
							$num_of_allocated = mysqli_num_rows($check_my_alllll);
							$remainder = $bedspace_no - $num_of_allocated;
							if($remainder > 0){
								echo '<div class="col-sm-2"><button onClick="select_room('.$student_portal_login_id.','.$room_id.')">'.$room_title.'</buttton></div>';
							}
											
										}
									}else{
										echo '<div class="col-md-12">NO AVAILABLE ROOM IN THIS BLOCK</div>';
									}
								}
 echo' </div>
</div>
								
								';
			
							}
							}
							
							
							
						}
						
						
						//cont end
							
						}else{
							echo'<div class="col-lg-12 well alert-danger">Sorry, Try Again latter.</div>';
						}
					}
				}
			
?>		
</div>