<?php
session_start();
$courses=array();
$h='';
$session_id=$_POST['id'];
//first semester
$id=$_SESSION['student_portal_login_id'];
include_once("../include/connections.php");
$sql="SELECT * FROM students_courses WHERE student_id='$id' AND status='1' AND semester='1' AND session='$session_id' ";
$query=mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($query)){
   $semester=$row['semester'];
   $course_id=$row['course_id'];
  $s="SELECT * FROM courses WHERE id='$course_id'";
  $q=mysqli_query($con,$s);
  $r=mysqli_fetch_assoc($q);
$h=$h.'<tr>
    <td align="center">'.$r['title'].'</td>
    <td align="center">'.$r['code'].'</td>

    </tr>
    ';
}
echo '
<label text-align="center"><h4>FIRST SEMESTER</h4></label>

<table class="table table-bordered">
<thead>
<tr>
<td align="center">COURSE TITLE</td>
<td align="center">COURSE CODE</td>
</tr>
</thead>
<tbody>
'.$h.'

</tbody>
</table><br>'  ; 
$semester='';
$course_id='';
$h='';
//first semester
include_once("../include/connections.php");
$sql="SELECT * FROM students_courses WHERE student_id='$id' AND status='1' AND semester='2' AND session='$session_id' ";
$query=mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($query)){
   $semester=$row['semester'];
   $course_id=$row['course_id'];
  $s="SELECT * FROM courses WHERE id='$course_id'";
  $q=mysqli_query($con,$s);
  $r=mysqli_fetch_assoc($q);
  
     $h=$h.'<tr>
    <td align="center">'.$r['title'].'</td>
    <td align="center">'.$r['code'].'</td>

    </tr>
    ';
}
echo '
<label text-align="center"><h4>SECOND SEMESTER</h4></label>
<table class="table table-bordered">
<thead>
<tr>
<td align="center">COURSE TITLE</td>
<td align="center">COURSE CODE</td>
</tr>
</thead>
<tbody>
'.$h.'

</tbody>
</table>'  ; 



?>
