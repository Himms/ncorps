<?php
include_once("../include/connections.php");
//get the current semester
$sn=0;
$c_total="0";
$sql="SELECT * FROM sessions WHERE  current_session='1' AND status='1' ";
$query=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($query);
$current_semester=$row['current_semester'];
//get registered student courses
$sql = "SELECT course_id FROM students_courses WHERE student_id='$student_portal_login_id' AND semester='2' AND status='1'";
		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		if(mysqli_num_rows($sql_run) > 0){
            while( $row = mysqli_fetch_assoc($sql_run)){
                //print_r($row);
                $course_id=$row['course_id'];
                 $sql="SELECT *  FROM courses WHERE id='$course_id'";
                 $query=mysqli_query($con,$sql);
                 if(mysqli_num_rows($query)>0){
                 while($r=mysqli_fetch_assoc($query)){
                 	$c=$r['unit'];
                     ++$sn;
                     $c_total=$c_total + $c;
                     
               echo '<tr>
               		<td>'.$sn.'</td>
               		<td>'.$r['code'].'</td>
               		<td>'.$r['unit'].'</td>
               		</tr>';
                  
                 
            }
          
            } 
            } 
                         
        }
        else{
            echo '<tr><td colspan="1"><h2 style="color:red">Please Register Your Courses</h2></td></tr>';
        }

?>