<?php
session_start();


include_once("../include/connections.php");

$student_id=$_SESSION['student_portal_login_id'];


$course_id=$_POST['course_id'];
$semester_id=$_POST['semester_id'];
$session_id=$_POST['session_id'];
$project_id=$_POST['project_id'];


	$total_cu=0;

include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
//check if has been registered
	$check_reg_bf_query=mysqli_query($con," select * FROM students_courses_".$current_session." where course_id='$course_id' AND student_id='$student_id' AND session = '$session_id' AND semester='$semester_id'");
	$check_reg_bf_num_rows = mysqli_num_rows($check_reg_bf_query);
	if( $check_reg_bf_num_rows > 0){
		//it has been registered
		//check status
		
		$sql="DELETE FROM students_courses_".$current_session." WHERE course_id='$course_id' AND student_id='$student_id'  AND session = '$session_id' AND semester='$semester_id'";
		$query=mysqli_query($con,$sql);
				if($query){
					//include('calculate_tcu_during_course_reg.php');
						echo $success=0;
							
					}
					
		
	}else{
		//register course
			$sql="INSERT INTO students_courses_".$current_session." (student_id,session,semester,course_id,status,project_id) VALUES('$student_id','$session_id','$semester_id','$course_id','1','$project_id')";
			$query=mysqli_query($con,$sql);
			if($query){
					//include('calculate_tcu_during_course_reg.php');
				echo 1;
			}
		
	}

?>