<div class="col-md-12">
		<style>
.box{
	text-align:center;
	background-color:#ccc;
	padding:10px;
	font-weight:bold;
	font-family:italic;

}
.student-detail{
	font-family:italic;
}
.l{
	text-align:center;
}
.passport{
	height:150px;
	width:150px;
}
</style>
<?php
session_start();
include_once('../php/get_student_profile.php');
if(empty($img)){
			
			$pic='0.png';
		}else{
			
			$pic=$img;
			
		}
?>
<div class="col-md-12">
		<div class="col-md-12" style="background-color:#ffffff;">
		<div class="modal-content" style="border:1px solid #000">
		<center><img src="./images/logo.png" alt=""/></center>
		<div class="box" style="background-color:black;color:white">SECOND SEMESTER EXAMINATION CARD</div><br>
		<table width="100%" style="font-size:10px;">
			<tr>
				<td width="60%">
					<table width="100%">
						<tr>
							<td width="100%"><label for="">NAME:<?php echo ' '.$first_name.' '.$other_names; ?></label></td>
						</tr>
						<tr>
							<td width="100%"><label for="">REGISTRATION NUMBER:<?php echo ' '.$number; ?></label></td>
						</tr>
						<tr>
							<td width="100%"><label for="">DEPARTMENT : <?php echo ' '.$department; ?></label></td>
						</tr>
						<tr>
							<td width="100%"><label for="">LEVEL:<?php echo ' '.$level; ?></label></td>
						</tr>
				</table>
				</td>
				<td width="40%"><img src="../flailas/uploads/<?php echo $pic; ?>" alt="" class="img-thumbnail passport"></td>
			</tr>
		</table>
		
		
		<div class="row">
			<div class="col-md-12 l">
		<table class="table table-bordered" style="font-size:10px;">
		<thead>
		<tr>
		<td>S/No</td>
		<td>Course code</td>
		<td>Course Unit</td>
		</tr>
		</thead>
		<tbody>
		
		<?php include_once('exam_card_courses.php'); ?>
		
		</tbody>

		</table>
		<label>Total Unit: <?php echo $c_total; ?></label><br/>
		<label>sign:_________________________________________</label><br>
	<label>Examination officer's signature and stamp</label><br>
	
	
	</div>
		</div>
		
		</div>
		<button class="btn btn-default pull-left modal-content" onclick="printDiv('content')">
	<i class="glyphicon glyphicon-print"></i>
	print exam card!
	</button>
		</div>
</div>
</div>