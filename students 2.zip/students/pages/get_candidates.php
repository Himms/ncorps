<?php
//error_reporting(0);
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
  $student_id=$student_portal_login_id;
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
		$office_id=$_POST['office_id'];

		//get all the offices
		$sql_get_office=mysqli_query($con,"SELECT *FROM offices WHERE offices_id='$office_id'");
	if($sql_get_office){
		$sql_get_officeRow=mysqli_num_rows($sql_get_office);
		if($sql_get_officeRow > 0){
			$get_rows=mysqli_fetch_assoc($sql_get_office);
				$title=$get_rows['title'];
				$office_id=$get_rows['offices_id'];

		}
	}
   ?>
  
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>Voting for the Office of the <?php echo $title; ?><hr/></h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
	<?php
		//chk if you have voted for this office or not
		$sql_chkVoted=mysqli_query($con,"SELECT *FROM votes WHERE student_id='$student_id' AND office_id='$office_id'");
	if($sql_chkVoted){
		$sql_chkVotedRow=mysqli_num_rows($sql_chkVoted);
		if($sql_chkVotedRow == 0){
			//get list of all candidates
	$sql_get_candidate=mysqli_query($con,"SELECT *FROM candidates WHERE office_id='$office_id' ");
	if($sql_get_candidate){
		$sql_get_candidateRow=mysqli_num_rows($sql_get_candidate);
		if($sql_get_candidateRow > 0){
			while($rows=mysqli_fetch_assoc($sql_get_candidate)){
				$candidate_id=$rows['candidate_id'];
				
				//get candidate info
				$sql = "SELECT *FROM student_".$current_session." WHERE id='$candidate_id'";
	

		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 //$project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			
			 $email=$get_Acc_detail['email'];
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $level=$get_Acc_detail['level'];
		
			 $full_name=$surname.' '.$first_name.' '.$other_names;
			 $img=str_replace("/","_",$number);
			 echo '
				<div class="col-md-4">
				<center>
				<img src="../images/candidates/'.$img.'.JPG" alt="..." class="img-thumbnail" style="width:100%;height:150px;">
				<a href="#" onclick="vote('.$candidate_id.','.$office_id.')">	<b>'.$full_name.'</b><br/>
				
				</a>
				</center>
				</div>
			 ';
		}
			}
		}
	}
		}else{
			echo '<div class="alert alert-danger" role="alert">
				You have already voted for this office, Please click on any of the office you have not voted for
			</div>';
		}
	}
	
	?>
</div>
</div>
</div>