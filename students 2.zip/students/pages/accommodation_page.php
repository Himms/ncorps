<?php

	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
	 $student_portal_login_id= $_SESSION['student_portal_login_id'];
	  include_once("../include/db.php");
	 
	include_once("../php/get_user_profile.php");
	
include_once("../include/GetCurrentSession.php");
	$session_title_sp=str_replace("/","_",$session_title);

}
	

?>
<div class="col-md-12">

		<div class="list-group panel-primary">
				<ul class="list-group">
					<li class="list-group-item panel-primary">
						<h4>ACCOMMODATION</h4>
					</li>
				</ul>
		</div>
<?php
	$txref=$id;
    include_once("../include/connections.php");
    //chk if the student has been allocated bedpace and has paid for the space 
	$check_my_acc = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE std_id='$number' ") or die(mysql_error());
				if($check_my_acc){
				$check_my_acc_row=mysqli_num_rows($check_my_acc);
					if($check_my_acc_row > 0){
						$get_my_room_info = mysqli_fetch_array($check_my_acc);
						$room_info_room_id = $get_my_room_info['room_id'];
						$room_info_site_id = $get_my_room_info['hostel_site'];
						$room_info_block_id = $get_my_room_info['hostel_categories'];
						
						
				
						$mm = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_info_room_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_room = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_categories  WHERE id='$room_info_block_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_block = $ronn ['title'];
							$hostel_amount = $ronn ['hostel_amount'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$room_info_site_id' ");
						$ronn = mysqli_fetch_array($mm);
							$site_title = strtoupper($ronn ['title']);
echo'<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Hostel Bedspace Information</h3>
  </div>
  <div class="panel-body">';
  
		//if the student has paid for the space
		$sql_chk=mysqli_query($con,"SELECT *FROM payments_".$session_title_sp." WHERE number ='$number' AND status='1' AND payment_type='Accommodation Fee' AND payment_date !='' AND payment_date !=' '") or die(mysqli_error($connn));
		if($sql_chk){
			$sql_chk_row=mysqli_num_rows($sql_chk);
			if($sql_chk_row > 0){
				echo '
				<ul class="list-group">
  <li class="list-group-item">
    <span class="badge">'.$site_title.'</span>
		Hostel Site
  </li>
  <li class="list-group-item">
    <span class="badge">'.$title_block.'</span>
		Hostel Category
  </li>
  <li class="list-group-item">
    <span class="badge">'.$title_room.'</span>
		Room Number
  </li>
</ul>
<hr/>

<b style="color:red;">Please proceed to the hostel to claim your bedspace, you are required to take along your ID card or Admission Letter and Evidence of payment for identification </b>
	<hr/>
	<p><a href="AllocationSlip.php" target="_blank" style="color:green;font-size:16px;">Click to print allocation slip</a></p>';
				
			}else{
				echo'<div class="col-lg-12 well alert-danger">You have 6H to make payment, Your space will be unbooked if you fail to pay.</div>';
				echo'
				 <div class="modal-footer">
        <button type="button" class="btn btn-info" data-dismiss="modal">Feel Free to contact us if you have any complain</button>

			<a style="background-color:green;color:#fff;" href="#" class="btn btn-default" onclick="feepayment()">Click to make your payment</a>
       
      </div>
				';
				
			}
		}
  echo'</div>
</div>';
					}else{ 
		//school fee has been confirmed, read tearm and condition
				 echo '
			<div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Info:</span>
		You are Eligible to apply for the Hostel, Please read the instruction carefully before you proceed to make payment, Aslo note that the 
		payment is online and any other form of payment will not be considered. 
		<br/>
		
		if you have made payment for hostel, kindly wait while we verify your payment.
	<br/><br/>
	
	<a href="#" style="color:#fff;" class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal">Click here to read Instruction and accept our Terms and Conditions </a>
</div>';




		
     }
					
}else{
     echo '
			<div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
		Network Issue, Please try again next time
	<br/>
</div>';
}
	
	
	
	
	
	
	
	
	
?>

</div>