<div class="col-md-12">

	
<div class="col-md-12" style="padding-left:0px; padding-right:0px;">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>PROFILE</h4>
					</li>
				</ul>
			<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
 				<div class="list-group">
				<ul class="list-group">
				<li class="list-group-item list-group-iteam">
				<div class="row">
				
  <div class="col-md-4">
         <div class="form-group">
		<label for="surname">Surname </label>
		<input value="<?php echo $first_name;?>" type="text" class="form-control" id="first_name" readonly>
		</div>
  </div>
  <div class="col-md-4">
        <div class="form-group">
		<label for="First name">Othername</label>
		<input value="<?php echo $other_name;?>" type="text" class="form-control" id="last_name" readonly>
		</div>
  </div>
   <div class="col-md-4">
  <div class="form-group">	
  <label for="middlename">Marital status</label>
			<select id="maritalstatus" value="" class="form-control">
				<label for="level">status</label>
				<option name=""><?php echo $maritalstatus; ?></option>
				<option name="married">married</option>
				<option name="single">single</option>
				<option name="other">other</option>
				</select>
			</div>
			</div>
  
   <div class="col-md-4">
		<div class="form-group">	
			<label for="middlename">Sex</label>
			<input value="<?php echo $gender;?>" type="text" class="form-control" id="Sex" readonly>
		</div>
	</div>
  
   <div class="col-md-12">
   <hr/>Date of Birth
   </div>
   <div class="col-md-12">
		<div class="container">
    <div class="row">
        <div class="col-md-2">
            <div class="form-group">
				<label for="middlename">Day</label>
				<input value="<?php echo $day;?>" type="text" class="form-control" id="day">
            </div>
        </div>
		
		<div class="col-md-2">
            <div class="form-group">
				<label for="middlename">Month</label>
				<input value="<?php echo $month;?>" type="text" class="form-control" id="month">
            </div>
        </div>
		
		<div class="col-md-2">
            <div class="form-group">
				<label for="middlename">Year</label>
				<input value="<?php echo $year;?>" type="text" class="form-control" id="year">
            </div>
        </div>
		</div>
    </div>
		
		
		
		
	<div class="col-md-12"><hr/></div>
	
 
  <div class="col-md-12">
  <div class="form-group">	
  <label for="middlename">State of Origin</label>
	<select onChange="load_lga()" id="state" class="form-control">
		<option><?php echo $state_title; ?></option>
		
		<?php
		
			include_once("../include/connections.php");
	
			//get state
			$sql_get_state=mysql_query("SELECT *FROM state") or die(mysql_error());
			if($sql_get_state){
				$sql_get_state_row=mysql_num_rows($sql_get_state);
				if($sql_get_state_row > 0){
					while($row=mysql_fetch_array($sql_get_state)){
						
						echo '<option>'.$row['title'].'</option>';
					}
				}
			}
		
		?>
	</select>
</div>

	</div>
	
	<div class="col-md-12">
  <div class="form-group">	
  <label for="middlename">LGA</label>
	<select  id="lga" class="form-control">
		<option><?php echo $lga_title;?></option>
	</select>
</div>

	</div>
  
 
   <div class="col-md-6">
   <div class="form-group">
		<label for="phonenumber">Phone number</label>
		<input type="text" class="form-control" value="<?php echo $phone_no;?>" id="phone_no" placeholder="phone no">
		</div>
		
		 <div class="form-group">
		<label for="email">Email</label>
		<input type="text" class="form-control" value="<?php echo $email;?>" id="email" placeholder="email" readonly>
		</div>
  </div>
  
  
  
   <div class="col-md-12">
   <div class="form-group">
		<label for="address">Address</label>
		<textarea id="address" rows="6px" cols="30px"><?php echo $address; ?></textarea>
		</div>
  </div>
	
</li>

			</div>

</div>
</div>
			</div>
		</div>
</div>
</div>	