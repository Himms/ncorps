<html>
<head>
</head>
<body>

<div class="col-md-12" style="padding-left:0px; padding-right:0px;" id="p">
		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>PROFILE</h4>
					</li>
				</ul>
		

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="biodata_heading">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#biodata" aria-expanded="false" aria-controls="biodata">Biodata</a>
      </h4>
    </div>
    <div id="biodata" class="panel-collapse collapse" role="tabpanel" aria-labelledby="biodata_heading">
      <div class="panel-body">
        <?php include_once('biodata_applicant.php') ?>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Health Information
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
		 <?php include_once('helth_info_applicant.php'); ?>  
      </div>
    </div>
  </div>
  
   <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingacadamic">
      <h4 class="panel-title">
        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#acadamic" aria-expanded="false" aria-controls="acadamic">
          Academic Record
        </a>
      </h4>
    </div>
    <div id="acadamic" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingacadamic">
      <div class="panel-body">
		 <?php include_once('acadamic_applicant.php'); ?>  
      </div>
    </div>
  </div>

</div>

 

</div>


</div>
  <div class="col-md-12" style="padding-left:0px; padding-right:0px;">
	<div id="profile_error"></div>
		<button onclick="update_applicant_profile()" class="btn btn-default" type="submit" id="btnupdateprofile">Save</button>
		<a class="btn btn-default" href="#" onclick="preview_biodata_applicant()">Preview Biodata</a>
		
		<!----<a href="dashboard.php?qlk=<?php //echo $mp_qlk;?>&act=print_biodata" class="btn btn-success">Preview</a> ---->
		
	</div>
		</body>
</html>
	
	