<table class="table table-bordered">
<thead>
<tr>
<td>TITLE</td>
<td>CODE</td>
<td>UNIT</td>
<td colspan="2"></td>
</tr>
</thead>
<tbody>
<?php
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	//chk if the session has pass or not
	//if the session is not the current session, get only the registered courses else get editable courses

	include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	 $course_ids=array();
     $registered_course_ids=array();
	//get project id

	//get all the courses
	 $sql="SELECT * FROM courses WHERE semester='2'";
     $query=mysqli_query($con,$sql);
      while($row=mysqli_fetch_assoc($query)){
	  $course_id=$row['id'];
      $code=$row['code'];
	
		//chk if the course has been register before or not
		$sql_chk=mysqli_query($con,"SELECT *FROM students_courses_".$current_session." where course_id='$course_id' AND student_id='$student_portal_login_id' AND session = '$session_id' AND semester='2' AND status='1'");
		if($sql_chk){
			$sql_chk_row=mysqli_num_rows($sql_chk);
			if($sql_chk_row > 0){
				$html_string='
                    <tr style="background-color:#CCC;" id="r'.$course_id.'">
						<td>'.$row['title'].'</td>
						<td>'.$code.'</td>
						<td>'.$row['unit'].'</td>
						<td>
							<button  onclick="registercourse('.$course_id.','.$semester.','.$session_id.',1)" id='.$course_id.' class="col-md-12 btn btn-default"><i style="color:#FFF" class="glyphicon glyphicon-remove"></i>
								Delete</button>
					</td></tr>'; 
			}else{
			$html_string='
                    <tr style="background-color:#FFF;" id="r'.$course_id.'">
						<td>'.$row['title'].'</td>
						<td>'.$code.'</td>
						<td>'.$row['unit'].'</td>
						<td>
							<button  onclick="registercourse('.$course_id.','.$semester.','.$session_id.',1)" id='.$course_id.' class="col-md-12 btn btn-default"><i style="color:#FFF" class="glyphicon glyphicon-add"></i>
								Add</button>
					</td></tr>'; 
			}
		}
		 
                     echo $html_string;
	  }
	  
				   
             
?>


</tbody>
</table>