<div class="form-bottom">
  <div class="form-group">
	<div class="row">
	
	<form action="index.php?token=<?php echo $token;?>" method="POST">
  <div class="form-group">
	<div class="row">
  <div class="col-xs-6" style="padding-left:0px;padding-right:0px;">
    <input name="first_name" type="text" class="form-control" placeholder="First Name">
  </div>
  <div class="col-xs-6" style="padding-left:0px;padding-right:0px;">
    <input name="other_names" type="text" class="form-control" placeholder="Other Names">
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Gender</label>
	<select name="gender" class="form-control">
		<option></option>
		<option>Male</option>
		<option>Female</option>
	</select>
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Email</label>
	<input name="email" type="text" class="form-control" placeholder="Email">
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Applicant's Phone Number</label>
	<input name="phone_number" type="text" class="form-control" placeholder="Applicant's Phone Number">
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Course Applying for</label>
	<select name="course" class="form-control">
		<option></option>
		
		<?php
		
		include_once('../include/connections.php');
		$sql_get_programme=mysqli_query($con,"SELECT *FROM programmes WHERE project_id='2'");
		if($sql_get_programme){
			$sql_get_programme_row=mysqli_num_rows($sql_get_programme);
			if($sql_get_programme_row > 0){
				While($get_title=mysqli_fetch_array($sql_get_programme)){
					$p_title=$get_title['title'];
				
				echo '<option>'.$p_title.'</option>';
				}
				
			}
		}
		?>
	</select>
  </div>
  
 
  <div class="col-xs-12" style="padding-top:5px;">
   <button onclick="create_application()" type="submit" name="myBtn" type="button" class="btn btn-success">Submit</button>
  </div>
</div>

</form>
	</h4>
  </h5>
</div>
    </div>
			                
		                    </div>
									
			
			                       
			                    
		                    </div>