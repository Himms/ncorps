
						<div class="col-md-12">
						
							<div class="col-lg-12 well alert-success">
								<h4>Terms and Conditions</h4>
									<ul>
										<li>
										By Clicking on the Accept button, you agree to the terms and conditions of the Accommodation, At 
										any moment in time, your application can be terminated if you Violate  any condition or Hostel Rules and Regulations.
										</li>
										<li>At any point in time, if it comes to our notice that wrong information is provided by you, your Bedspace will be revoke without any Refund.</li>
										<li>
										    Ibrahim Badamasi Babangida University is not under any obligation to provide all students with hostel accommodation. Allocation of bed space in halls of residence is, therefore, a privilege and not a right.
										</li>
										<li>2.	Allocation of bed spaces to eligible students is on the principle of first come first served.</li>
										<li>3.	Only fresh and final-year students may be eligible for bed space. In other words, while the University makes every effort to ensure that most students enjoy hostel accommodation, it should be realized that no student has a statutory right to University accommodation.</li>
										<li>4.	Students allocated bed spaces are entitled to the benefits of the facilities in the hostels.</li>
										<li>5.	Any student found occupying a bed space illegally or that accommodates a ‘squatter’ at any point in time will be ejected and will be made to face disciplinary actions. Punishment may range from ejection, rustication, to expulsion. </li>
										<li>6.	Any bed space or room allocation made cannot be altered and students must remain where they are assigned for the period of session under review.</li>
										<li>7.	Acceptance of place in the hostels means acceptance of all existing rules and regulations that may from time to time be drawn up to facilitate management of the hostels.</li>
										<li>8.	Failure to comply with hostel regulations may lead to withdrawal of hostel allocation and other appropriate punishments.</li>
										<li>9.	Hall Administrators are authorized to make supplementary rules which they may consider necessary for the smooth running of the hostels but they must seek the permission of the Dean, Student Affairs before implementation.</li>
										<li>10.	Sale or consumption of alcohol or any intoxicant is strictly prohibited. Violation attracts expulsion.</li>
										<li>11.	Smoking of cigarettes in public places such as hostel rooms, common rooms, classrooms, library, administrative offices, cafeteria, practical laboratories, etc, is strictly prohibited. Violation attracts suspension.</li>
										<li>12.	Smoking of Indian hemp is strictly prohibited. Violation attracts expulsion. </li>
										<li>13.	Fighting, quarrelling, threat of any kind, open religious preaching, and loud music are not allowed in the hostels and their environ. Violation attracts rustication.</li>
									</ul>
									
					
						<a href="#" onclick="load_my_bedspace()" class="btn btn-success glyphicon glyphicon-Next">
                           Accept
                        </a>
							</div>

						</div>
					
		