<?php session_start(); ?>

<?php
	//get other menu depending on the school and the user type
	//session_start();
	include_once("../include/connections.php");
	//get user_acc_details
	
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
		$sql = "SELECT *FROM students_".$current_session." WHERE id='$student_portal_login_id' AND  status='1'";
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 
			
		}

	//get the menu
	$sql_get=mysqli_query($con,"SELECT *FROM eportal_menu WHERE project_id='$project_id'");
	if($sql_get){
		$sql_get_row=mysqli_num_rows($sql_get);
		if($sql_get_row > 0){
			while($get_rows=mysqli_fetch_assoc($sql_get)){
				$menu_title=$get_rows['menu_title'];
				$menu_function=$get_rows['menu_function'];
				$menu_link=$get_rows['link'];	
				echo '<a href="'.$menu_link.'" class="list-group-item" onclick="'.$menu_function.'">'.$menu_title.'</a>';
			}
		}
	}

?>