<?php
//session_start();
$id=$_SESSION['student_portal_login_id'];
$semester="First Semester";
include_once("../include/connections.php");
         $course_ids=array();
         $registered_course_ids=array();
		//get program id;
		$sql = "SELECT programme_id,level FROM students WHERE id='$id'";
		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		if(mysqli_num_rows($sql_run) > 0){
			 $row = mysqli_fetch_assoc($sql_run);
             $programme_id=$row['programme_id'];
             $current_level=$row['level'];
			 
             //get programm courses
              //only courses from his/her level and below should be loaded incase e get carry over
             $sql="SELECT * FROM programmes_courses WHERE programme_id='$programme_id' AND semester='$semester'";
            $query=mysqli_query($con,$sql) or die(mysqli_error($con));
             if(mysqli_num_rows($query)>0){
                while($row=mysqli_fetch_assoc($query)){
                    //get course_id
                   array_push($course_ids,$row['course_id']);
                 
            }
            }           
        }
           
        //get registered_course_ids
            $sql="SELECT *  FROM students_courses WHERE student_id='$id' AND status='1'";
                     $query=mysqli_query($con,$sql) or die(mysqli_error($con));
                     if(mysqli_num_rows($query)>0){
                    while($row=mysqli_fetch_assoc($query)){
                    //get course_id
                    array_push($registered_course_ids,$row['course_id']);
                               
                 }   
                }
          
       //get already registered courses
        $result=array_intersect($course_ids,$registered_course_ids);
        foreach($result as $id){
                  $sql="SELECT * FROM courses WHERE id='$id'";
                   $query=mysqli_query($con,$sql);
                   $row=mysqli_fetch_assoc($query);
                   $code=$row['code'];
                   $code=trim($code);

                    $html_string='
                    <tr style="background-color:#FFFDD0" id='.$id.'><td>'.$row['title'].'</td><td>'.$code.'</td><td>'.$row['unit'].'</td><td>
                    <button  onclick="register_course('.$id.','.$code.',1)" id='.$code.' class="col-md-12 btn btn-default"><i style="color:red" class="glyphicon glyphicon-remove"></i>
                    delete</button></td></tr>'; 
                     echo $html_string;
                                     
        }
        //get the remaining courses
        $result=array_diff($course_ids,$registered_course_ids);
        foreach($result as $id){
                  $sql="SELECT * FROM courses WHERE id='$id'";
                   $query=mysqli_query($con,$sql);
                   $row=mysqli_fetch_assoc($query);
                   $code=$row['code'];
                    $html_string='
                    <tr  id='.$id.'><td>'.$row['title'].'</td><td>'.$code.'</td><td>'.$row['unit'].'</td><td>
                    <button  onclick="register_course('.$id.','.$code.',1)" id='.$code.' class="col-md-12 btn btn-default"><i style="color:green"  class="glyphicon glyphicon-plus"></i>
                    add</button></td></tr>'; 
                     echo $html_string;
                                     
        }
                 
       

     

                  
?>
  