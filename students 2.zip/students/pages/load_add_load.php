 <?php
	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	include_once("../php/get_student_profile.php");
	}
	
	//get total loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number'");
if($sql_student_loan_application){
	$loan_no=mysqli_num_rows($sql_student_loan_application);
	
	}
	
	
	//get total pending loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number' AND approval_status='0'");
if($sql_student_loan_application){
	$loan_pending=mysqli_num_rows($sql_student_loan_application);
	
	}
	
		//get total approved loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number' AND approval_status='1'");
if($sql_student_loan_application){
	$loan_approved=mysqli_num_rows($sql_student_loan_application);
	
	}
	
	//get total rejected loan
	$sql_student_loan_application=mysqli_query($con,"SELECT * FROM student_loan_application WHERE student_id='$number' AND approval_status='2'");
if($sql_student_loan_application){
	$loan_rejected=mysqli_num_rows($sql_student_loan_application);
	
	}
 
 ?>

<div class="col-md-12" style="padding-left:0px; padding-right:0px;" id="p">
		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>NEW LOAN APPLICATION</h4>
					</li>
				</ul>
		

<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="biodata_heading">
      <h4 class="panel-title">
			Add New
      </h4>
	 
	  <button onclick="loan_application()" style="float:right;background-color:green;" type="button" class="btn btn-default" aria-label="Left Align">
  <span class="glyphicon glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
</button>
    </div>
    <div id="biodata" class="panel-collapse" role="tabpanel" aria-labelledby="biodata_heading">
      <div class="panel-body">
			<div class="col-md-12">
				<div class="col-md-6">
			<div class="form-group">
		<label for="state">Loan Type</label>
			<select id="loan_type" class="form-control">
					<option></option>
					<option>School Fee Loan</option>
																
			</select>
		</div>
		</div>
		
		<div class="col-md-6">
			<div class="form-group">
		<label for="state">Amount Requesting</label>
			<select id="amount_needed" class="form-control">
					<option></option>
					<?php
						//chk if the student is indegin or not
						if($state=="Niger State"){
							echo '<option>5000</option>
								<option>10000</option>
								<option>15000</option>';
								
						}else{
						echo '<option>5000</option>
								<option>10000</option>
								<option>15000</option>
								<option>20000</option>';
						}
					?>
			</select>
		</div>
		</div>
				<p style="color:green;">I <?php echo $first_name; ?> with Matric Number <?php echo $number; ?> hereby undertake that i will pay back my school fees loan before end of 2017/2018 
				academic session and failure to do so the schhol autority should take any action againt me</p><br/><br/>
				
				<div id="loan_error"></div><a href="#" onclick="add_new_loan()" class="btn btn-success glyphicon glyphicon-Next">
                           Accept
                        </a>
			</div>
			
			
      </div>
    </div>
  </div>
  
 
</div>

 

</div>


</div>

	
	