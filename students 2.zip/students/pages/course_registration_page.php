<?php
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$email= $_SESSION['email'];
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND status='1'";
	

		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			 $level=$get_Acc_detail['level'];
			 
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $level=$get_Acc_detail['level'];
		
			 $full_name=$surname.' '.$first_name.' '.$other_names;
			 $mat_year=substr($number,0,3);
			 
			 if($image=='0.jpg'){
				 $pic='0.jpg';
			 }else{
				 $pic=$student_portal_login_id.'.jpg';
			 }
			
		}

	
	
?>
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>COURSE REGISTRATION</h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
  
	<?php
	
		//get the current session
		$get_session=mysqli_query($con,"SELECT *FROM sessions WHERE current_session='1'");
		if($get_session){
			$get_session_row=mysqli_num_rows($get_session);
			if($get_session_row > 0){
				$get_row=mysqli_fetch_array($get_session);
				$session_id=$get_row['id'];
				$session_title=$get_row['title'];

	 
			}
		}
	
	
	echo'
<div class="list-group">
  <a href="#" class="list-group-item active">
    '.$session_title.' -First Semester- '.$level.' Course Registration
  </a>
  <a href="#" class="list-group-item">';
  include_once("../include/connections.php");
			$semester="1";
			include('get_semester_course_reg.php');
  echo'</a>
 
</div>';

echo'
<div class="list-group">
  <a href="#" class="list-group-item active">
    '.$session_title.' -Second Semester- '.$level.' Course Registration
  </a>
  <a href="#" class="list-group-item">';
  include_once("../include/connections.php");
			$semester="2";
			include('get_second_semester_course_reg.php');
  echo'</a>
 
</div>';
	?>
</div>


<a class="btn btn-default" href="print_semester_registered_course.php?token=<?php echo md5($session_id); ?>&token_sm=<?php echo md5(1); ?>">
			<span class="glyphicon glyphicon-print" aria-hidden="true"></span>
			Print First Semester Course Registration
		</a>
		
<a class="btn btn-default" href="print_semester_registered_course2.php?token=<?php echo md5($session_id); ?>&token_sm=<?php echo md5(2); ?>">
			<span class="glyphicon glyphicon-print" aria-hidden="true"></span>
			Print Second Semester Course Registration
		</a>
		</a>
   
   