<?php

	session_start();
	include_once("../include/connections.php");
	//get user_acc_details
	
	$program=$_POST['program'];
	
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$sql = "SELECT *FROM user_login_info ulog INNER JOIN user_information uinfo ON ulog.user_info_id=uinfo.id WHERE uinfo.id='$student_portal_login_id'";
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 $usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 
			 
			
		}
		
		//get course of studeies details
		$sql_get_programmes_details=mysqli_query($con,"SELECT *FROM programmes WHERE id='$program'");
		if($sql_get_programmes_details){
			$sql_get_programmes_details_row=mysqli_num_rows($sql_get_programmes_details);
			if($sql_get_programmes_details_row > 0){
				$get_details=mysqli_fetch_array($sql_get_programmes_details);
					$department_id=$get_details['department_id'];
				
				//get department details
				$sql_get_department_detail=mysqli_query($con,"SELECT *FROM students_departments WHERE id='$department_id'");
				if($sql_get_department_detail){
					$sql_get_department_detail_row=mysqli_num_rows($sql_get_department_detail);
					if($sql_get_department_detail_row > 0){
						$get_department=mysqli_fetch_array($sql_get_department_detail);
						echo $title=$get_department['title'];
					}
				}
			}
		}
		
		


?>