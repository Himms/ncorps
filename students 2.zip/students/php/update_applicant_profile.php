<?php
	session_start();
	include_once("../include/connections.php");
	$student_id=$_SESSION['applicant_portal_login_id'];
	$maritalstatus=$_POST['maritalstatus'];
	
	
	$email=$_POST['email'];
		$name_of_guardian=$_POST['name_of_guardian'];
		$no_guardian=$_POST['no_guardian'];
		$address_gaurdian=$_POST['address_gaurdian'];
		$dob=$_POST['dob'];
	
		
		$H_status=$_POST['H_status'];
		$medication=$_POST['medication'];
		//echo $H_status;
		$disability=$_POST['disability'];
		$blood_type=$_POST['blood_type'];
		$gender=$_POST['gender'];
		$phone_no=$_POST['phone_no'];
		$address=$_POST['address'];
		$level=$_POST['level'];
		$permenat_address=$_POST['permenat_address'];
		$kin_name=$_POST['kin_name'];
		$kin_relationship=$_POST['kin_relationship'];
		$kin_phone_number=$_POST['kin_phone_number'];
		$kin_address=$_POST['kin_address'];
		$program=$_POST['program'];
		//get programme id
		$query=mysqli_query($con,"SELECT * FROM programmes WHERE title='$program'");
		$row=mysqli_fetch_assoc($query);
		$programme_id=$row['id'];
	
		
		$state=$_POST['state'];
		$sql_get_state=mysqli_query($con,"SELECT *FROM state WHERE title = '$state'");
		if($sql_get_state){
			$sql_get_state_row = mysqli_num_rows($sql_get_state);
			if($sql_get_state_row > 0){
						if($state_row=mysqli_fetch_assoc($sql_get_state)){
							$state_id = $state_row['id'];

						}
					}
		}
		
		
		$lga=$_POST['lga'];
		$sql_get_staff=mysqli_query($con,"SELECT *FROM lga WHERE title = '$lga'");
				if($sql_get_staff){
					$sql_get_staff_row=mysqli_num_rows($sql_get_staff);
					if($sql_get_staff_row > 0){
						$lga_row=mysqli_fetch_assoc($sql_get_staff);
							$lga_id = $lga_row['id'];
							
						
					}
				}
		
		
	$sql="UPDATE applicants SET state_id='$state_id',lga_id='$lga_id',kin_address='$kin_address',kin_phone_number='$kin_phone_number',kin_relationship='$kin_relationship',kin_name='$kin_name',permanent_address='$permenat_address',programme_id='$programme_id',level='$level',phone_no='$phone_no',marital_status='$maritalstatus',gender='$gender',dob='$dob',address='$address',sponsorship_name='$name_of_guardian',sponsorship_address='$address_gaurdian',medi='$medication',H_status='$H_status',disability='$disability',blood_type='$blood_type',email='$email',sponsor_number='$no_guardian' WHERE id='$student_id'";
		
		$query=mysqli_query($con,$sql);
		
		if($query){
			echo '<h4 style="color:green">Profile updated successfully</h4>';
		}
?>