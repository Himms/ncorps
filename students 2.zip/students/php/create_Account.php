<?php
	$project_id =$_POST['project_id'];
	$password1 =$_POST['password1'];
	$password2 =$_POST['password'];
	$email =$_POST['email'];
	$surname =$_POST['surname'];
	$firstname =$_POST['firstname'];
	$othernames =$_POST['othernames'];
	$gender =$_POST['gender'];
	$phonenumber =$_POST['phonenumber'];

	include_once("../include/connections.php");
	include_once('../include/get_project_details_with_id.php');
	include_once('../include/GetCurrentSession.php');
	
	$current_session=str_replace("/","_",$session_title);
	$pass=md5($password1);
	if($surname =="" && $firstname=="" && $othernames=="" && $gender=="" && $phonenumber=="" && $email=="" && $password=="" && $password1==""){
		echo '<p style="color:red">Provide all the requred Informations</p>';
	}else{
		if($password2 != $password1){
			echo '<p style="color:red">Password not thesame</p>'; 
		}else{
			//chk if email exist
			$sql_email = "SELECT *FROM applicants_".$current_session." WHERE email='$email'";
		$sql_run = mysqli_query($con, $sql_email) or die(mysqli_error($con));
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){	
			echo "Email already exist";
			
		}else{
			$sql_phonenumber = "SELECT *FROM applicants_".$current_session." WHERE phone_no='$phonenumber'";
		$sql_run = mysqli_query($con, $sql_phonenumber);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){	
			echo "Phone Number already exist";
			}else{
				//create account
				$sql_insert=mysqli_query($con,"INSERT INTO user_login(email,password,project_id) VALUES('$email','$pass','$project_id')");
				if($sql_insert){
					$insertSQL="INSERT INTO applicants_".$current_session." (surname,first_name,other_names,phone_no,gender,email,project_id) VALUES('$surname','$firstname','$othernames','$phonenumber','$gender','$email','$project_id')";
					$sql_inserStudent=mysqli_query($con,$insertSQL);
					if($sql_inserStudent){
						echo "Your Account has been created successfull, you can login to complete your registration";
					}
				}
			}
			
		}
		
			
		}
	}


?>