<?php
error_reporting(0);
//session_start();
		//session don start already
	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	
	$email= $_SESSION['email'];
	}
$state="";
$lga="";
$jamb_no="";
	include_once("../include/connections.php");
		include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	$sql = "SELECT *FROM student_".$current_session." WHERE email='$email'";
		
		$sql_run = mysqli_query($con, $sql);

		$no_of_rows=mysqli_num_rows($sql_run);

		if( $no_of_rows > 0){
			 $record = mysqli_fetch_assoc($sql_run);
		$id=$record['id']; 
		$student_id=$record['id'];
		$img=$record['image'];
		$number=$record['number'];
		$surname=$record['surname'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$full_name=$surname.' '.$first_name.' '.$other_names;
		$project_id=$record['project_id'];
		$hostel_eligibility=$record['hostel_eligibility'];
		$maritalstatus=$record['marital_status'];
		$gender=$record['gender'];
		$medication=$record['medi'];
		$H_status=$record['H_status'];
		$std_date=$record['dob'];
		$email=$record['email'];
		$address=$record['address'];
		$permenat_address=$record['permenat_address'];
		 
		$phone_no=$record['phone_no'];
		$sponsorship_name=$record['sponsorship_name'];
		$sponsorship_address=$record['sponsorship_address'];
		$sponsorship_number=$record['sponsor_number'];
		$state=$record['state_id'];
		$programme_id=$record['programme_id'];
		$programmeid=$record['programme_id'];
		
		$bedspace=$record['bedspace'];
		$platoon=$record['platoon'];
		$hostel=$record['hostel'];

        $sead=$record['sead'];

		$bank=$record['bank'];

		

		//get space
		$hostel = mysqli_query($con, "SELECT *FROM hostels WHERE id='$hostel'");
		if($hostel){
			$hostelRow = mysqli_num_rows($hostel);
			if($hostelRow > 0){
				$getHostel = mysqli_fetch_assoc($hostel);
				$hostelname = $getHostel['title'];
			}
		}
		

		$hostel = mysqli_query($con, "SELECT *FROM saed WHERE id='$sead'");
		if($hostel){
			$hostelRow = mysqli_num_rows($hostel);
			if($hostelRow > 0){
				$getHostel = mysqli_fetch_assoc($hostel);
				$seadname = $getHostel['title'];
			}
		}


		$hostel = mysqli_query($con, "SELECT *FROM banks WHERE id='$bank'");
		if($hostel){
			$hostelRow = mysqli_num_rows($hostel);
			if($hostelRow > 0){
				$getHostel = mysqli_fetch_assoc($hostel);
				$bankname = $getHostel['title'];
			}
		}
		
		
		// if($userType==0){
		// 	$search=$number;
		// }else{
		// 	$application_number=$record['application_number'];
		// 	$search=$application_number;
		// }
		
		//get programme
	// 	$query_programme=mysqli_query($con,"SELECT  *FROM programmes WHERE id='$programme_id'");
	// 	$row=mysqli_fetch_assoc($query_programme);
	// 	$course=$row['title'];
	// 	$department_id=$row['department_id'];
	// 	$programmetype=$row['type'];
		
		
	// 	//get programme
	// 	$query_programme=mysqli_query($con,"SELECT  *FROM students_departments WHERE id='$department_id'");
	// 	$row=mysqli_fetch_assoc($query_programme);
	// 	$department=$row['title'];
		
		
		
	// 	//$faculty=$record['faculty'];
	// 	//$hostel_faculty=$record['faculty'];
		
	// 	$query=mysqli_query($con,"SELECT title FROM state WHERE id='$state'");
	// 	$row=mysqli_fetch_assoc($query);
	// 	$state=$row['title'];
		
	// 	$lga=$record['lga_id'];
	// 	$query=mysqli_query($con,"SELECT title FROM lga WHERE id='$lga'");
	// 	$row=mysqli_fetch_assoc($query);
		
	// 	$lga=$row['title'];
	// 	$status=$record['marital_status'];
	// 	$medication=$record['medi'];
	// 	$blood_group=$record['blood_type'];
	// 	$disability=$record['disability'];
		
	// 	//$mat_no=$record['jamb_no'];
	// 	//$student_type=$record['student_type'];
		
	// 	$permenat_address=$record['permanent_address'];
	// 	$level=$record['level'];
	// 	//$lga_title=$record['lga_title'];
	// 	//$religion=$record['religion'];
		
		
	// 	$kin_address=$record['kin_address'];
	// 	$kin_phone_number=$record['kin_phone_number'];
	// 	$kin_relationship=$record['kin_relationship'];
	// 	$kin_name=$record['kin_name'];
		
		
	// 	$state_title="";
	// 	$lga_title="";
	// 	}
				
	
	// $sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
	// 	if($sql_get){
	// 		$sql_get_row=mysqli_num_rows($sql_get);
	// 		if($sql_get_row > 0){
	// 			while($row=mysqli_fetch_assoc($sql_get)){
	// 				$project_sm_logo=$row['project_sm_logo'];
	// 				$system_code=$row['system_code'];
	// 				$project_id=$row['project_id'];
	// 				$projects_title=$row['projects_title'];
					
	// 				$project_code=$row['project_code'];
	// 				$website=$row['website'];
	// 				$contact_person=$row['contact_person'];
	// 				$header_image=$row['header_image'];
	// 				$crf_image=$row['crf_image'];
	// 				$refree_image=$row['refree_image'];
					
	// 				$header_image='images/'.$header_image;
	// 				$crf_image='images/'.$crf_image;
	// 				$refree_image='images/'.$refree_image;
					
					
	// 			}
	// 		}
	// 	}

	// 		//mysqli_close($con);
		
		}		

?>



