<?php

session_start();
	include_once("../include/connections.php");
if(isset($_POST['username']) && isset($_POST['password']))
{
	$un=mysqli_real_escape_string($con,$_POST['username']);
	$pass=md5(mysqli_real_escape_string($con,$_POST['password']));
	
	//get project detal
	include_once("../include/connections.php");
	
	include_once('../include/get_project_details.php');
	
	include_once('../include/GetCurrentSession.php');
	
	
	$current_session=str_replace("/","_",$session_title);
	
	$sql = "SELECT *FROM student_".$current_session." WHERE number='$un' AND password='$pass' AND user_status='1'";
		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			 $row = mysqli_fetch_assoc($sql_run);
			$_SESSION['student_portal_login_id']=$row['id']; //Storing user session value.
			//$_SESSION['student_user_type']=$row['user_status']; //Storing user session value.
			//$_SESSION['project_id']=$row['project_id'];
			$_SESSION['email']=$row['email'];
			echo "1";
		}else{
			echo "0";
		}
		mysqli_close($con);
}

?>
