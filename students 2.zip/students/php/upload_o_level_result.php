
<?php
	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	}
	if(isset($_POST['exam_type'])){
		include_once("../include/connections.php");
		$exam_type = $_POST['exam_type'];
		$exam_year = $_POST['exam_year'];
		$exam_month = $_POST['exam_month'];
		$subject_id = $_POST['subject'];
		$sub_grade = $_POST['sub_grade'];
		$student_id = $student_portal_login_id;
		$exam_number= $_POST['exam_number'];
		
		if(empty($exam_number)){
			echo 'Enter Exam Number';
		}else if(empty($exam_year)){
				echo 'Select exam year';
		}
		else if(empty($exam_month)){
				echo 'Select exam month';
		}
		else if(empty($subject_id)){
					echo 'Select Subject';
		}
		else if(empty($sub_grade)){
				echo 'Select the grade obtained in the selected subject';
		}else if(empty($exam_type)){
				echo 'Select exam_type';
		}
		
		else{
			
			
			include_once("../include/GetCurrentSession.php");
			$current_session=str_replace("/","_",$session_title);
	
	
			// check if the student  has upload this information before
			$check_sql  = "select * from student_o_level_".$current_session." WHERE student_id = '$student_id'  AND exam_type = '$exam_type' AND  exam_year = '$exam_year' AND subject_id ='$subject_id' AND sub_grade = '$sub_grade'";
			$check_query = mysqli_query($con,$check_sql) or die(mysqli_error($con));
			$getNomRow=mysqli_num_rows($check_query);
				if($getNomRow == 0){ 
				// insert exam information into the table
		
				
						$insert_sql  = "insert into student_o_level_".$current_session." (student_id,exam_type,exam_year,exam_month,subject_id,sub_grade,exam_number)";
						$insert_sql  .= "values('$student_id','$exam_type','$exam_year','$exam_month','$subject_id','$sub_grade','$exam_number')";
						$insert_query = mysqli_query($con,$insert_sql) or die(mysqli_error($con));
						if($insert_query)
						{
							echo '1';
						}
					
				}else{ 
				// update the information for the student
				
					$update_sql = "update student_o_level_".$current_session." set exam_number='$exam_number',exam_type = '$exam_type' AND  exam_year = '$exam_year'  AND subject_id ='$subject_id' AND sub_grade = '$sub_grade' ";
					$update_sql = "where student_id = 'student_id' AND exam_type = '$exam_type' AND  exam_year = '$exam_year'  AND subject_id ='$subject_id' AND sub_grade = '$sub_grade' ";
					$updat_query = mysqli_query($con,$update_sql);
					if($updat_query){
						echo '1';
					}
					
				}
		}
		
	}


?>