<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		$payment_type=$_POST['payment_type'];
		$session=$_POST['session'];
		$teller=$_POST['teller'];
		$bank=$_POST['bank'];
		$branch=$_POST['branch'];
		$payment_date=$_POST['payment_date'];
		$depositor=$_POST['depositor'];
		
		
		$id = $student_portal_login_id;
	$sql=mysqli_query($con,"SELECT *FROM student_information WHERE id= '$student_portal_login_id'");
   	if($sql){
   		$sql_row=mysqli_num_rows($sql);
   		if($sql_row > 0){
   			//get the student detals
   			$row=mysqli_fetch_array($sql);
   			$number=$row['number'];
			
		}
	}
	//chk teller number
	$sql_chk=mysqli_query($con,"SELECT *FROM payments WHERE teller_no= '$teller'");
   	if($sql_chk){
   		$sql_chk_row=mysqli_num_rows($sql_chk);
   		if($sql_chk_row > 0){
   			echo "This payment Teller has already been submitted, Please Contact ICT for Help";
		}else{
			$M = mysqli_query($con,"INSERT INTO payments(student_id,matric_number,payment_type,session,depositors_name,payment_date,teller_no,bank,branch,status) values('$student_portal_login_id','$number','$payment_type','$session','$depositor','$payment_date','$teller','$bank','$branch','0') ");
		if($M){
			echo "Your Payment detail submited successful, Please wait for sometime while we confirm the payment";
		}else{
			echo "Something Went wrong, Please try again later";
		}
		
		
	}
		}
		
}


?>