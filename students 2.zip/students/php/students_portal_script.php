<?php

session_start();
if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['token']))
{
	//$username=mysql_real_escape_string($_POST['username']);
	//$password=md5(mysql_real_escape_string($_POST['password']));
	//echo $token=md5(mysql_real_escape_string($_POST['token']));
	
	$username=$_POST['username'];
	$password=md5($_POST['password']);
	$token=$_POST['token'];
	
	include_once("../include/connections.php");
	include_once("../include/actions.php");
	
}

?>