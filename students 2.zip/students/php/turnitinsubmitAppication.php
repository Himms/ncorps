<?php
session_start();
    include_once("../include/connections.php");
    include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
if(isset($_SESSION['student_portal_login_id'])){

    $student_portal_login_id= $_SESSION['student_portal_login_id'];
	$userType= $_SESSION['student_user_type'];
	$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
    }
    

    $sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND status='1'";
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
             $number=$get_Acc_detail['number'];
             
        }
    
    
    
    $amount="5";

    $pdate=date("Y/m/d");
    $sql=mysqli_query($con,"SELECT *FROM turnitin_programme WHERE student_email='$email'");
    if($sql){
        $sql_row=mysqli_num_rows($sql);
        if($sql_row == 0){
$M = mysqli_query($con,"INSERT INTO turnitin_programme(student_email,dateApplied) values('$email','$pdate')");
		if($M){
            //chk payment
           $sqlChkPayment=mysqli_query($con,"SELECT *FROM payments_".$current_session." WHERE payment_type='Turnitin Fee' AND number='$number'");
           if($sqlChkPayment){
                $sqlChkPaymentRow=mysqli_num_rows($sqlChkPayment);
                if($sqlChkPaymentRow == 0){
                    $sqlP=mysqli_query($con,"INSERT INTO payments_".$current_session." (number,payment_type,date_generated,amount) VALUES('$number','Turnitin Fee','$pdate','$amount')");
                }
           }
			echo '<b class="alert alert-danger" role="alert">Your Application has been submited Successfully, Please click on fee payment to make payment</b>';
		}else{
            echo '<b class="alert alert-danger" role="alert">Something Went wrong, Please try again later</b>';
		
		}
    }
}
?>