<?php
if(isset($_POST['phone_number']) && isset($_POST['matric_number']))
{
	$phone_number=$_POST['phone_number'];
	$matric_number=$_POST['matric_number'];
	
include_once("../include/connections.php");


$sql = "SELECT * FROM students WHERE number='$matric_number' AND phone_no='$phone_number' AND  user_status='0'";
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			 $row = mysqli_fetch_assoc($sql_run);
			$phone_no =$row['phone_no'];
			$id =$row['id'];
			
			$generated_password=1234;
			$pass=md5($generated_password);
			$sql_update="UPDATE students SET password='$pass' WHERE id='$id' AND number='$matric_number'";
			$sql_run_update = mysqli_query($con, $sql_update);
			
			if($sql_run_update){
				echo 'Password sent to your Phone number';
			}
		}else{
			echo 'Password Reset not Successfully done, please check the details';
		}
		mysqli_close($con);
}

?>