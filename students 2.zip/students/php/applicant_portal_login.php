<?php

session_start();
if(isset($_POST['username']) && isset($_POST['password']))
{
	$un=$_POST['username'];
	$pass=md5($_POST['password']);
//	$token=$_POST['token'];
	//get project detal
	include_once("../include/connections.php");
	//include_once('../include/get_project_details.php');
	
		include_once("../include/connections.php");
		$sql = "SELECT *FROM applicants WHERE number='$un' AND password='$pass' AND  user_status='1'";
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			 $row = mysqli_fetch_assoc($sql_run);
			$_SESSION['applicant_portal_login_id']=$row['id']; //Storing user session value.
			echo "1";
		}else{
			echo "0";
		}
		mysqli_close($con);
}

?>
