 <?php
        $phoneNumber=$_POST['phoneNumber'];
        $number=$_POST['mat'];
        $password1=$_POST['password1'];
        $email=$_POST['email'];
        
 
 
	include_once("../include/connections.php");
	
$dbServerName = "portals.ibbu.edu.ng";
$dbUsername = "portalsi_syncdba";
$dbPassword = "765QWE119ssjXxxX";
$dbName = "portalsi_UGRegSyncDB";

$project_id='3';

// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


    //chk if the student is a valid one
    
    $password1=md5($password1);
    
    //$sql_query=mysqli_query($conn,"SELECT * FROM student_payment_list");
    //$sql_query=mysqli_query($conn,"SELECT * FROM student_payment_list WHERE jamb_matric_no='$number'") or die(mysqli_error($conn));
	$sql_query=mysqli_query($conn,"SELECT * FROM student_biodata_registration WHERE matric_no='$number' AND telephone='$phoneNumber'");
    if($sql_query){
        $sql_query_row=mysqli_num_rows( $sql_query);
        if($sql_query_row > 0){
            //the student exist
			//register the student
			$get_details=mysqli_fetch_array($sql_query);
			$facultyid=$get_details['facultyid'];
			$deptid=$get_details['deptid'];
			$courseid=$get_details['courseid'];
			$contact_add=$get_details['contact_add'];
			$telephone=$get_details['telephone'];
		
			$gender_t=$get_details['gender_t'];
			$mstatus_t=$get_details['mstatus_t'];
			$dob_2=$get_details['dob_2'];
			$religion_t=$get_details['religion_t'];
			$countryid=$get_details['countryid'];
			$stateid=$get_details['stateid'];
			$lgaid=$get_details['lgaid'];
			$firstname=$get_details['firstname'];
			$othername=$get_details['othername'].' '.$get_details['surname'];
			
			$paddress=$get_details['perm_add'];
			$medication=$get_details['medication'];
			$bgroup_t=$get_details['bgroup_t'];
			$curr_s_level_t=$get_details['curr_s_level_t'];
			$sponsor_name=$get_details['sponsor_name'];
			$sponsor_add=$get_details['sponsor_add'];
			$course_duration=$get_details['course_duration'];
			$matric_no=$get_details['matric_no'];
			$jamb_no=$get_details['jamb_no'];
			
		    $hostel_eligibility='0';
		    $sponsor_add=str_replace("'","",$sponsor_add);
		    $paddress=str_replace("'","",$paddress);
		    $contact_add=str_replace("'","",$contact_add);
		    
		  //chk if the student has already created account or not
		    
            $sql_chk_student=mysqli_query($con,"SELECT *FROM students_2019_2020 WHERE number='$number'") or die(mysqli_error($con));
			if($sql_chk_student){
				$sql_chk_student_row=mysqli_num_rows($sql_chk_student);
				    
				    
				if($sql_chk_student_row > 0){
				    //this matric has already been used
				    echo'<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span>This Matric Number has already been Used</div>';
				}else{
				    //create account
				    $sql_addStudent=mysqli_query($con,"INSERT INTO students_2019_2020(number,programme_id,password,state_id,lga_id,gender,first_name,other_names,phone_no,dob,marital_status,email,address,permanent_address,medi,blood_type,sponsorship_name,sponsorship_address,project_id,hostel_eligibility,level) VALUES('$number','$courseid','$password1','$stateid','$lgaid','$gender_t','$firstname','$othername','$phone_number','$dob_2','$mstatus_t','$email','$contact_add','$paddress','$medication','$bgroup_t','$sponsor_name','$sponsor_add','$project_id','$hostel_eligibility','$curr_s_level_t')") or die(mysqli_error($con)) ;
					
					if($sql_addStudent){
					    
		$sql_chkLogin=mysqli_query($con,"SELECT *FROM user_login WHERE email='$email'") or die(mysqli_error($con));
			if($sql_chkLogin){
				$sql_chkLogin_row=mysqli_num_rows($sql_chkLogin);
				if($sql_chkLogin_row == 0){
				     $sqlAd=mysqli_query($con,"INSERT INTO user_login(email,password) VALUES('$email','$password1')") or die(mysqli_error($con)) ;
					if($sqlAd){
					     echo'<div class="alert alert-success pull-left" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only"></span>Your Account has been created Successfully, you can now login with your Email and Password</div>';
					}
				    
				}
			}			    
					    
					   
					
					}else{
					    echo'<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:Netword Issue, Please try again</span></div>';
					
					}
				}
			}
		    
		   
			
        }else{
            echo'<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span>Invalid Credentials, Note that 100 Level students should update their biodata to enable them create Accommodation Account.</div>';
		
        }
    }
    


 
 ?>
 
 
                
                
 
 
                
                