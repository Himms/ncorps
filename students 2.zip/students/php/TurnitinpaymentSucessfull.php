<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	}

	$TID=$_POST['TID'];
	$amont_paid=$_POST['total'];
	$payment_date=date('Y/m/d');
	
	$payment_status='1';
	
	$s=mysqli_query($con,"INSERT INTO turnitin_payments(TID,student_id,Amount,date_paid,status) VALUES('$TID','$student_portal_login_id','$amont_paid','$payment_date','1')") or die(mysqli_error($con));
	
	
?>