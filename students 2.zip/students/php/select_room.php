<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	}
$id = $student_portal_login_id;

include_once("get_user_profile.php");




$room_id = $_POST['room_id'];
$check_room = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_id'") ;
$rowis = mysqli_fetch_array($check_room);
$bed = $rowis['bedspace'];
$tit = $rowis['title'];
$site_id = $rowis['hostel_site'];
$block_id = $rowis['hostel_categories'];


$check_avail = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE room_id='$room_id' ");
$bed_allocated = mysqli_num_rows($check_avail);
$remainder = $bed - $bed_allocated;
if($remainder > 0){
	$check_avail_st = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE std_id ='$id'");
	if(mysqli_num_rows($check_avail_st ) > 0){
		echo "ALREADY ALLOCATED";
	}else{
		$M = mysqli_query($con,"INSERT INTO hostel_allocation(std_id,room_id,hostel_categories,hostel_site) values('$number','$room_id','$block_id','$site_id ') ");
		if($M){
			echo "Bedspace booked Successfully";
			$M = mysqli_query($con,"INSERT INTO payments_2019_2020(number,payment_type,date_generated,amount,status) values('$number','Accommodation Fee','$date_generated','12400','0') ");
		}
	}
}else{

	echo "TRY AGAIN";
}

?>