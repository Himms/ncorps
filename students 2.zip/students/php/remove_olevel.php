<?php
	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		$token=$_POST['token'];
		include_once("../include/connections.php");
		
		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
		
		$sql="DELETE FROM student_o_level_".$current_session." WHERE id='$token'";
		$sql_run=mysqli_query($con,$sql);	
		if($sql_run){
			echo "Record Removed Successfully";
		}
	}

	

?>