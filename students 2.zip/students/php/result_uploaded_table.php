<?php
//session_start();
$tr="";

include_once("../include/GetCurrentSession.php");
			$current_session=str_replace("/","_",$session_title);
	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	
		$student_id = $student_portal_login_id;
		
		include_once("../include/connections.php");
		
		
		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
			
		$sql  = "select * from student_o_level_".$current_session." WHERE student_id = '$student_id'";
		$query=mysqli_query($con,$sql);
		$r=mysqli_num_rows($query);
		if($r > 0){
			$sn = 1;
			while($rows = mysqli_fetch_array($query)){
				$olevel_id = $rows['id'];
				$exam_type = $rows['exam_type'];
				$exam_year = $rows['exam_year'];
				$exam_month = $rows['exam_month'];
				$sub_grade = $rows['sub_grade'];
				$subject_id = $rows['subject_id'];
				$exam_number = $rows['exam_number'];
				
				// get subject title
				$sql_query2 = mysqli_query($con,"select title from subjects where subject_id = '$subject_id'");
					while($title_array  = mysqli_fetch_array($sql_query2)){
							$subject_title = $title_array['title'];
					
						$tr .= '
							<tr>
								<td>'.$sn.'</td>
								<td>'.$exam_number.'</td>
								<td>'.$exam_type.'</td>
								<td>'.$exam_year.'</td>
								<td>'.$exam_month.'</td>
								<td>'.$subject_title.'</td>
								<td>'.$sub_grade.'</td>
								<td><a style="color:red;" href="#" onclick="remove_olevel('.$olevel_id.')">Remove</a></td>
							</tr>
						';
						
					}
				$sn++;
			}
		}
		
	}

?>

	<table class="table table-bordered">
			<thead>
					<tr>
						<th colspan="7">#</th>
					</tr>
				</thead>
			<tbody>
					<?php echo $tr; ?>
			</tbody>
			
	</table>