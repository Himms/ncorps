<?php

		//session don start already
	if(isset($_SESSION['applicant_portal_login_id'])){
		$student_portal_login_id= $_SESSION['applicant_portal_login_id'];
	}

	include_once("../include/connections.php");
		$sql = "SELECT *FROM applicants WHERE id='$student_portal_login_id'";
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			 $record = mysqli_fetch_assoc($sql_run);
			$id=$record['id']; 
		//$reg_no=$record['number'];
		$img=$record['image'];
		$number=$record['number'];
		$program=$record['programme_id'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$first_name=$first_name.' '.$other_names;
		$level=$record['level'];
		$project_id=$record['project_id'];
		
		$query=mysqli_query($con,"SELECT title,department_id FROM programmes WHERE id='$program'");
		$row=mysqli_fetch_assoc($query);
		$course=$row['title'];
		$department=$row['department_id'];
		//$address=$row['address'];
		
		$query=mysqli_query($con,"SELECT title FROM students_departments WHERE id='$department'");
		$row=mysqli_fetch_assoc($query);
		$department=$row['title'];
		
		
		
		$maritalstatus=$record['marital_status'];
		$gender=$record['gender'];
		$medication=$record['medi'];
		$H_status=$record['H_status'];
		$std_date=$record['dob'];
		$email=$record['email'];
		$address=$record['address'];
		$phone_no=$record['phone_no'];
		$sponsorship_name=$record['sponsorship_name'];
		$sponsorship_address=$record['sponsorship_address'];
		$sponsorship_number=$record['sponsor_number'];
		$state=$record['state_id'];
		$query=mysqli_query($con,"SELECT title FROM state WHERE id='$state'");
		$row=mysqli_fetch_assoc($query);
		$state=$row['title'];
		
		$lga=$record['lga_id'];
		$query=mysqli_query($con,"SELECT title FROM lga WHERE id='$lga'");
		$row=mysqli_fetch_assoc($query);
		$lga=$row['title'];
		$status=$record['marital_status'];
		$medication=$record['medi'];
		$blood_group=$record['blood_type'];
		$disability=$record['disability'];
		$mat_no=$record['number'];
		
		
		$permenat_address=$record['permanent_address'];
		//$state_title=$record['state_title'];
		//$lga_title=$record['lga_title'];
		$religion=$record['religion'];
		
		
		$kin_address=$record['kin_address'];
		$kin_phone_number=$record['kin_phone_number'];
		$kin_relationship=$record['kin_relationship'];
		$kin_name=$record['kin_name'];
		
		
		$state_title="";
		$lga_title="";
		}
				
	
	
$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$header_image=$row['header_image'];
					$crf_image=$row['crf_image'];
					
					$header_image='images/'.$header_image;
					$crf_image='images/'.$crf_image;
				}
			}
		}
			

?>