<?php
		session_start();
	include_once("../include/connections.php");
		
		
		$state = $_POST['state'];
		$sql_get_state=mysqli_query($con,"SELECT *FROM state WHERE title = '$state'");
		if($sql_get_state){
			$sql_get_state_row = mysqli_num_rows($sql_get_state);
			if($sql_get_state_row > 0){
						if($state_row=mysqli_fetch_assoc($sql_get_state)){
							$state_id = $state_row['id'];

						}
					}
		}
		
		
		$sql_get_staff=mysqli_query($con,"SELECT *FROM lga WHERE state_id = '$state_id' ORDER BY title ");
				if($sql_get_staff){
					$sql_get_staff_row=mysqli_num_rows($sql_get_staff);
					if($sql_get_staff_row > 0){
					echo '<option>---SELECT LOCAL GOVERNMENT---<option>';
						while($news_row=mysqli_fetch_assoc($sql_get_staff)){
							$title = $news_row['title'];
							echo '<option>'.$title.'<option>';
						}
					}
				}
	
	?>