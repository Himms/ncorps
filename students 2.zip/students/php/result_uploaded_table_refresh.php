<?php
$tr="";
session_start();
	if(isset($_SESSION['applicant_portal_login_id'])){
		$student_portal_login_id= $_SESSION['applicant_portal_login_id'];
	
		$student_id = $student_portal_login_id;
		
		include_once("../include/connections.php");
		
		$sql_query = mysqli_query($con,"select * from student_o_level_result_table WHERE student_id = '$student_id' ORDER BY id DESC");
		if(mysqli_num_rows($sql_query) > 0){
			$sn = 1;
			while($rows = mysqli_fetch_array($sql_query)){
				$exam_type = $rows['exam_type'];
				$exam_year = $rows['exam_year'];
				$exam_month = $rows['exam_month'];
				$sub_grade = $rows['sub_grade'];
				$subject_id = $rows['subject_id'];
				
				// get subject title
				$sql_query2 = mysqli_query($con,"select title from subjects where subject_id = '$subject_id'");
					while($title_array  = mysqli_fetch_array($sql_query2)){
							$subject_title = $title_array['title'];
					
						$tr .= '
							<tr>
								<td>'.$sn.'</td>
								<td>'.$exam_type.'</td>
								<td>'.$exam_year.'</td>
								<td>'.$exam_month.'</td>
								<td>'.$subject_title.'</td>
								<td>'.$sub_grade.'</td>
								<td>Remove</td>
							</tr>
						';
						
					}
				$sn++;
			}
		}
		
	}

?>

	<table class="table table-bordered">
			<thead>
					<tr>
						<th colspan="7">#</th>
					</tr>
				</thead>
			<tbody>
					<?php echo $tr; ?>
			</tbody>
			
	</table>