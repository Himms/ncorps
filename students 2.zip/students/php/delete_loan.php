<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		$token=$_POST['token'];
		
	}
$id = $student_portal_login_id;
	
$M = mysqli_query($con,"DELETE FROM student_loan_application WHERE loan_id='$token'") or die(mysqli_error($con));
		if($M){
			echo "Loan Applicated was deleted Successfully";
		}else{
			echo "Something Went wrong, Please try again later";
		}

?>