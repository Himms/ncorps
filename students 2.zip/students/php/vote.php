<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_id= $_SESSION['student_portal_login_id'];
		
	}
	
	$office_id=$_POST['office_id'];
	$candidate_id=$_POST['candidate_id'];
	



$sql_chkVoted=mysqli_query($con,"SELECT *FROM votes WHERE student_id='$student_id' AND office_id='$office_id'");
	if($sql_chkVoted){
		$sql_chkVotedRow=mysqli_num_rows($sql_chkVoted);
		if($sql_chkVotedRow == 0){
			
			$M = mysqli_query($con,"INSERT INTO votes(student_id,office_id,candidate_id,date_time) values('$student_id','$office_id','$candidate_id',now())") or die(mysqli_error($con));
		if($M){
			echo '<div class="alert alert-success" role="alert">
			Your vote has been submited successfully, you can now proceed to the next office
			</div>';
		}else{
			echo "Something Went wrong, Please try again later";
		}
		}
	}



?>