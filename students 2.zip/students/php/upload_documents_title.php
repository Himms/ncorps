<?php
	<?php
		session_start();
		$student_portal_login_id= $_SESSION['applicant_portal_login_id'];
	?>
	
		if(isset($_POST['document_title'])){
			
			include_once("../include/connections.php");
			//set default student_id for testing
			$student_id = $student_portal_login_id;
			$document_title = mysqli_real_escape_string($con,$_POST['document_title']);
			$document_title = strtoupper($document_title);
			
		
						$insert_sql  = "insert into students_doc (student_id,document_title,date_uploaded) values('$student_id','$document_title',now())";
						$insert_query = mysqli_query($con,$insert_sql);
								if($insert_query){
									echo 'file is uploaded....';
									
								}else{
									echo 'File upload failed...';
								}
			
				
				
				}else{
						echo 'not posted..';		
				}
	
?>