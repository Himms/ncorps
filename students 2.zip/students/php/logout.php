<?php
	session_start();
	 unset($_SESSION['student_portal_login_id']);
	if(!isset($_SESSION['student_portal_login_id'])){
		echo "1";
	}
?>