<?php
session_start();
$tr="";
include_once("../include/connections.php");
include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
		if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	
		$student_id = $student_portal_login_id;
		
		include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
		
		
		$s="select * from  other_certificate_uploads_".$current_session." where student_id = '$student_id'";
		$sql_query = mysqli_query($con,$s);
		$row_number=mysqli_num_rows($sql_query);
		if( $row_number > 0){
			$sn = 1;
			while($rows = mysqli_fetch_array($sql_query)){
				$document_id = $rows['document_id'];
				$certificate_type = $rows['certificate_type'];
				$images = $rows['images'];
		
						$tr .= '
							<tr>
								<td>'.$sn.'</td>
								<td>'.$certificate_type.'</td>
								<td class="text-center"><img width="10%" src="document_uploads_'.$current_session.'/'.$images.'"></td>
								<td class="text-center"><a style="color:red;" href="#" onclick="remove_certificate('.$document_id.')">Remove</td>
							</tr>
						';
						
					
				$sn++;
			}
		}else
		{
			echo 'No document is uplaoded yet..';
		}
		
	}

?>

	<table class="table table-bordered">
			<thead>
					<tr>
						<th>#</th>
						<th class="text-center">Document Title</th>
						<th class="text-center">Date Uplaoded</th>
						<th></th>
					</tr>
				</thead>
			<tbody>
					<?php echo $tr; ?>
			</tbody>
			
	</table>
	
	