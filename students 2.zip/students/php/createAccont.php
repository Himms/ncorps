<?php
	include_once("../include/connections.php");
	$email=$_POST['email'];
	$gender=$_POST['gender'];
	$phone_number=$_POST['phone_number'];
	$password1=md5($_POST['password1']);
	$password2=$_POST['password2'];
	$last_ip='';
	//if the email has been used or not
	$sql_email = "SELECT *FROM user_information WHERE email='$email'";
		$sql_run = mysqli_query($con, $sql_email);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){	
			echo "Email already exist";
		}else{
			//chk phone number
		$sql_phone_number = "SELECT *FROM user_information WHERE phone_no='$phone_number'";
		$sql_run = mysqli_query($con, $sql_phone_number);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){	
			echo "Phone Number already exist";
		}else{
			//create user account
			$sql_createAccount=mysqli_query($con,"INSERT INTO user_information(phone_no,email,gender) VALUES('$phone_number','$email','$gender')");
			if($sql_createAccount){
				$insertLoginDetailes=mysqli_query($con,"INSERT INTO user_login_info(user_name,password,last_ip,last_login_time_date) VALUES('$email','$password1','$last_ip',now())");
				//log the user in 
				if($insertLoginDetailes){
					echo "Your Account has been Created Successfully, You can now Sing in";
				}
			}
		}
}
		
	
?>