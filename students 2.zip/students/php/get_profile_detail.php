<?php
	//chk the user type
	include_once('get_user_profile.php');

?>