<?php
	
$mat=$_POST['mat'];
$number=$_POST['mat'];
$email=$_POST['email'];
$phone_number=$_POST['phone_number'];
$tid_type=$_POST['tid_type'];
$surname=$_POST['surname'];
$othernames=$_POST['othernames'];

$mydate=getdate(date("U"));
$dt= "$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]";

//get current session
$session="2016-2017";

//get fee amont
$amount="40,000";
$curent_year="2017";

//chk is the student exist of not from the student table
if(!empty($mat) && !empty($email) && !empty($phone_number)){
	include_once("../include/connections.php");
	$sql = "SELECT *FROM students WHERE number='$mat'";
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){	
			$record = mysqli_fetch_assoc($sql_run);
			$email=$record['email'];
			$phone_no=$record['phone_no'];
			$student_id=$record['id'];
			//The student Exist then
			//chk if the TID has been generated or not
			$sql = "SELECT *FROM school_fee_payments WHERE student_id='$mat' AND session='$session' AND payment_type='$tid_type' AND session='$session'";
			$sql_select = mysqli_query($con, $sql);
			$no_of_rows=mysqli_num_rows($sql_select);
			if($no_of_rows=mysqli_num_rows($sql_select) > 0){
				//the Tid has been generated so print out
				include_once('dispalyTID.php');
				
			}else{
				//the Tid has not been generated, so generate and print out
				
				$tid="";
				$c1=mt_rand(1000,9000);
				$tid.=$mat.'-'.$c1;
				$tid.=$curent_year;
				
		$sql = "INSERT INTO school_fee_payments(student_id,session,payment_type,TID,amount,date_added) VALUES('$mat','$session','$tid_type','$tid','$amount','$dt')";
		$sql_run = mysqli_query($con,$sql);
		if($sql_run ){
				include_once('dispalyTID.php');
			}
		}
	}else{
		//the student do not exist so 
		//for now we will insert the student record and also generate the transaction id
		//this script will be deleted in the next version
		
		//insert student record
		$sql_insert=mysqli_query($con,"INSERT INTO students(number,email,phone_no,first_name,other_names) VALUES('$mat','$email','$phone_number','$surname','$othernames')");
		if($sql_insert){
			//generate TID and Display
				$tid="";
				$c1=mt_rand(1000,9000);
				$tid.=$mat.'-'.$c1;
				$tid.=$curent_year;
				
		$sql = "INSERT INTO school_fee_payments(student_id,session,payment_type,TID,amount,date_added) VALUES('$mat','$session','$tid_type','$tid','$amount','$dt')";
		$sql_run = mysqli_query($con,$sql);
		if($sql_run ){
				include_once('dispalyTID.php');
			}
		}else{
					echo'
			 <div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  	Sorry, Something went wrong,we could not generate your TID, Please try again
</div>
			 ';
		}
	}
}	

?>


 <hr/><center><a href="">Click here to go back</a> || <a href="#" onclick="printContent('print')">Click here to Print</a> </center>