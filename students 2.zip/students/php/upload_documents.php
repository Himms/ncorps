<?php
error_reporting(0);
session_start();
include_once("../include/connections.php");
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$email= $_SESSION['email'];
	

$target_dir = "../../uploads/";
$target_file = rand(10,100).$student_portal_login_id.'.pdf';
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
	$project_topic=$_POST['project_topic'];
	$abstract=$_POST['abstract'];
	
  $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
  $uploadOk = 1;
}


// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.";
  $uploadOk = 0;
  die();
}

// Allow certain file formats
if($imageFileType != "pdf" ) {
  echo "Sorry, only PDF files are allowed.";
  $uploadOk = 0;
  die();
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
die();
} else {
	
  if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir.$target_file)) {
    echo "The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.";
	
	//chk if inserted
	$sqlChk=mysqli_query($con,"SELECT *FROM student_project WHERE student_id='$student_portal_login_id'");
	if($sqlChk){
		$sqlChkRow=mysqli_num_rows($sqlChk);
		if($sqlChkRow > 0){
			//update
			$sqlUpdate=mysqli_query($con,"UPDATE student_project SET topic='$project_topic',file='$target_file',abstract='$abstract' WHERE student_id='$student_portal_login_id'");
		}else{
			//insert
			$sql_Insert=mysqli_query($con,"INSERT INTO student_project(topic,file,student_id,abstract) VALUES('$project_topic','$target_file','$student_portal_login_id','$abstract')");
		}
	}
    
    
    
  } else {
    echo "Sorry, there was an error uploading your file.";
    die();
  }
}


?>
