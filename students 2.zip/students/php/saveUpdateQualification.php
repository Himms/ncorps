<?php
	session_start();
	$token=$_POST['token'];
	
	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		
		include_once("../include/connections.php");
		
		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
		
		
		$qualification=$_POST['qualification'];
		$specify=$_POST['specify'];
		$class_off_qualification=$_POST['class_off_qualification'];
		$institution=$_POST['institution'];
		$yearOfGraduation=$_POST['yearOfGraduation'];
		
		
		
		$sql="SELECT *FROM applicant_qualification_".$current_session." WHERE applicant_id='$token'";
		$sql_run=mysqli_query($con,$sql);	
		if($sql_run){
			$row=mysqli_num_rows($sql_run);
			if($row == 0){
				//insert
				$sqlInsert="INSERT INTO applicant_qualification_".$current_session."(qualification,applicant_id,institution,year_of_graduation,class_of_result,specify) VALUES('$qualification','$student_portal_login_id','$institution','$yearOfGraduation','$class_off_qualification','$specify')";
				$sqlInsert_run=mysqli_query($con,$sqlInsert);
				if($sqlInsert_run){
					echo "Record Saved Successfully";
				}
			}else{
				//update
				$sqlInsert="UPDATE applicant_qualification_".$current_session." SET qualification='$qualification',applicant_id='$student_portal_login_id',institution='$institution',year_of_graduation='$yearOfGraduation',class_of_result='$class_off_qualification',specify='$specify'";
				$sqlInsert_run=mysqli_query($con,$sqlInsert) or die(mysqli_error($con));
				if($sqlInsert_run){
					echo "Record Saved Successfully";
				}
			}
		}
	}

	

?>