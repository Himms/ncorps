<?php
	include_once("../include/connections.php");
	$number=$_POST['number'];
	$email=$_POST['email'];
	$password1=$_POST['password1'];

	$last_ip='';
	
$dbServerName = "portals.ibbu.edu.ng";
$dbUsername = "portalsi_syncdba";
$dbPassword = "765QWE119ssjXxxX";
$dbName = "portalsi_UGRegSyncDB";

$project_id='3';

// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


    //chk if the student is a valid one
    

    //$sql_query=mysqli_query($conn,"SELECT * FROM student_payment_list");
    //$sql_query=mysqli_query($conn,"SELECT * FROM student_payment_list WHERE jamb_matric_no='$number'") or die(mysqli_error($conn));
	$sql_query=mysqli_query($conn,"SELECT * FROM student_biodata_registration WHERE matric_no='$number'");
    if($sql_query){
        $sql_query_row=mysqli_num_rows( $sql_query);
        if($sql_query_row > 0){
            //the student exist
			//register the student
			$get_details=mysqli_fetch_array($sql_query);
			$facultyid=$get_details['facultyid'];
			$deptid=$get_details['deptid'];
			$courseid=$get_details['courseid'];
			$contact_add=$get_details['contact_add'];
			$telephone=$get_details['telephone'];
		
			$gender_t=$get_details['gender_t'];
			$mstatus_t=$get_details['mstatus_t'];
			$dob_2=$get_details['dob_2'];
			$religion_t=$get_details['religion_t'];
			$countryid=$get_details['countryid'];
			$stateid=$get_details['stateid'];
			$lgaid=$get_details['lgaid'];
			$firstname=$get_details['firstname'];
			$othername=$get_details['othername'].' '.$get_details['surname'];
			
			$paddress=$get_details['perm_add'];
			$medication=$get_details['medication'];
			$bgroup_t=$get_details['bgroup_t'];
			$curr_s_level_t=$get_details['curr_s_level_t'];
			$sponsor_name=$get_details['sponsor_name'];
			$sponsor_add=$get_details['sponsor_add'];
			$course_duration=$get_details['course_duration'];
			$matric_no=$get_details['matric_no'];
			$jamb_no=$get_details['jamb_no'];
			
		    $hostel_eligibility='0';
		    
		    $las4D=substr($telephone,-4);
		    $las2D=substr($telephone,0,2);
		    
		    $no=str_replace("/","_",$number);
		    
		    
		       
		    echo '	<div style="width:100%">
		 <div class="form-group">
    <label for="password" style="float:left;">Enter your Phone number that ends with '.$las2D.'* **** '.$las4D.'</label>
    <input type="text" class="form-control" id="phoneNumber" placeholder="Enter Phone Number">
    <input type="hidden" class="form-control" id="mat" value="'.$number.'">
    <input type="hidden" class="form-control" id="password1" value="'.$password1.'">
    <input type="hidden" class="form-control" id="email" value="'.$email.'">
  </div>
  <div class="modal-footer">
        <div id="proceed"></div>
        <a href="#" class="btn btn-success" onclick="ActivateAccount()">Activate Account</a>
        <a class="btn btn-primary" href="https://ibbu.edu.ng/accommodation/manage/done.php?token=812ed4562d3211363a7b813aa9cd2cf042b63bb2tt256e8190e474aatt256e8190e474aa">Close </a>
      </div>
		</div>';
		    
		   
			
        }else{
            echo'<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span>Invalid Matric Number, Note that 100 Level students should update their biodata to enable them create Accommodation Account.</div>';
		
        }
    }
    

?>