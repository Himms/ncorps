<?php
error_reporting(0);
	session_start();
	include_once("../include/connections.php");
	$student_id=$_SESSION['student_portal_login_id'];
	//$project_id=$_SESSION['project_id'];
	
	//include_once("../include/get_project_details_with_id.php");
	
		$maritalstatus=$_POST['maritalstatus'];
		$first_name=$_POST['first_name'];
		$other_name=$_POST['other_name'];
		$email=$_POST['email'];
		//$name_of_guardian=$_POST['name_of_guardian'];
		//$no_guardian=$_POST['no_guardian'];
		//$address_gaurdian=$_POST['address_gaurdian'];
		$dob=$_POST['dob'];
		
		$H_status=$_POST['H_status'];
		$medication=$_POST['medication'];
		//echo $H_status;
		$disability=$_POST['disability'];
		$blood_type=$_POST['blood_type'];
		$gender=$_POST['gender'];
		$phone_no=$_POST['phone_no'];
		$address=$_POST['address'];
		
		
		$stateid=$_POST['state'];
		$lga=$_POST['lga'];
		
		$query=mysqli_query($con,"SELECT *FROM state WHERE title='$stateid'");
		$row=mysqli_fetch_assoc($query);
		$state_id=$row['id'];
		
		
		$query=mysqli_query($con,"SELECT * FROM lga WHERE title='$lga'");
		$row=mysqli_fetch_assoc($query);
		$lga_id=$row['id'];
		
		$permenat_address=$_POST['permenat_address'];
		$kin_name=$_POST['kin_name'];
		$kin_relationship=$_POST['kin_relationship'];
		$kin_phone_number=$_POST['kin_phone_number'];
		$kin_address=$_POST['kin_address'];
		

		include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	//get user_acc_details
	$user_type=$_POST['user_type'];
	if($user_type==1){
		$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND status='1'";
	}elseif($user_type==0){
		$sql = "SELECT *FROM applicants_".$current_session." WHERE email='$email' AND user_status='1'";
	}
	

		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			 
			 $mat_year=substr($number,0,3);
			 
			 if($image==''){
				 $pic='0.jpg';
			 }else{
				 $pic=$image;
			 }
		}
	
	
		
		
		if($user_type=="0"){
			$query="SELECT *FROM applicants_".$current_session." WHERE project_id='$project_id' AND number !='' ";
			$sql_chk=mysqli_query($con,$query) or die(mysqli_error($con));
					if($sql_chk){
						$sql_chk_row=mysqli_num_rows($sql_chk);
					
						if($sql_chk_row > 0){
							
							$n =$sql_chk_row + 1;
							
						}else{
							
							$n=1;
						}
					if($n < 10){
						$n="000".$n;
					}elseif($n < 100){
						$n="00".$n;
					}elseif($n < 1000){
						$n="0".$n;
					}elseif($n < 10000){
						$n=$n;
					}
					
					//gett project code
					
					//gett session year code
					 $dt_y=date("Y");
					 
					  $dty=date("m-d-Y");
					 
					
					 
					 //get application number generation formart
					 
					$n=$project_code.'/IMS/'.$dt_y.'/'.$n;
		
		
			
			if($number==""){
				$course=$_POST['course']; 
				$sql="UPDATE applicants_".$current_session." SET number='$n',lga_id='$lga_id',state_id='$state_id',kin_address='$kin_address',kin_phone_number='$kin_phone_number',kin_relationship='$kin_relationship',kin_name='$kin_name',permanent_address='$permenat_address',phone_no='$phone_no',marital_status='$maritalstatus',gender='$gender',dob='$dob',address='$address',sponsorship_name='$name_of_guardian',sponsorship_address='$address_gaurdian',medi='$medication',H_status='$H_status',disability='$disability',blood_type='$blood_type',sponsor_number='$no_guardian',programme_id='$course' WHERE email='$email'";
				//insert paymentType
				//chk if the fee payment is inserted or not
				//get amount payable
				
			$sql_get_set_payment_fee=mysqli_query($con,"SELECT *FROM programmes WHERE project_id='$project_id' AND id='$course'");
			if($sql_get_set_payment_fee){
				$sql_get_set_payment_fee_row=mysqli_num_rows($sql_get_set_payment_fee);
				if($sql_get_set_payment_fee_row > 0){
				$row=mysqli_fetch_assoc($sql_get_set_payment_fee);
				$amount=$row['programme_application_fee'];
				$amount=$amount + 400;
				
				}
			}
				
			}else{
				$sql="UPDATE applicants_".$current_session." SET lga_id='$lga_id',state_id='$state_id',kin_address='$kin_address',kin_phone_number='$kin_phone_number',kin_relationship='$kin_relationship',kin_name='$kin_name',permanent_address='$permenat_address',phone_no='$phone_no',marital_status='$maritalstatus',gender='$gender',dob='$dob',address='$address',sponsorship_name='$name_of_guardian',sponsorship_address='$address_gaurdian',medi='$medication',H_status='$H_status',disability='$disability',blood_type='$blood_type',sponsor_number='$no_guardian' WHERE email='$email'";
			}
			
			if($number==""){
				$sqlP="SELECT *FROM payments_".$current_session." WHERE number='$n' AND payment_type='Application Fee'";
				$nn=$n;
			}else{
				$sqlP="SELECT *FROM payments_".$current_session." WHERE number='$number' AND payment_type='Application Fee'";
				$nn=$number;
			}
				$sql_chkPayment=mysqli_query($con,$sqlP) ;
				if($sql_chkPayment){
					$sql_chkPayment_row=mysqli_num_rows($sql_chkPayment);
					if($sql_chkPayment_row == 0){
						//insert
						$sqlInsertP="INSERT INTO payments_".$current_session." (number,payment_type,amount,date_generated) VALUES('$nn','Application Fee','$amount','$dty')";
						$sqlRun=mysqli_query($con,$sqlInsertP);
					}
				}
			
			}
		}else{
			$sql="UPDATE students_".$current_session." SET kin_address='$kin_address',kin_phone_number='$kin_phone_number',kin_relationship='$kin_relationship',kin_name='$kin_name',permanent_address='$permenat_address',phone_no='$phone_no',marital_status='$maritalstatus',gender='$gender',dob='$dob',address='$address',sponsorship_name='$name_of_guardian',sponsorship_address='$address_gaurdian',medi='$medication',H_status='$H_status',disability='$disability',blood_type='$blood_type',sponsor_number='$no_guardian' WHERE email='$email'";
		}
		
		
		$query=mysqli_query($con,$sql) or die(mysqli_error($con));
		
		if($query){
			echo '<h4 style="color:green">Profile updated successfully</h4>';
		}
		
		
?>