<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	}
$id = $student_portal_login_id;

include_once("../include/GetCurrentSession.php");
$current_session=str_replace("/","_",$session_title);

include_once("get_user_profile.php");


	$txref=$_POST['txref'];
	$amont_paid=$_POST['total'];
	$payment_date=date("Y/m/d");
	//$payment_type='Accommodation Fee';
	$payment_status='1';
	
	$sql="UPDATE payments_".$current_session." SET status='1',payment_date='$payment_date' WHERE number='$number'";
	$sql_update=mysqli_query($con,$sql);
	
	//chk if the student has gotten admission
	$userType= $_SESSION['student_user_type'];
	if($userType=="0"){
		//chk if the student has paid acceptance fee
		$sqlPayment=mysqli_query($con,"SELECT *FROM payments_".$current_session." WHERE number='$number' AND payment_type='Acceptance Fee' AND status='1'");
			if($sqlPayment){
				$sqlPayment_row=mysqli_num_rows($sqlPayment);
				if($sqlPayment_row > 0){
					//insert
					$chk=mysqli_query($con,"SELECT *FROM payments_".$current_session." WHERE number='$number' AND payment_type='School Fee'");
					if($chk){
						$chk_row=mysqli_num_rows($chk);
						if($chk_row == 0){
							$s=mysqli_query($con,"INSERT INTO payments_".$current_session."(number,payment_type,amount) VALUES('$number','School Fee','1')");
						}
					}
					
				}
			}
			
			
		//chk if the student has paid acceptance fee
		$sqlPayment=mysqli_query($con,"SELECT *FROM payments_".$current_session." WHERE number='$number' AND payment_type='School Fee' AND status='1'");
			if($sqlPayment){
				$sqlPayment_row=mysqli_num_rows($sqlPayment);
				if($sqlPayment_row > 0){
					//insert
					$chk=mysqli_query($con,"SELECT *FROM students_".$current_session." WHERE matric_no='$number'");
					if($chk){
						$chk_row=mysqli_num_rows($chk);
						if($chk_row == 0){
							$sql="INSERT INTO students_".$current_session." (programme_id,matric_no,country_id,state_id,lga_id,surname,first_name,other_names,phone_no,gender,dob,medi,marital_status,username,password,email,address,permanent_address,image,blood_type,disability,mode_of_entry,user_status,place_of_birth,level,H_status,validity_status,sponsorship_name,sponsorship_address,sponsor_number,kin_name,kin_phone_number,kin_address,kin_relationship,project_id) SELECT programme_id,matric_no,country_id,state_id,lga_id,surname,first_name,other_names,phone_no,gender,dob,medi,marital_status,username,password,email,address,permanent_address,image,blood_type,disability,mode_of_entry,user_status,place_of_birth,level,H_status,validity_status,sponsorship_name,sponsorship_address,sponsor_number,kin_name,kin_phone_number,kin_address,kin_relationship,project_id FROM applicants_".$current_session;
							mysqli_query($sql,$con) or die(mysqli_error($con));
							
							//$sqlUpdate=mysqli_query($con,"UPDATE user_login SET user_type='1' WHERE email='$email'");
						}
					}
					
				}
			}
	}
	
	
?>