<?php

		include_once("../include/connections.php");
		$sql = "SELECT *FROM school_fee_payments WHERE student_id='$number'";
			$sql_select = mysqli_query($con, $sql);
			$no_of_rows=mysqli_num_rows($sql_select);
			if($no_of_rows=mysqli_num_rows($sql_select) > 0){
				$data = mysqli_fetch_assoc($sql_select);
					$TID=$data['TID'];
					$student_id=$data['student_id'];
					$session=$data['session'];
					$payment_status=$data['payment_status'];
					$payment_type=$data['payment_type'];
					$date_added=$data['date_added'];
					$amount=$data['amount'];
					
	$sql = "SELECT *FROM students WHERE number='$number'";
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){	
			$record = mysqli_fetch_assoc($sql_run);
			
			$first_name=$record['first_name'];
			$other_names=$record['other_names'];
			$phone_no=$record['phone_no'];
			$email=$record['email'];
		}
					
echo'<div class="list-group" style="font-size:20px;">
  <a href="#" class="list-group-item disabled">
    Your Transaction Details : 
  </a>
  <a href="#" class="list-group-item">MATRIC NUMBER: '.$number.' </a>
   <a href="#" class="list-group-item">SURNAME: '.$first_name.' </a>
    <a href="#" class="list-group-item">OTHER NAMES: '.$other_names.' </a>
  <a href="#" class="list-group-item">PHONE NUMBER: '.$phone_no.'</a>
  <a href="#" class="list-group-item">EMAIL: '.$email.'</a>
  <a href="#" class="list-group-item">TID: '.$TID.'</a>
   <a href="#" class="list-group-item">TID TYPE: '.$payment_type.'</a>
  <a href="#" class="list-group-item">AMOUNT: '.$amount.'</a>
   <a href="#" class="list-group-item">DATE: '.$date_added.'</a>
 
</div>';
				
				
			}else{
			echo'
			 <hr/> <div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
		There was a problem with your request, Please try again.

</div>
			 ';
			
			}
			

?>