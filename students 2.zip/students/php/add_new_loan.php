<?php
session_start();
	include_once("../include/connections.php");
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		$loan_title=$_POST['loan_type'];
		$amount_needed=$_POST['amount_needed'];
		$date_applied=date("dd-mm-yy");
	}
$id = $student_portal_login_id;
	$sql=mysqli_query($con,"SELECT *FROM students WHERE id= '$student_portal_login_id'");
   	if($sql){
   		$sql_row=mysqli_num_rows($sql);
   		if($sql_row > 0){
   			//get the student detals
   			$row=mysqli_fetch_array($sql);
   			$number=$row['number'];
			
		}
	}

$M = mysqli_query($con,"INSERT INTO student_loan_application(student_id,loan_title,session,amount_needed,date_applied) values('$number','$loan_title','2017/2018','$amount_needed','$date_applied ') ");
		if($M){
			echo "Your Request has been Submited, Kindly wait for sometime";
		}else{
			echo "Something Went wrong, Please try again later";
		}

?>