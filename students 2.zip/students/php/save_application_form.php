<?php

	session_start();
	include_once("../include/connections.php");
	//get user_acc_details
	
	$program=$_POST['program'];
	
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$programme_id=$program;
	
	$sql_get_programmes_details=mysqli_query($con,"SELECT *FROM programmes WHERE id='$program'");
		if($sql_get_programmes_details){
			$sql_get_programmes_details_row=mysqli_num_rows($sql_get_programmes_details);
			if($sql_get_programmes_details_row > 0){
				$get_details=mysqli_fetch_array($sql_get_programmes_details);
					$department_id=$get_details['department_id'];
					$programme_application_fee=$get_details['programme_application_fee'];
			}
		}
		
		
	//update student programme
	$sql_save=mysqli_query($con,"UPDATE user_information SET department_id='$department_id',programme_id='$programme_id' WHERE id='$student_portal_login_id'");

	if($sql_save){
		//generate payment details
		$mydate=getdate(date("U"));
		$dt= "$mydate[weekday], $mydate[month] $mydate[mday], $mydate[year]";
		$c1=mt_rand(20,99);
		$c2=mt_rand(1000,9000);
		$c3=mt_rand(1,9);
		
		$tid=$c1.$c2.$c3;
		$payment_for="Application Form";
		
		
		
		//chk if the tid is generated or not
		$sql_chk_tid=mysqli_query($con,"SELECT *FROM payments WHERE student_id='$student_portal_login_id' AND payment_for='$payment_for'") or die(mysqli_error($con));
		if($sql_chk_tid){
			$chk_tid_row=mysqli_num_rows($sql_chk_tid);
			if($chk_tid_row == 0){
				$sql_payments=mysqli_query($con,"INSERT INTO payments(student_id,payment_for,transaction_id,date_generated,amont_paid) VALUES('$student_portal_login_id','$payment_for','$tid','$dt','$programme_application_fee')");
			}else{
				//update
				$sql_update=mysqli_query($con,"UPDATE payments SET amont_paid='$programme_application_fee' WHERE student_id='$student_portal_login_id'");
				
			}
		}
		
		
		echo '<b style="color:green">Your Application has been Saved Successfully, Click on the payment link to see your payment Details<b><br/><hr/>';
	}
?>