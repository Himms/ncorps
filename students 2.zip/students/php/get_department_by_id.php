<?php

	include_once("../include/connections.php");
	$sql = "SELECT *FROM students_departments WHERE id='$department_id'";
		$sql_run = mysqli_query($con, $sql) or die(mysql_error());
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			 $record = mysqli_fetch_assoc($sql_run);
			 $department_title=$record["title"];
			}
	
	mysqli_close($con);

?>