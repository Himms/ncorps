<?php
	session_start();
	$student_portal_login_id=$_SESSION['student_portal_login_id'];
	
		
	
	

	 unset($_SESSION['student_portal_login_id']);
	 header("location:index.php?token=812ed4562d3211363a7b813aa9cd2cf042b63bb2tt256e8190e474aatt256e8190e474aa");
	
?>