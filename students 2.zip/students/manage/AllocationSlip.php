<?php 
error_reporting(0);
session_start();
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		$userType= $_SESSION['student_user_type'];
	$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
	}else{
		header('location:logout.php');
	}
	

	require_once('../fpdf/fpdf.php');
include_once('../include/connections.php');
include_once("../include/connections.php");
		include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND  status='1'";
		
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			 $record = mysqli_fetch_assoc($sql_run);
		$id=$record['id']; 
		$student_id=$record['id'];
		$img=$record['image'];
		$number=$record['number'];
		$surname=$record['surname'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$full_name=$surname.' '.$first_name.' '.$other_names;
		$project_id=$record['project_id'];
		$hostel_eligibility=$record['hostel_eligibility'];
		$maritalstatus=$record['marital_status'];
		$gender=$record['gender'];
		$medication=$record['medi'];
		$H_status=$record['H_status'];
		$std_date=$record['dob'];
		$email=$record['email'];
		$address=$record['address'];
		$phone_no=$record['phone_no'];
		$sponsorship_name=$record['sponsorship_name'];
		$sponsorship_address=$record['sponsorship_address'];
		$sponsorship_number=$record['sponsor_number'];
		$state=$record['state_id'];
		$programme_id=$record['programme_id'];
		$programmeid=$record['programme_id'];
		
		$token=$_GET['token'];
		$f=$_GET['f'];
		$sqlPayment="SELECT *FROM payments_".$current_session." WHERE number='$number' AND payment_type='Accommodation Fee' AND payment_date !=''";
		$sqlPaymentRun=mysqli_query($con,$sqlPayment) or die(mysqli_error($con));
		$sqlPaymentRunRow=mysqli_num_rows($sqlPaymentRun);
		if($sqlPaymentRunRow > 0){
			$r=mysqli_fetch_array($sqlPaymentRun);
				$payment_type=$r['payment_type'];
				$payment_info=$r['id'];
				$payment_id=$r['id'];
				$amount=$r['amount'];
				$paymentRef=$r['number'];
				$status=$r['status'];
				$payment_type=$r['payment_type'];
				
				
				$payment_date=$r['payment_date'];
				
				if($status=="0"){
					$c="red";
					$s="Pending";
				}else{
					$c="green";
					$s="Paid";
				}
			
		}
		
		if($userType==0){
			$search=$number;
		}else{
			$application_number=$record['application_number'];
			$search=$application_number;
		}
		
		//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM programmes WHERE id='$programme_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$course=$row['title'];
		$department_id=$row['department_id'];
		$programmetype=$row['type'];
		
		
		//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM students_departments WHERE id='$department_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$department=$row['title'];
		
		
		
		//$faculty=$record['faculty'];
		//$hostel_faculty=$record['faculty'];
		
		$query=mysqli_query($con,"SELECT title FROM state WHERE id='$state'");
		$row=mysqli_fetch_assoc($query);
		$state=$row['title'];
		
		$lga=$record['lga_id'];
		$query=mysqli_query($con,"SELECT title FROM lga WHERE id='$lga'");
		$row=mysqli_fetch_assoc($query);
		
		$lga=$row['title'];
		$status=$record['marital_status'];
		$medication=$record['medi'];
		$blood_group=$record['blood_type'];
		$disability=$record['disability'];
		
		//$mat_no=$record['jamb_no'];
		//$student_type=$record['student_type'];
		
		$permenat_address=$record['permanent_address'];
		$level=$record['level'];
		//$lga_title=$record['lga_title'];
		//$religion=$record['religion'];
		
		
		$kin_address=$record['kin_address'];
		$kin_phone_number=$record['kin_phone_number'];
		$kin_relationship=$record['kin_relationship'];
		$kin_name=$record['kin_name'];
		
		
		$state_title="";
		$lga_title="";
		}
				
	
	$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$header_image=$row['header_image'];
					$crf_image=$row['crf_image'];
					$refree_image=$row['refree_image'];
					
					$header_image='images/'.$header_image;
					$crf_image='images/'.$crf_image;
					$refree_image='images/'.$refree_image;
					$paymentInvoice='images/paymentInvoice.png';
					
					
					
				}
			}
		}
		
		 //chk if the student has been allocated bedpace and has paid for the space 
	$check_my_acc = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE std_id='$number' ") or die(mysql_error());
				if($check_my_acc){
				$check_my_acc_row=mysqli_num_rows($check_my_acc);
					if($check_my_acc_row > 0){
						$get_my_room_info = mysqli_fetch_array($check_my_acc);
						$room_info_room_id = $get_my_room_info['room_id'];
						$room_info_site_id = $get_my_room_info['hostel_site'];
						$room_info_block_id = $get_my_room_info['hostel_categories'];
						
						
				
						$mm = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_info_room_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_room = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_categories  WHERE id='$room_info_block_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_block = $ronn ['title'];
							
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$room_info_site_id' ");
						$ronn = mysqli_fetch_array($mm);
							$site_title = strtoupper($ronn ['title']);
							
					}
				}
			
	$pdf = new FPDF();
$pdf  -> AddPage();
$pdf->Image('images/paid-banner.png', 15, 70, 180, 95);
//$pdf  -> Image('images/paid-banner.png',165,50,40,80);
$pdf  -> Image('images/paymentInvoice.png',40,6);


$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"BASIC INFORMATION",0,1,'l');

$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(0,5,"LEVEL: {$number}",1,1,'L');
$pdf  -> Cell(0,8,"NAME: {$full_name}",1,1,'L');



$pdf  -> Cell(0,5,"LEVEL: {$level}",1,1,'L');
$pdf  -> Cell(0,5,"AMOUNT : N{$amount}",1,1,'L');




$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,10,"ALLOCATION DETAILS",0,1,'l');

$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(0,8,"SITE: {$site_title}",1,1,'L');

$pdf  -> Cell(0,5,"BLOCK: {$title_block}",1,1,'L');
$pdf  -> Cell(0,5,"ROOM : {$title_room}",1,1,'L');



$pdf  -> SetFont("Arial","UB",12);

$pdf  -> Cell(0,10,"PAYMENT DETAILS",0,1,'l');
$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(0,8,"PAYMENT FOR: Hostel Accommodation",1,1,'L');
$pdf  -> Cell(0,5,"DATE PAID: {$payment_date}",1,1,'L');
$pdf  -> Cell(0,5,"AMOUNT PAID: N{$amount}",1,1,'L');


$pdf  -> SetFont("Arial","B",5);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"Source: {$projects_title}, 2017/2018 Academic Session.",0,0,'l');

$pdf -> Output();




?>