<?php 
//error_reporting(0);
session_start();
require_once('../fpdf/fpdf.php');
include_once("../include/connections.php");

	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$userType= $_SESSION['student_user_type'];
	$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
	}
	
	include_once("../include/GetCurrentSession.php");
$current_session=str_replace("/","_",$session_title);
	
		if($userType==1){
		$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND  status='1'";
	}else{
		 $sql = "SELECT *FROM applicants_".$current_session." WHERE email='$email' AND user_status='1'";
	}
		
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if( $no_of_rows > 0){
			 $record = mysqli_fetch_assoc($sql_run);
		$id=$record['id']; 
		$student_id=$record['id'];
		$img=$record['image'];
		$number=$record['number'];
		$surname=$record['surname'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$full_name=$surname.' '.$first_name.' '.$other_names;
		$project_id=$record['project_id'];
		$hostel_eligibility=$record['hostel_eligibility'];
		$maritalstatus=$record['marital_status'];
		$gender=$record['gender'];
		$medication=$record['medi'];
		$H_status=$record['H_status'];
		$std_date=$record['dob'];
		$email=$record['email'];
		$address=$record['address'];
		$phone_no=$record['phone_no'];
		$sponsorship_name=$record['sponsorship_name'];
		$sponsorship_address=$record['sponsorship_address'];
		$sponsorship_number=$record['sponsor_number'];
		$state=$record['state_id'];
		$programme_id=$record['programme_id'];
		$programmeid=$record['programme_id'];
		
		
		if($userType==0){
			$search=$number;
		}else{
			$application_number=$record['application_number'];
			$search=$application_number;
		}
		
		//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM programmes WHERE id='$programme_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$course=$row['title'];
		$department_id=$row['department_id'];
		$programmetype=$row['type'];
		
		
		
		//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM students_departments WHERE id='$department_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$department=$row['title'];
		
		
		
		//$faculty=$record['faculty'];
		//$hostel_faculty=$record['faculty'];
		
		$query=mysqli_query($con,"SELECT title FROM state WHERE id='$state'");
		$row=mysqli_fetch_assoc($query);
		$state=$row['title'];
		
		$lga=$record['lga_id'];
		$query=mysqli_query($con,"SELECT title FROM lga WHERE id='$lga'");
		$row=mysqli_fetch_assoc($query);
		
		$lga=$row['title'];
		$status=$record['marital_status'];
		$medication=$record['medi'];
		$blood_group=$record['blood_type'];
		$disability=$record['disability'];
		
		//$mat_no=$record['jamb_no'];
		//$student_type=$record['student_type'];
		
		$permenat_address=$record['permanent_address'];
		$level=$record['level'];
		//$lga_title=$record['lga_title'];
		//$religion=$record['religion'];
		
		
		$kin_address=$record['kin_address'];
		$kin_phone_number=$record['kin_phone_number'];
		$kin_relationship=$record['kin_relationship'];
		$kin_name=$record['kin_name'];
		
		
		$state_title="";
		$lga_title="";
		
		
		$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$header_image=$row['header_image'];
					$crf_image=$row['crf_image'];
					$refree_image=$row['refree_image'];
					
					$header_image='images/'.$header_image;
					$crf_image='images/'.$crf_image;
					$refree_image='images/'.$refree_image;
					
					
				}
			}
		}
		
		
		}


	$header_image='../images/header_'.$current_session.'.png';
	
if(empty($img)){
		$path = "uploads/0.jpg";
	}else{
		$path = "uploads/".$img;
	}
	
	$pdf = new FPDF();
$pdf  -> AddPage();

$pdf  -> Image($header_image,40,6);

$pdf  -> Image($path,165,25,30,30);
$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"BIO-DATA",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(70,5,"REGISTRATION NO: {$number}",1,0,'L');
$pdf  -> Cell(70,5,"NAME: {$full_name}",1,0,'L');
$pdf  -> Cell(50,5,"GENDER: {$gender}",1,1,'L');

$pdf  -> Cell(70,5,"DATE OF BIRTH: {$std_date}",1,0,'L');
$pdf  -> Cell(70,5,"MARITAL STATUS: {$maritalstatus}",1,1,'L');


$pdf  -> Cell(70,5,"NATIONALITY: Nigeria",1,0,'L');
$pdf  -> Cell(70,5,"STATE: {$state}",1,0,'L');
$pdf  -> Cell(50,5,"LOCAL GOVT. AREA: {$lga}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"CONTACT INFORMATION",0,1,'l');


$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"TELEPHONE:{$phone_no}",1,1,'L');
$pdf  -> Cell(190,5,"PRESENT ADDRESS:{$address}",1,1,'L');
$pdf  -> Cell(190,5,"PERMENANT ADDRESS:{$permenat_address}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"NEXT OF KIN",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"NAME:{$kin_name}",1,1,'L');
$pdf  -> Cell(190,5,"RELATIONSHIP:{$kin_relationship}",1,1,'L');
$pdf  -> Cell(190,5,"TELEPHONE:{$kin_phone_number}",1,1,'L');
$pdf  -> Cell(190,5,"ADDRESS:{$kin_address}",1,1,'L');

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"SPONSOR",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"NAME: {$sponsorship_name}",1,1,'L');
$pdf  -> Cell(190,5,"TELEPHONE: {$sponsorship_number}",1,1,'L');
$pdf  -> Cell(190,5,"ADDRESS: {$sponsorship_address}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"HEALTH DATA",0,1,'l');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(70,5,"STATUS: {$H_status}",1,0,'L');
$pdf  -> Cell(70,5,"DISABILITY: {$disability}",1,0,'L');
$pdf  -> Cell(50,5,"BLOOD GROUP: {$blood_group}",1,1,'L');
$pdf  -> Cell(50,5,"MEDICATION: {$medication}",1,1,'L');
  
  



$pdf  -> AddPage();


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"APPLICATION DETAILS",0,1,'l');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"DEPARTMENT: {$department}",1,1,'L');
$pdf  -> Cell(190,5,"PROGRAMM: {$course}",1,1,'L');
$pdf  -> Cell(190,5,"LEVEL: {$level}",1,1,'L');



$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"ACADEMIC RECORDS",0,1,'l');

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,8,"Olevel Result",0,1,'l');


$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"SN",1,0,'L');
$pdf  -> Cell(40,5,"Exam Number",1,0,'L');
$pdf  -> Cell(40,5,"Exam Type",1,0,'L');
$pdf  -> Cell(40,5,"Year/Month",1,0,'L');
$pdf  -> Cell(40,5,"Subject",1,0,'L');
$pdf  -> Cell(10,5,"Grade",1,1,'L');

include_once("../include/connections.php");
		
		
		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
			
		$sql  = "select * from student_o_level_".$current_session." WHERE student_id = '$student_portal_login_id'";
		$query=mysqli_query($con,$sql);
		$r=mysqli_num_rows($query);
		if($r > 0){
			$sn = 1;
			while($rows = mysqli_fetch_array($query)){
				$olevel_id = $rows['id'];
				$exam_type = $rows['exam_type'];
				$exam_year = $rows['exam_year'];
				$exam_month = $rows['exam_month'];
				$sub_grade = $rows['sub_grade'];
				$subject_id = $rows['subject_id'];
				$exam_number = $rows['exam_number'];
				
				// get subject title
				$sql_query2 = mysqli_query($con,"select title from subjects where subject_id = '$subject_id'");
					while($title_array  = mysqli_fetch_array($sql_query2)){
							$subject_title = $title_array['title'];
						$pdf  -> Cell(20,5,"{$sn}",1,0,'L');
						$pdf  -> Cell(40,5,"{$exam_number}",1,0,'L');
						$pdf  -> Cell(40,5,"{$exam_type}",1,0,'L');
						$pdf  -> Cell(40,5,"{$exam_month}",1,0,'L');
						$pdf  -> Cell(40,5,"{$subject_title}",1,0,'L');
						$pdf  -> Cell(10,5,"{$sub_grade}",1,1,'L');
						
					}
				$sn++;
			}
		}
		

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,8,"Higher Qualification",0,1,'l');
$pdf  -> SetFont("Arial","B",7);

$pdf  -> Cell(50,5,"Qualification",1,0,'L');
$pdf  -> Cell(40,5,"Class of Qualification",1,0,'L');
$pdf  -> Cell(50,5,"Institution",1,0,'L');
$pdf  -> Cell(40,5,"Year of Graduation",1,1,'L');


include_once('../include/connections.php');
							include_once("../include/GetCurrentSession.php");
							$current_session=str_replace("/","_",$session_title);
							$sql="SELECT * FROM applicant_qualification_".$current_session." WHERE applicant_id='$student_portal_login_id'";
							$sql_query = mysqli_query($con,$sql);
							$sql_query_row=mysqli_num_rows($sql_query);
							if($sql_query_row > 0){
								$sub_array = mysqli_fetch_array($sql_query);
										$qualification = $sub_array['qualification'];
										$institution = $sub_array['institution'];
										$year_of_graduation = $sub_array['year_of_graduation'];
										$class_of_result = $sub_array['class_of_result'];
										$specify = $sub_array['specify'];
										
										if($qualification=="Others"){
											$qualification=$specify;
										}
										
$pdf  -> Cell(50,5,"{$qualification}",1,0,'L');
$pdf  -> Cell(40,5,"{$class_of_result}",1,0,'L');
$pdf  -> Cell(50,5,"{$institution}",1,0,'L');
$pdf  -> Cell(40,5,"{$year_of_graduation}",1,1,'L');

							}
									
$pdf  -> AddPage();										
$pdf  -> Image($refree_image,40,6);
$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,60,"",0,1,'C');
$pdf  -> Cell(0,3,"Section A (To be completed by the candidate)",0,1,'l');									

$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",10);
$pdf  -> Cell(190,5,"1. Name of the Candidate:",0,1,'L');
$pdf  -> Cell(190,5,"{$full_name}",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');


$pdf  -> Cell(190,5,"2a. Department of the University to which Application is being made:",0,1,'L');
$pdf  -> Cell(190,5,"{$department}",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');


$pdf  -> Cell(190,5,"2b. Course of study to which admission is sought:",0,1,'L');
$pdf  -> Cell(190,5,"{$course}",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> Cell(0,3,"Section B (To be completed by the Referee)",0,1,'l');

$pdf  -> SetFont("Arial","B",10);
$pdf  -> Cell(190,5,"Comments will be regarded as confidential information. The completed forms should please be returned directly to the",0,1,'L');
$pdf  -> Cell(190,5,"Academic Programme Officer, Institute of Maritime Studies, Ibrahim Badamasi Babangida University, P.M.B 11, Lapai.",0,1,'L');

$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"3. How long, and in what capacity have you known the Candidate (e.g. as his/her teacher at under graduate or",0,1,'L');
$pdf  -> Cell(190,5,"post-graduate level)?",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');



$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"4. Please comment on the candidate suitability or otherwise to undertake post-graduate work in the proposed",0,1,'L');
$pdf  -> Cell(190,5,"field (bearing in mind the following intellectual ability: capacity for persistance, independent academic)",0,1,'L');
$pdf  -> Cell(190,5,"study, ability for imaginative thought.)",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');

$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"5. Please indicate by a brief statement, whether you consider the candidate adequate in oral and written",0,1,'L');
$pdf  -> Cell(190,5,"expression in English language to enable him to cope with the need of his research in an english-speaking",0,1,'L');
$pdf  -> Cell(190,5,"University).?",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');


$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"6. Please rank the candidate academically among the students you have known or taught",0,1,'L');
$pdf  -> Cell(190,5,"Top 10%__________ Top 25%________Average__________ Lowest 25%________Lowest 10%__________ ",0,1,'L');


$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"7. Please comment on the candidate's personality (Bearing in mind moral character emotion and physical stability).",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');


$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"8. Should the situation arise, would you be ready to accept the candidate as your research student?",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');

$pdf  -> Cell(190,5,"",0,1,'L');									
$pdf  -> Cell(190,5,"9. Comment freely upon the candidate.",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');


$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"Name of the Referee",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');

$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(80,5,"Rank of Referee",0,0,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(80,5,"_____________________________________",0,0,'L');
$pdf  -> Cell(80,5,"_____________________________________",0,1,'L');

$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(80,5,"School or University",0,0,'L');
$pdf  -> Cell(80,5,"Date",0,0,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(80,5,"_____________________________________",0,0,'L');
$pdf  -> Cell(80,5,"_____________________________________",0,1,'L');



$pdf  -> Cell(190,5,"",0,1,'L');
$pdf  -> Cell(80,5,"Address",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');
$pdf  -> Cell(190,5,"_____________________________________________________________________________________________",0,1,'L');

		include_once("../include/GetCurrentSession.php");
		$current_session=str_replace("/","_",$session_title);
			
		$sql  = "select * from other_certificate_uploads_".$current_session." WHERE student_id = '$student_id'";
		$query=mysqli_query($con,$sql);
		$r=mysqli_num_rows($query);
		if($r > 0){
			$sn = 1;
			while($rows = mysqli_fetch_array($query)){
				$images=$rows['images'];
				$pdf  -> AddPage();
				
				$p='document_uploads_'.$current_session.'/'.$images;
				$pdf  -> Image($p,20,6);
			}
		}





		
$pdf -> Output();




?>