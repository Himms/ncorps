<?php 
error_reporting(0);
session_start();
require_once('../fpdf/fpdf.php');
include_once("../php/get_applicant_profile.php");

if(empty($img)){
		$path = "uploads/0.jpg";
	}else{
		$path = "uploads/".$img;
	}
	$pdf = new FPDF();
$pdf  -> AddPage();

$pdf  -> Image($header_image,40,6);

$pdf  -> Image($path,165,25,30,30);
$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"BIO-DATA",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(70,5,"MATRICULATION NO: {$number}",1,0,'L');
$pdf  -> Cell(70,5,"NAME: {$first_name}",1,0,'L');
$pdf  -> Cell(50,5,"GENDER: {$gender}",1,1,'L');

$pdf  -> Cell(70,5,"DATE OF BIRTH: {$std_date}",1,0,'L');
$pdf  -> Cell(70,5,"MARITAL STATUS: {$maritalstatus}",1,1,'L');


$pdf  -> Cell(70,5,"NATIONALITY: Nigeria",1,0,'L');
$pdf  -> Cell(70,5,"STATE: {$state}",1,0,'L');
$pdf  -> Cell(50,5,"LOCSL GOVT. AREA: {$lga}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"CONTACT INFORMATION",0,1,'l');


$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"TELEPHINE:{$phone_no}",1,1,'L');
$pdf  -> Cell(190,5,"PRESENT ADDRESS:{$address}",1,1,'L');
$pdf  -> Cell(190,5,"PERMENANT ADDRESS:{$permenat_address}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"NEXT OF KIN",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"NAME:{$kin_name}",1,1,'L');
$pdf  -> Cell(190,5,"RELATIONSHIP:{$kin_relationship}",1,1,'L');
$pdf  -> Cell(190,5,"TELEPHONE:{$kin_phone_number}",1,1,'L');
$pdf  -> Cell(190,5,"ADDRESS:{$kin_address}",1,1,'L');

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"SPONSOR",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"NAME: {$sponsorship_name}",1,1,'L');
$pdf  -> Cell(190,5,"TELEPHONE: {$sponsorship_number}",1,1,'L');
$pdf  -> Cell(190,5,"ADDRESS: {$sponsorship_address}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"HEALTH DATA",0,1,'l');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(70,5,"STATUS: {$H_status}",1,0,'L');
$pdf  -> Cell(70,5,"DISABILITY: {$disability}",1,0,'L');
$pdf  -> Cell(50,5,"BLOOD GROUP: {$blood_group}",1,1,'L');
$pdf  -> Cell(50,5,"MEDICATION: {$medication}",1,1,'L');
  
  
$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,10,"ACADEMIC RECORD",0,1,'l');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(190,5,"DEPARTMENT: {$department}",1,1,'L');
$pdf  -> Cell(190,5,"PROGRAMM: {$course}",1,1,'L');
$pdf  -> Cell(190,5,"LEVEL: {$level}",1,1,'L');


$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,8,"",0,1,'C');
$pdf  -> Cell(0,10,"[ * ] I certify that the information entered herein is the best of my knowledge and correct and complete:",0,0,'l');




$pdf  -> SetFont("Arial","B",5);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"Source: $projects_title Online Registration Portal",0,0,'l');

$pdf -> Output();




?>