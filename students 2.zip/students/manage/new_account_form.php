<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			
                            		 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 New Account</span></h5>
                        		</div>                       		
                            </div>
			
							<div class="form-bottom">
			              <form role="form" class="login-form" action="#" method="POST">
			                    	<div class="form-group">
			                    		<label for="username">Email (Any valid Email)</label>
			                        	<input id="email" type="email" name="email" placeholder="Email" class="form-control">
			                        </div>
									
									<div class="form-group">
			                    		<label for="gender">Gender</label>
			                        	<select class="form-control" id="gender" name="gender">
											<option></option>
											<option>Male</option>
											<option>Female</option>
										</select>
			                        </div>
									<div class="form-group">
			                        	<label for="phone_number">Phone Number (Any valid Phone Number)</label>
			                        	<input id="phone_number" type="text" name="phone_number" placeholder="Phone Number" class="form-control">
			                        </div>
			                        <div class="col-md-6" style="margin:0px;padding:0px;">
										<div class="form-group">
			                        	<label for="password">Password</label>
			                        	<input id="password1" type="password" name="password1" placeholder="Password" class="form-control">
			                        </div>
									</div>
									
									 <div class="col-md-6" style="margin:0px;padding:0px;">
										<div class="form-group">
			                        	<label for="password">Confirm</label>
			                        	<input id="password2" type="password" name="password2" placeholder="Confirm" class="form-control">
			                        </div>
									</div>
									
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button name="btn_Generate" onclick="create_account()" class="btn btn-success" type="button">
                            Create Account
                        </button>
						<hr/><div id="error" style="color:red"></div>
						
						<center>
						<a role="button" style="margin-top:3px;" class="btn btn-info glyphicon glyphicon-home" href="http://<?php echo $website; ?>">School Website</a>

						
						<a onclick="load_student_account_login()" role="button" style="margin-top:3px;" class="btn btn-success" href="#">Sign in instead</a></center>
                    </div>
			                    </form>
		                    </div>