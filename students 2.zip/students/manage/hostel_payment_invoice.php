<?php
	if(isset($_GET['token'])){
		$t_amount="300";
	}else{
		
		header('location:desktop.php');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>..:ePortal&reg :<?php echo $projects_title; ?></title>
<script type="text/javascript" src="https://api.ravepay.co/flwv3-pug/getpaidx/api/flwpbf-inline.js"></script>
<link href="../css/font_css.css" rel="stylesheet" type="text/css" />
<link href="../css/invoice.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .auto-style1 {
            width: 63px;
            height: 79px;

        }
        .panel-heading{
            background:white;
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

</head>
<body>
    <form name="form1" method="post" action="" id="form1">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-lg-offset-1">    
                <div class="panel panel-default" id="invoice">
                    <div class="panel-heading" style="background:white">
                                                <div class="row">
                            <div class="col-lg-8">
                                <p><img src="images/<?php echo $project_sm_logo; ?>" title="Logo" ></p> 
                            </div>
                           
                    <div class="panel-body">
                        
                        <div class="row">
                            <h3>Transaction ID <span class="badge"><span id="lblRRR"><?php echo $number;?></span></span></h3>
                            <div class="col-xs-5">
                                <h4>Transaction Reference<span class="badge"><span id="lblTxnRef"></span></span></h4>
                                <h4>Application Number  <span class="badge"><span id="lblInvoiceNo"><?php echo $number;?></span></span></h4>
                                
                                <p>Date: <span id="lblDate"><?php echo date("Y/m/d");?></span></p>
                                </div>
                                <div class="col-xs-4">
                                    <h4>Invoiced To</h4>
                                    <p>
                                        <span id="lblFullname"><?php echo $app_name; ?></span><br> 
                                        <span id="lblTelephone"><?php echo $phone_number; ?></span><br>
                                        <span id="lblDepartment"><?php echo $email; ?></span>
                                                                            </p>
                                    
                                </div>
                                <div class="col-xs-3">
                                    <h4>Pay To</h4>
                                    <p><?php echo $projects_title ?>.<br>
<br>
                                    </p>
                                </div>
                            </div>
                        <br />
                            <table class="table table-bordered table-striped">
                                <tbody><tr>
                                    <th>SN</th>
									
                                    <th>Amount</th>
                                    
                                    <th>Payment Type</th>
                                </tr>
                                                                <tr>
                                    <td><span id="lblPaymentPurpose">1</span></td>
						
									 <td><span id="lblFeeType" style="font-weight:normal;">APPLICATION FORM FEE (<?php echo $programm_title; ?>)</span></td>
                                    <td><span id="lblAmount">=N=<?php echo $amount; ?></span></td>
                                    
                                </tr>
								 <tr>
                                    <td><span id="lblPaymentPurpose">2</span></td>
									
									 <td><span id="lblFeeType" style="font-weight:normal;">Online Transaction FEE</span></td>
                                    <td><span id="lblAmount">=N=<?php echo $t_amount; ?></span></td>
                                    
                                </tr>
                                                                <tr>
                                    <td>&nbsp;</td>
                                    <td></td>
									 <td></td>
                                    
                                </tr>

                                                                                                <tr>
                                    <td>&nbsp;</td>
                                    <td> </td>
									 <td></td>
									 
                                                                                                    
                                </tr>
                                <tr class="info">
                                    <td>Total:</td>
                                    <td><span id="lbltotal" style="font-weight:bold;">=N=<?php echo $total; ?></span></td>
                                    <td></td>
									
                                </tr>
                            </tbody></table>

                            
                            <h4>
                                <span style="color:red;">Click on the Pay Now Button to pay your fee Online</span>
							  <div class="col-lg-4 text-right">
							 <?php
								if($project_id==1){
									
   echo'<a class="flwpug_getpaid" data-PBFPubKey="FLWPUBK-36f622d5cdba092c98dbf739a9d92387-X" data-txref="'.$projects_title.'" data-amount="'.$total.'" data-customer_email="'.$email.'" data-currency = "NGN" data-pay_button_text = "Pay Now" data-country="NG" data-custom_title = "'.$projects_title.'" data-custom_description = "Application Fee Payment Paid by '.$number.'" data-redirect_url = "" data-custom_logo = "//ravepay.co/files/paybutton-images/a9fc2f1e9b23fa937a69678235868353.png" data-payment_method = "both" data-exclude_banks=""></a>';

								}elseif($project_id==2){
									
   echo'<a class="flwpug_getpaid" data-PBFPubKey="FLWPUBK-1b7efad5d4acde7998951b5cb2dff860-X" data-txref="'.$projects_title.'" data-amount="'.$total.'" data-customer_email="'.$email.'" data-currency = "NGN" data-pay_button_text = "Pay Now" data-country="NG" data-custom_title = "'.$projects_title.'" data-custom_description = "Application Fee Payment Paid by '.$number.'" data-redirect_url = "" data-custom_logo = "eportal.flailas-edu.net/manage/images/logo.png" data-payment_method = "both" data-exclude_banks=""></a>	';

								}
							 
							 ?>

							 
							 
							 
							                                         </div>
							</h4>
			<hr/>
			<p>
			
				<h4>NOTE:</h4>
				<p>Get faster account activation by paying online</p>
				<p>Print this slip for reference Use.</p>
				
				<p>After making your payment, Your Account will be Activated and your Login Detail will be sent to you via your email or Phone Number.
				for online payment, your account will be activated within 1Hour while for bank deposit your Account will be activated within 24Hours from the time you make the payment</p>
				<p>Online Transaction Fee is only Apply to you, if you are paying online</p>
				<p>If you need help at any point, please feel free to contact us, For Technical Support:09034202781 </p>
			</p>
                            <table class="table table-striped">
                                <tbody><tr>
                                    <td>
                                        <span id="lblInstruction"></span> </td>
                                </tr>
                                                               
                                                                <tr>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                                           
                            </tbody></table>
<table class="table table-bordered table-striped">
                                <tbody><tr>
                                    <th>SN</th>
									<th>Bank</th>
                                    <th>Account Name</th>
                                    <th>Account Number</th>
                                </tr>
							   
                         <?php
						 $sn=1;
		include_once('../include/connections.php');
		//set payment type to control the payment that will show
		  $sql_get_bank=mysqli_query($con,"SELECT *FROM bank_detail WHERE project_id='$project_id' AND status='1'");
			if($sql_get_bank){
				$sql_get_bank_row=mysqli_num_rows($sql_get_bank);
				if($sql_get_bank_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_bank)){
				   $Bank=$row['Bank'];
				   $Account_Name=$row['Account_Name'];
				   $Account_Number=$row['Account_Number'];
				   
				   echo '<tr>
                                    <td>'.$sn.'</td>
									<td>'.$Bank.'</td>
                                    <td>'.$Account_Name.'</td>
                                    <td>'.$Account_Number.'</td>
                                </tr>';
								
								$sn=$sn + 1;
				}
				
				
				
				}
			}
						 
						 ?>
						 </tbody></table>
                           
                        </div>
                    </div>
                </div>

            </div>
            
            
            <div class="row">
                <div class="col-lg-9 col-lg-offset-1 text-right" >
                    <a href="index.php?token=<?php echo $token; ?>" class="btn btn-link"><< Back</a><a href="#" class="btn btn-default btn-sm btn-success" onclick="printDiv('invoice')">Print Page</a>
                </div>
            </div>
        </div>
      </div>
	   </div>
    </form>

</body>
</html>
