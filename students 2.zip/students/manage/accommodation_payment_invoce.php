<?php

	session_start();
	if(isset($_SESSION['student_portal_login_id'])){
	 $student_portal_login_id= $_SESSION['student_portal_login_id'];
	  include_once("../include/db.php");
	 
  $sql_get_alloc=mysqli_query($con,"SELECT *FROM students_2019_2020 WHERE id='$student_portal_login_id'");
		
		if($sql_get_alloc){
			$sql_get_alloc_row=mysqli_num_rows($sql_get_alloc);
			if($sql_get_alloc_row > 0){
				$row=mysqli_fetch_assoc($sql_get_alloc);
					$student_id	=$row['id'];
					$matric_no=$row['number'];
					$surname=$row['first_name'];
					$othername=$row['other_names'];
					$level=$row['level'];
					$phone_no=$row['phone_no'];
					
					$full_name=$surname.' '.$othername;
			}
		}
	
	$check_my_acc = mysqli_query($con,"SELECT *FROM hostel_allocation WHERE std_id='$number' ") or die(mysql_error());
				if($check_my_acc){
				$check_my_acc_row=mysqli_num_rows($check_my_acc);
					if($check_my_acc_row > 0){
						$get_my_room_info = mysqli_fetch_array($check_my_acc);
						$room_info_room_id = $get_my_room_info['room_id'];
						$room_info_site_id = $get_my_room_info['hostel_site'];
						$room_info_block_id = $get_my_room_info['hostel_categories'];
						
						
				
						$mm = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_info_room_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_room = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_categories  WHERE id='$room_info_block_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_block = $ronn ['title'];
							
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$room_info_site_id' ");
						$ronn = mysqli_fetch_array($mm);
							$site_title = strtoupper($ronn ['title']);
					}
				}
				
	$tfee="400";
	$total=12400;
		$sqlPayment="SELECT *FROM payments_2019_2020 WHERE number='$number' AND payment_type='Accommodation Fee' AND status='0'";
		$sqlPaymentRun=mysqli_query($con,$sqlPayment) or die(mysqli_error($con));
		$sqlPaymentRunRow=mysqli_num_rows($sqlPaymentRun);
		if($sqlPaymentRunRow > 0){
			$r=mysqli_fetch_array($sqlPaymentRun);
				$payment_type=$r['payment_type'];
				$payment_info=$r['id'];
		}

}
	

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>..:ePortal&reg :<?php echo $projects_title; ?></title>
<script type="text/javascript" src="https://api.ravepay.co/flwv3-pug/getpaidx/api/flwpbf-inline.js"></script>
<link href="../css/font_css.css" rel="stylesheet" type="text/css" />
<link href="../css/invoice.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .auto-style1 {
            width: 63px;
            height: 79px;

        }
        .panel-heading{
            background:white;
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

</head>
<body>
    <form name="form1" method="post" action="" id="form1">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-lg-offset-1">    
                <div class="panel panel-default" id="invoice">
                    <div class="panel-heading" style="background:white">
                                                <div class="row">
                            <div class="col-lg-8">
                               <p><img src="images/ibbul.jpg" title="Logo" ></p> 
                            </div>
                           
                    <div class="panel-body">
                        
                        <div class="row">
                            <h3><?php echo $number;?></h3>
                            <div class="col-xs-5">
                                
                                <p>Date: <span id="lblDate"><?php echo date("Y/m/d");?></span></p>
								
	<a href="#" onClick="payWithRave('.$total.','.$student_portal_login_id.','.$payment_info.')" class="list-group-item btn btn-success"><center><b>Pay Now</b><center></a>
                                </div>
                                <div class="col-xs-4">
                                    <h4>Invoiced To</h4>
                                    <p>
                                        <span id="lblFullname"><?php echo $full_name; ?></span><br> 
                                        
                                    </p>
                                    
                                </div>
                                <div class="col-xs-3">
                                    <h4>Pay To</h4>
                                    <p>Ibrahim Badamasi Babangida University, Lapai<br>
<br>
                                    </p>
                                </div>
                            </div>
                        <br />
                            <table class="table table-bordered table-striped">
                                <tbody><tr>
                                    <th>SN</th>
									
                                    <th>Amount</th>
                                    
                                    <th>Payment Type</th>
                                </tr>
                                                                <tr>
                                    <td><span id="lblPaymentPurpose">1</span></td>
						
									 <td><span id="lblFeeType" style="font-weight:normal;">Accommodation Fee</span></td>
                                    <td><span id="lblAmount">=N=<?php echo $total; ?></span></td>
                                    
                                </tr>
								
								 
                                                                <tr>
                                    <td>&nbsp;</td>
                                    <td></td>
									 <td></td>
                                    
                                </tr>

                                                                                                <tr>
                                    <td>&nbsp;</td>
                                    <td> </td>
									 <td></td>
									 
                                                                                                    
                                </tr>
                                <tr class="info">
                                    <td>Total:</td>
                                    <td><span id="lbltotal" style="font-weight:bold;">=N=<?php echo $total; ?></span></td>
                                    <td></td>
									
                                </tr>
                            </tbody></table>

                            
                           
			<hr/>
		
			
			


			
			</p>
                        </div>
                    </div>
                </div>

            </div>
            
            
            
        </div>
      </div>
	   </div>
    </form>
    
   <script type="text/javascript" src="https://api.ravepay.co/flwv3-pug/getpaidx/api/flwpbf-inline.js"></script>
    <script>
  
    //const API_publicKey = "FLWPUBK-4829c1170eb69f32b9ca459ad5fc7078-X";
    const API_publicKey = "FLWPUBK-7111ab866f3fc3bccde72cd3ae133fa9-X";
    var flw_ref = "", chargeResponse = "", trxref = "FDKHGK"+ Math.random();
    function payWithRave(total,txref) {
		
        var x = getpaidSetup({
            PBFPubKey: API_publicKey,
            customer_email: accommodationhelp.ibbu.edu.ng,
            custom_title: "FEES PAYMENT",
            amount: total,
            payment_options:"card",
            custom_description: "ACCOMMODATION FEE",
            custom_logo: "http://www.flailas-edu.com/img/ibbul.jpg",
            currency: "NGN",
            txref: txref,
            meta: [{
                metaname: "flightID",
                metavalue: "AP1234"
            }],
            onclose: function() {},
            callback: function(response) {
                var txref = response.tx.txRef; 
				chargeResponse = response.tx.chargeResponseCode;
               
                if (
                    chargeResponse == "00" ||
                    chargeResponse == "0"
                ) {
                    paymentSucessfull(txref,total);
					
                } else {
                    paymentfail(txref);
                }

                x.close(); // use this to close the modal immediately after payment.
            }
        });
    }
	function paymentfail(txref){
		alert("Payment unsuccessfull, Please try again latter");
	}
	function paymentSucessfull(txref,total){
		$.post('../php/paymentSucessfull.php',{txref:txref,total:total},
				function(response,error){
					//alert(response);
					feepayment();
					
			});
	}
</script>
</body>
</html>
