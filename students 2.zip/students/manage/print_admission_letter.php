<?php 
error_reporting(0);
session_start();
if(isset($_SESSION['student_portal_login_id'])){
		include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$userType= $_SESSION['student_user_type'];
	
	$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
		$student_id = $student_portal_login_id;
}
require_once('../fpdf/fpdf.php');
//include_once("../php/get_user_profile.php");

include_once("../include/GetCurrentSession.php");
$current_session=str_replace("/","_",$session_title);

	$header_image='../images/header_'.$current_session.'.png';
	
	
	
	$sql = "SELECT *FROM applicants_".$current_session. " app INNER JOIN admitted_students_".$current_session." astd ON astd.applicant_id=app.number WHERE app.email='$email' AND app.user_status='1'";

		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 $project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			 $programme_id=$get_Acc_detail['programme_id'];
			 
			 //get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM programmes WHERE id='$programme_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$course=$row['title'];
		$department_id=$row['department_id'];
		$programmetype=$row['type'];
		$programme_time=$row['programme_time'];
			 
		if($programme_time=="Part-time"){
		   $admission_header='images/admission_header_'.$current_session.'_1.png';
		}else{
		   $admission_header='images/admission_header_'.$current_session.'_2.png';
		}	 
			 
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $level=$get_Acc_detail['level'];
		
			 $full_name=$surname.' '.$first_name.' '.$other_names;
			 $mat_year=substr($number,0,3);
			 
			 if($image=='0.jpg'){
				 $pic='0.jpg';
			 }else{
				 $pic=$student_portal_login_id.'.jpg';
			 }
			
		}
		
	$ref='REF: IBBUL/IMS/'.$programmetype.'/'.$session_title;
if(empty($img)){
		$path = "uploads/0.jpg";
	}else{
		$path = "uploads/".$img;
	}
	$pdf = new FPDF();
$pdf  -> AddPage();
$pdf->Image('images/back.png', 0, 0, 250, 298);
$pdf  -> Image($admission_header,40,6);


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"{$ref}",0,1,'l');

$pdf  -> SetFont("Arial","B",10);
$pdf  -> Cell(70,5,"{$full_name}",0,1,'L');


$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> MultiCell(0,10,"I write to inform you that your application for {$programme_time} {$course} in the INSTITUTE OF MARITIME STUDIES has been successful.",0,1,'');
$pdf  -> MultiCell(0,10,"The provisional admission takes effect from June 3, 2019 and your programme is expected to last for a minimum of 12 months and up to 24 months.",0,1,'');

$pdf  -> MultiCell(0,10,"All candidates are to pay their fees and other charges during registration, which lasts for 2 weeks and a further period of 2 weeks of late registration which attracts a fine of N5,000.00.",0,1,'');

$pdf  -> Cell(0,5,"Admission is deemed lapsed after four weeks of official resumption, if the candidate does not register.",0,1,'l');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,5,"Candidates are to present their original certificates/credentials for screening during registration.",0,1,'l');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,5,"Ensure that the particulars and information you are providing are correct in every respect. If at any time, it is discovered that ",0,1,'l');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,5,"you do not satisfy the minimum entry requirements prescribed for the course at the time of this offer, or that any of the",0,1,'l');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,5,"qualifications you claimed to have is false or incorrect, you will be required to withdraw from the university. Also, know that,",0,1,'l');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,5,"the name by which you are hereby admitted and by which you are registered is the one that will appear",0,1,'l');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,5,"on any certificate that the University will issue to you on successful completion of your programme.",0,1,'l');

$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(0,2,"",0,1,'C');
$pdf  -> Cell(190,7,"Please accept my congratulations on your admission.",0,1,L);

$pdf  -> Image("images/sig.png",110,230,80,30);
		
$pdf -> Output();




?>