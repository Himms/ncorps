<?php
session_start();
include_once("../include/connections.php");

include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
}

if(isset($_FILES["FileInput"]) && $_FILES["FileInput"]["error"]== UPLOAD_ERR_OK)
{
	$number=$_POST["doc_type"];;
	############ Edit settings ##############
	$UploadDirectory= 'document_uploads_2019_2020/'; //specify upload directory ends with / (slash)
	##########################################
	
	/*
	Note : You will run into errors or blank page if "memory_limit" or "upload_max_filesize" is set to low in "php.ini". 
	Open "php.ini" file, and search for "memory_limit" or "upload_max_filesize" limit 
	and set them adequately, also check "post_max_size".
	*/
	
	//check if this is an ajax request
	if (!isset($_SERVER['HTTP_X_REQUESTED_WITH'])){
		die();
	}
	
	
	//Is file size is less than allowed size.
	if ($_FILES["FileInput"]["size"] > 5242880) {
		die("File size is too big!");
	}
	
	//allowed file type Server side check
	switch(strtolower($_FILES['FileInput']['type']))
		{
			//allowed file types
            case 'image/png': 
			
			case 'image/jpeg': 
			case 'image/pjpeg':
			
			case 'application/pdf':
			
			
				break;
			default:
				die('Unsupported File!'); //output error
	}
	
	$File_Name = strtolower($_FILES['FileInput']['name']);
	$File_Ext  = substr($File_Name, strrpos($File_Name, '.')); //get file extention
	$rnumber=rand(10000000,999999999);
	$NewFileName= $rnumber.$number.$File_Ext; //new file name
	
	
	if(move_uploaded_file($_FILES['FileInput']['tmp_name'],$UploadDirectory.$NewFileName ))
	   {
	   //save document name $NewFileName 
	   
	   $sql="INSERT INTO other_certificate_uploads_".$current_session."(student_id,certificate_type,images) VALUES('$student_portal_login_id','$number','$NewFileName')";
	   $sql_add=mysqli_query($con,$sql);
		die('Success! File Uploaded.');
	}else{
		die('error uploading File!');
	}
	
}
else
{
	die('Something wrong with upload! Is "upload_max_filesize" set correctly?');
}