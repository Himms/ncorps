<?php
	if(isset($_GET['token'])){
	    
	    $token=$_GET['token'];
		
		include_once("../include/connections.php");
		$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE system_code='$token' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$slider=$row['slider'];
					
				}
			}else{
			    
			    
		header('location:http://www.google.com');

			}
		}
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>..:ePortal&reg :<?php echo $projects_title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">



<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

	
  </head>
  <body >
  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand" href="#" style="color:green"><b> SmartSchool&reg 5.0 </b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                <!-- header menu -->
				<?php
	//get project id
	$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE system_code='$token' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				$row=mysqli_fetch_assoc($sql_get);
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
				
			}
		}

?>
<ul class="nav navbar-nav navbar-right">

            <!--<li>
				<a href="#" style="color:green;" class="btn btn-success btn-lg-xs" data-toggle="modal" data-target="#myModal" style="color:#fff">Apply Now</a>
			</li>-->
			  <li>
				<a href="#" style="color:green;" class="btn btn-success btn-lg-xs" data-toggle="modal" data-target="#activateAccount" style="color:#fff">Activate Account</a>
			</li>
			
		<li class="active">
				<a class="btn-group btn-group-xs" href="http://flailas-edu.com/">Back to School Website</a>
		</li>
		
</ul>
				<!-- end header menu -->
				
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:10px;">
<div style="height:500px;">
	          <div class="top-content">
                       <div style="width:100%">
                            <div style="width:10%;float:left;background-color:black;color:#fff;">HELP LINE</div>
                             <div style="width:80%;float:right;">
                                 <marquee behavior="scroll" direction="left"> For more enquiries, Please contact ddlawal@ibbu.edu.ng or use our online chartbox</marquee>
                                </div>
                       </div>
            <div class="inner-bg" >
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-sm-offset-0 form-box" style="padding:0px;margin:0px;">
						
						<div class="col-sm-8" style="padding:0px;margin:0px;">
						
						<div class="form-bottom" style="padding:0px;margin:0px;">
              <img src="../images/home_mob.jpg" width="100%" height="400px" />
		        </div>
						
						
						
				<div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>		
						
						
						</div>
						<div class="col-sm-4 form-box" id="content" style="background-color:#CCCCC">
						
						
						<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			<center><img src="images/<?php echo $project_sm_logo; ?>" width="30%"></center>
                            		 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 Login here</span></h5>
                        		</div>                       		
                            </div>
							
							<div class="form-bottom">
							
			                    <form role="form" class="login-form">
			                    	<div class="form-group">
			                    		<label class="sr-only" for="username">Email</label>
			                        	<input id="username" type="text" name="form-username" placeholder="Email" class="form-control">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="password">Password</label>
			                        	<input id="password" type="password" name="form-password" placeholder="Password..." class="form-control">
										<input id="token" type="hidden" value="<?php echo $system_code;?>">
			                        </div>
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button id="btn_login" onclick="student_portal_login()" class="btn btn-success" type="button">
                            Sign in
                        </button>
						<hr/><div id="error" style="color:red"></div>
						
						
                    </div>
			                    </form>
		                    </div>
						
						</div>
						
						
                        </div>
                    </div>
                    
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
 
  
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Instructions</h4>
      </div>
      <div class="modal-body">
            <div class="list-group">
  <a href="#" class="list-group-item active">
    1. Create Account
  </a>
  <a href="#" class="list-group-item">
        <p>Click on Apply Now to get started, Read the Instructions and make sure you understand before you proceed. </p>
            <img src="images/login.PNG" />
  </a>
  
</div>



 <div class="list-group">
  <a href="#" class="list-group-item active">
    2. Fill the required Information
  </a>
  <a href="#" class="list-group-item">
        <p>Fill all the required Information, Make sure you use a valid email address and your current Phone Number. Enter the password you will always remember, Click on Create Account button when you are done.
        Click on login to access your account.</p>
            <img src="images/create.PNG" />
  </a>
  
</div>



 <div class="list-group">
  <a href="#" class="list-group-item active">
    3. Login
  </a>
  <a href="#" class="list-group-item">
        <p>Enter your email and password and click on Signin button to login to your Account.</p>
            <img src="images/login.PNG" />
  </a>
  
</div>


 <div class="list-group">
  <a href="#" class="list-group-item active">
    4. Upload Passport
  </a>
  <a href="#" class="list-group-item">
        <p>After loging in, click on the Avater picture to upload your passport</p>
            <img src="images/1.PNG" />
            
            
  </a>
  
</div>


 <div class="list-group">
  <a href="#" class="list-group-item active">
    5. Upload Passport
  </a>
  <a href="#" class="list-group-item">
        <p>Chose the pasport and click on the arrow button to upload the pasport</p>
            <img src="images/2.PNG" />
  </a>
  
</div>

 <div class="list-group">
  <a href="#" class="list-group-item active">
    6. Update your Biodata, Health Information and choose your course
  </a>
  <a href="#" class="list-group-item">
        <p>Click on biodata, fill all the requred fields and click on Health Information, Fill the required fields and then Select the course you are applying for and click on save changes button</p>
            <img src="images/1.PNG" />
  </a>
  
</div>

<div class="list-group">
  <a href="#" class="list-group-item active">
    7. Update Academic Record
  </a>
  <a href="#" class="list-group-item">
       
            <img src="images/3.PNG" />
  </a>
  
</div>

<div class="list-group">
  <a href="#" class="list-group-item active">
    8. Upload other document
  </a>
  <a href="#" class="list-group-item">
        
            <img src="images/4.PNG" />
  </a>
  
</div>

<div class="list-group">
  <a href="#" class="list-group-item active">
    9. Click on Fee Payment to make your Payment
  </a>
  <a href="#" class="list-group-item">
       
            <img src="images/5.PNG" />
  </a>
  
</div>

<div class="list-group">
  <a href="#" class="list-group-item active">
    9. Enter your Card Details and click on pay
  </a>
  <a href="#" class="list-group-item">
      
            <img src="images/6.PNG" />
  </a>
  
</div>

      </div>
      <div class="modal-footer">
        <a href="new_account/?token=<?php echo $token; ?>" class="btn btn-primary">Apply</a>
      </div>
    </div>
  </div>
</div>


<div class="modal fade" id="activateAccount" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title pull-left" id="myModalLabel">Activate Account</h4>
      </div>
      <div class="modal-body" id="errorCreateAccount">
         
 
 
   <div class="col-md-12">
    <div class="form-group">
    <label for="matric" style="float:left;">Matric Number</label>
    <input type="text" class="form-control" id="matricNumber" placeholder="Matric Number">
  </div>
   </div>
  <div class="col-md-12">
   <div class="form-group">
    <label for="email" style="float:left;">Email address</label>
    <input type="email" class="form-control" id="emailAddress" placeholder="Email address">
  </div>
  </div>
  <div class="col-md-12">
		<div class="col-md-6">
			 <div class="form-group">
    <label for="password" style="float:left;">Enter Password</label>
    <input type="password" class="form-control" id="password1" placeholder="Enter Password">
  </div>
		</div>
		<div class="col-md-6">
		 <div class="form-group">
    <label for="password" style="float:left;">Re-Enter Password</label>
    <input type="password" class="form-control" id="password2" placeholder="Re-Enter Password">
  </div>
		</div>
  </div>
   <div class="modal-footer">
        <a class="btn btn-primary" onclick="nextcreateAccount()">Next</a>
      </div>
	</div>
     <div id="Createerror"></div>
    </div>
  </div>
</div>

 </body>
 <html>