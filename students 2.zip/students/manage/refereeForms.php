<?php
$error="";
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	if(isset($_POST['btnSubmit'])){
	    echo $error= '<b style="color:green">Record Submited Successfully';
	}
	
    if(isset($_GET['token'])){
        $token=$_GET['token'];
        //get candidate detail
        
        $sql_getRef=mysqli_query($con,"SELECT *FROM referee WHERE md5(ref1)='$token' or md5(ref2)='$token' OR md5(ref3)='$token'") or die(mysqli_error($con));
    if($sql_getRef){
        $sql_getRef_row=mysqli_num_rows($sql_getRef);
        if($sql_getRef_row > 0){
            $ro=mysqli_fetch_array($sql_getRef);
            $candidateemail=$ro['email'];
           
        }
    }
    
    //get candidate detail
    $sql = "SELECT *FROM applicants_".$current_session." WHERE email='$candidateemail'";

		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $programme_id=$get_Acc_detail['programme_id'];
			 
			$fullname=$surname.' '.$first_name.' '.$other_names;
			
			
				//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM programmes WHERE id='$programme_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$course=$row['title'];
		$department_id=$row['department_id'];
		$programmetype=$row['type'];
			
		}
    
    
    }

?>
<!DOCTYPE html>
<html>
  <head>
    <title>..:ePortal&reg :Referee Form</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">



<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

	
  </head>
  <body >
  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand" href="#" style="color:green"><b> REFEREE FORM</b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                <!-- header menu -->
				<ul class="nav navbar-nav navbar-right">
	       
           
		
</ul>
				<!-- end header menu -->
				
			</div>
		</div>
</div>
                </div>
                
 <form action="refereeForms.php?token=<?php echo $token; ?>" method="POST">
 <div class="row" style="margin-top:10px;">
<div style="height:500px;">
	          <div class="top-content">

            <div class="inner-bg" >
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-sm-offset-0 form-box" style="padding:0px;margin:0px;">
						
						<div class="col-sm-12 form-box" id="content" style="background-color:#CCCCC">
							<div class="col-md-6" style="padding:0px;margin:0px;">
								
						
						<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			
                            		 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 Refree Form</span></h5>
                        		</div>                       		
                            </div>
							
							<div class="form-bottom">
									<div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Candidate Name</label>
	<input id="surname" type="text" name="surname"  class="form-control" value="<?php echo $fullname; ?>" disabled>
			                        </div>
									</div>
									<div class="col-md-12">
										<div class="form-group">
			                    		<label for="username">Course Applied</label>
			         <textarea id="surname" class="form-control" disabled><?php echo $course; ?></textarea>
			                        
			                        </div>
									</div>
									
									
		                    
		                    	<div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">How long, and in what capacity have you known the Candidate (e.g. as his/her teacher at under graduate or post-graduate level)?</label>
			     <textarea id="surname" class="form-control"></textarea>
			                        </div>
									
		                    </div>
		                    
		                    
		                    
		                    
		                 
		                    
		                    
		                    <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Please comment on the candidate suitability or otherwise to undertake post-graduate work in the proposed field (bearing in mind the following intellectual ability: capacity for persistance, independent academic) study, ability for imaginative thought.</label>
			     <textarea id="surname" class="form-control"></textarea>
			                        </div>
									
		                    </div>
							

   <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Please indicate by a brief statement, whether you consider the candidate adequate in oral and written expression in English language to enable him to cope with the need of his research in an english-speaking University.</label>
			     <textarea id="surname" class="form-control"></textarea>
			                        </div>
									
		                    </div>
		                    
		                    
							
							</div>
							
						</div>
						<div class="col-md-6" style="padding:0px;margin:0px;">
						    
						      <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Please rank the candidate academically among the students you have known or taught (eg.  Top 10%, 25%,Average,Lowest 25%,Lowest 10%)</label>
		<input id="surname" type="text" name="surname"  class="form-control">
			                        </div>
									
		                    </div>
		                    
		                    
		                     <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Please comment on the candidate's personality (Bearing in mind moral character emotion and physical stability.</label>
			     <textarea id="surname" class="form-control"></textarea>
			                        </div>
									
		                    </div>
		                    
		                    
		                     <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Should the situation arise, would you be ready to accept the candidate as your research student?</label>
			    <input id="surname" type="text" name="surname"  class="form-control">
			                        </div>
									
		                    </div>
		                    
		                    
		                   <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Comment freely upon the candidate.</label>
			     <textarea id="surname" class="form-control"></textarea>
			                        </div>
									
		                    </div>
		                    
		                    
		                    
		                     <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Name of the Referee</label>
			    <input id="surname" type="text" name="surname"  class="form-control">
			                        </div>
									
		                    </div>
		                    
		                    
		                    <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">Rank of the Referee</label>
			    <input id="surname" type="text" name="surname"  class="form-control">
			                        </div>
									
		                    </div>
		                    
		                    
		                    <div class="col-md-12">
										<div class="form-group">
			                    	<label for="username">School or University</label>
			    <input id="surname" type="text" name="surname"  class="form-control">
			                        </div>
									
		                    </div>
		                    
		                    
		                    
						</div>
						
						
					<div class="col-md-12">	
						 <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							<div><?php $error; ?></div>
            <button type="submit" class="btn btn-success" name="btnSubmit">
                            SUBMIT
                        </button>
                    </div>
				</div>	
						
						
						
                        </div>
                    </div>
                    
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  </form>

 </body>
 <html>