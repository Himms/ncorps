<?php
//error_reporting(0);
session_start();
include_once("../include/connections.php");
	
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
		$office_id=$_GET['office_id'];

	
   ?>
  
<div class="col-md-12">

		<div class="list-group panel-default">
				<ul class="list-group">
					<li class="list-group-item panel-default">
						<h4>ELECTION RESULT<hr/></h4>
					</li>
				</ul>
				
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
<?php
		$sql_get_office=mysqli_query($con,"SELECT *FROM offices WHERE offices_id='$office_id' ORDER BY sorting DESC");
	if($sql_get_office){
		$sql_get_officeRow=mysqli_num_rows($sql_get_office);
		if($sql_get_officeRow > 0){
			while($get_rows=mysqli_fetch_assoc($sql_get_office)){
				$title=$get_rows['title'];
				$office_id=$get_rows['offices_id'];
				
			echo '<h1>'.$title.'</h1><hr/>';
					//get list of all candidates
	$sql_get_candidate=mysqli_query($con,"SELECT *FROM candidates WHERE office_id='$office_id' ");
	if($sql_get_candidate){
		$sql_get_candidateRow=mysqli_num_rows($sql_get_candidate);
		if($sql_get_candidateRow > 0){
			while($rows=mysqli_fetch_assoc($sql_get_candidate)){
				$candidate_id=$rows['candidate_id'];
				
				//get candidate info
				$sql = "SELECT *FROM student_".$current_session." WHERE id='$candidate_id'";
	

		$sql_run = mysqli_query($con, $sql) or die(mysqli_error($con));
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 $get_Acc_detail = mysqli_fetch_assoc($sql_run);
			 //$usertype=$get_Acc_detail['user_type'];
			 //$project_id=$get_Acc_detail['project_id'];
			 $image=$get_Acc_detail['image'];
			 $number=$get_Acc_detail['number'];
			 $gender=$get_Acc_detail['gender'];
			
			 $email=$get_Acc_detail['email'];
			 $surname=$get_Acc_detail['surname'];
			 $first_name=$get_Acc_detail['first_name'];
			 $other_names=$get_Acc_detail['other_names'];
			 $level=$get_Acc_detail['level'];
		
			 $full_name=$surname.' '.$first_name.' '.$other_names;
			 $img=str_replace("/","_",$number);
			 
 $sql_chkVoted=mysqli_query($con,"SELECT DISTINCT(student_id) FROM votes WHERE candidate_id='$candidate_id' AND office_id='$office_id'");
	if($sql_chkVoted){
		$sql_chkVotedRow=mysqli_num_rows($sql_chkVoted);
	}
			
			 echo '
				<div class="col-md-4">
				
				<a href="#">
				<img src="../images/candidates/'.$img.'.JPG" alt="..." class="img-thumbnail" style="width:20%;height:150px;"><br/>
					<b>'.$full_name.'</b><br/>
					<b>'.$number.'</b><br/>
					<b>Votes: '.$sql_chkVotedRow.'</b><br/>
				</a>
				
				</div>
				<br/>
				<br/>
			 ';
		}
			}
		}
	}
		}
		}
	}
?>
	
</div>
</div>
</div>