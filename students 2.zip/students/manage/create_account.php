<?php
	if(isset($_GET['token'])){
		include_once('../include/get_project_details.php');
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>..:ePortal&reg :<?php echo $projects_title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

	
  </head>
  <body>


  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand" href="#" style="color:green"><b> ePOrTAL&reg 2.1 </b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                <!-- /end of function nav bar /header menu -->
				<ul class="nav navbar-nav navbar-right">
					
			<li class="dropdown">
          <a style="color:green" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><b>Prospective Students</b><span class="caret"></span></a>
          <ul class="dropdown-menu">
			<li><a href="my_application_form.php?token=<?php echo $token; ?>">My Application Form</a></li>
            <li><a href="generate_payment_invoice.php?token=<?php echo $token; ?>">Generate Payment Invoice</a></li>
			<li><a href="reprint_invoice_slip.php?token=<?php echo $token; ?>">Reprint Invoice Slip</a></li>
          </ul>
        </li>
		
		<li class="dropdown">
          <a style="color:green" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><b>New Students</b><span class="caret"></span></a>
          <ul class="dropdown-menu">
			 <li><a href="generate_payment_invoice.php?token=<?php echo $token; ?>">Generate Payment Invoice</a></li>
			<li><a href="reprint_invoice_slip.php?token=<?php echo $token; ?>">Reprint Invoice Slip</a></li>
            <li><a href="create_account.php?token=<?php echo $token; ?>">Create Account</a></li>
          </ul>
        </li>
		
		
		<li class="dropdown">
          <a style="color:green" href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><b>Returning Students</b><span class="caret"></span></a>
          <ul class="dropdown-menu">
			 <li><a href="generate_payment_invoice.php?token=<?php echo $token; ?>">Generate Payment Invoice</a></li>
			<li><a href="reprint_invoice_slip.php?token=<?php echo $token; ?>">Reprint Invoice Slip</a></li>
            <li><a href="activate_account.php?token=<?php echo $token; ?>">Activate Account</a></li>
			
          </ul>
        </li>
		
			<li>
				<a class="btn-group btn-group-xs" href="http://<?php echo $website; ?>">Back to School Website</a>
			</li>
			<li class="active">
				<a class="btn-group btn-group-xs" href="index.php?token=<?php echo $token; ?>">Login</a>
			</li>
				</ul>
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:10px;">
<div style="height:500px;">
	          <div class="top-content">

            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-sm-offset-0 form-box">
						
						<div class="col-sm-8"></div>
						<div class="col-sm-4 form-box" id="content" style="background-color:#CCCCC">
						
						
						<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			<center><img src="images/logo.png" width="30%"></center>
									 <div class="alert alert-info" role="alert" style="margin-top:10px;">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only"></span>
  	LOGIN: For any difficulty Click here or call our support line: <?php echo $contact_person; ?><br/>
</div>
                            		
                        		</div>                       		
                            </div>
							
							<div class="form-bottom">
							
			                    <form role="form" class="login-form">
			                    	<div class="form-group">
			                    		<label class="sr-only" for="username">Username</label>
			                        	<input id="username" type="text" name="form-username" placeholder="Username..." class="form-control">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="password">Password</label>
			                        	<input id="password" type="password" name="form-password" placeholder="Password..." class="form-control">
										<input id="token" type="hidden" value="<?php echo $system_code;?>">
			                        </div>
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button id="btn_login" onclick="student_portal_login()" class="btn btn-success" type="button">
                            Sign in
                        </button>
						<hr/><div id="error" style="color:red"></div>
						
						<center>
						<a role="button" style="margin-top:3px;" class="btn btn-info glyphicon glyphicon-home" href="http://<?php echo $website; ?>">School Website</a>

						
						<a role="button" style="margin-top:3px;" class="btn btn-danger glyphicon glyphicon-edit" href="account_reset.php">Reset Password</a></center>
                    </div>
			                    </form>
		                    </div>
						
						</div>
						
						
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  

 </body>
 <html>