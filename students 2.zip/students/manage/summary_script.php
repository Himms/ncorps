<?php
$otherL=0;
$oneL=0;
$oneLm=0;
$oneLf=0;

$dbServerName = "localhost";
$dbUsername = "xbbue9x";
$dbPassword = "^TOtallyquasing*ProgrammiNG(ifX=&,--_+.Rw";
$dbName = "xbbue9x_data_sync";

$project_id='3';

// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);



$dbServerName1 = "portals.ibbu.edu.ng";
$dbUsername1 = "portalsi_syncdba";
$dbPassword1 = "765QWE119ssjXxxX";
$dbName1 = "portalsi_UGRegSyncDB";

$project_id='3';

// create connection
$connn = new mysqli($dbServerName1, $dbUsername1, $dbPassword1, $dbName1);

// check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



    //get all Allocation
    include_once("../include/connections.php");
    $sql_get_all_allocation=mysqli_query($con,"SELECT *FROM user_information");
    if($sql_get_all_allocation){
        $sql_get_all_allocation_row=mysqli_num_rows($sql_get_all_allocation);
        if($sql_get_all_allocation_row > 0){
            while($get_record=mysqli_fetch_array($sql_get_all_allocation)){
            $number=$get_record['number'];
            echo $number.' ';
            $mat_year=substr($number,0,3);
            $sql_chk=mysqli_query($conn,"SELECT *FROM student_eligibility WHERE student_matric_number ='$number'") or die(mysqli_error($conn));
            if($sql_chk){
                $sql_chk_row=mysqli_num_rows($sql_chk);
                if($sql_chk_row > 0){
                    echo 'Exist';
                }else{
                    
                   $sql=mysqli_query($con,"UPDATE user_information SET hostel_eligibility='0' WHERE number='$number'");
                    echo 'Do not Exist';
                }
            }
            
            echo '<br/>';
            
        }
    }

}




?>