<?php

	session_start();
	
	include_once("../php/get_student_profile.php");
	

	if(!isset($_SESSION['student_portal_login_id'])){
	
		header("location:index.php");
	}
	$student_portal_login_id= $_SESSION['student_portal_login_id'];
	
	
	include_once("../include/connections.php");
  
	if(empty($img)){
			
			$pic='0.png';
		}else{
			
			$pic=$img;
			
		}

//file uploads

   
?>
<!DOCTYPE html>
<html>
  <head>
    <title>..:ePortal&reg </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    
	 <script type="text/javascript" src="../js/jquery.js"></script>
        <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   <script type="text/javascript" src="../js/inner_script.js"></script>
   <script type="text/javascript" src="../js/save.js"></script>
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">
	<link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.min.css">
	<link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap-theme.min.css">
	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.min.js"></script>
	
	
	<script>
/* Script written by Adam Khoury @ DevelopPHP.com */
/* Video Tutorial: http://www.youtube.com/watch?v=EraNFJiY0Eg */
function _(el){
	return document.getElementById(el);
}
function uploadFile(){
	var file = _("file1").files[0];
	// alert(file.name+" | "+file.size+" | "+file.type);
	var formdata = new FormData();
	formdata.append("file1", file);
	var ajax = new XMLHttpRequest();
	ajax.upload.addEventListener("progress", progressHandler, false);
	ajax.addEventListener("load", completeHandler, false);
	ajax.addEventListener("error", errorHandler, false);
	ajax.addEventListener("abort", abortHandler, false);
	ajax.open("POST", "file_upload_parser.php");
	ajax.send(formdata);
}
function progressHandler(event){
	_("loaded_n_total").innerHTML = "Uploaded "+event.loaded+" bytes of "+event.total;
	var percent = (event.loaded / event.total) * 100;
	_("progressBar").value = Math.round(percent);
	_("status").innerHTML = Math.round(percent)+"% uploaded... please wait";
}
function completeHandler(event){
	_("status").innerHTML = event.target.responseText;
	_("progressBar").value = 0;
}
function errorHandler(event){
	_("status").innerHTML = "Upload Failed";
}
function abortHandler(event){
	_("status").innerHTML = "Upload Aborted";
}


</script>
  </head>
  <body>


  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#" style="color:green"><b> ePOrTAL&reg 5.0 </b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->   
                <!-- /end of function nav bar /header menu -->
				<ul class="nav navbar-nav navbar-right">
					<li>
						<h6>
                        
                        </h6>
					
					</li>
                    <?php
	//get menu 
	$sql_get=mysqli_query($con,"SELECT *FROM eportal_menu WHERE project_id='$project_id' AND (link_type='0' OR link_type='$student_type')");
	if($sql_get){
		
		$sql_get_row=mysqli_num_rows($sql_get);
		if($sql_get_row > 0){
			
			while($get_rows=mysqli_fetch_assoc($sql_get)){
				$menu_title=$get_rows['menu_title'];
				$menu_function=$get_rows['menu_function'];
				$menu_link=$get_rows['link'];
				
				echo '<li ><a class="btn-group btn-group-xs" href="'.$menu_link.'" onclick="'.$menu_function.'">'.$menu_title.'</a> </li>';
				
			}
		}
	}
  ?>
					<li class="active"><a class="btn-group btn-group-xs" href="logout.php">Logout</a></li>
				</ul>
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:50px;">
	<div id="error"></div>
<div class="well" style="height:550px;">
      <div class="col-md-3 tabcontents"> 
        <div id="view1">
		<div class="list-group">
  <a href="#" class="list-group-item disabled">
   	<span class="label label-default"><?php echo $mat_no; ?></span>
  </a>
  <a title="Click to upload passport"  data-toggle="collapse" href="#collapseExample"  class="list-group-item"><center> <img src="uploads/<?php echo $pic; ?>" class="img-circle" width="150px" height="200px" /></center></a>
  <div class="  collapse" id="collapseExample" style="height:40px">
							  <div style="height:40px">
							   <form id="upload_form" enctype="multipart/form-data" method="post">
								<div class="col-md-9">
								<progress style="align:right" id="progressBar" value="0" max="100" style="width:200px;"></progress>
								<input align="left" type="file" name="file1" id="file1">
								</div>
	<div class="col-md-3">
		<button onclick="uploadFile()" type="submit" class="btn btn-primary" align="right"><span class="glyphicon glyphicon-upload"></span></button>
		
	</div>
	
  <h3 id="status"></h3>
  <p id="loaded_n_total"></p><br/>	
					
								
								</form>
							  </div>
							</div>
  <a href="#" class="list-group-item"><span class="label label-default"><?php echo $first_name; ?></span></a>
  <a href="#" class="list-group-item"><span class="label label-default"><?php echo $course; ?></span></a>
  <a href="#" class="list-group-item"><span class="label label-default"><?php echo $level; ?></span></a>
</div>	 
        </div> 
      </div>
	   <div class="col-md-2 tabcontents" > 
        <div id="view1">
			<div class="list-group">
  <a href="#" class="list-group-item disabled">
    <span style="color:green;" class="glyphicon glyphicon-list" aria-hidden="true"></span>MENU
  </a>
    <?php
	//get menu 
	$sql_get=mysqli_query($con,"SELECT *FROM eportal_menu WHERE project_id='$project_id' AND (link_type='0' OR link_type='$student_type')");
	if($sql_get){
		
		$sql_get_row=mysqli_num_rows($sql_get);
		if($sql_get_row > 0){
			
			while($get_rows=mysqli_fetch_assoc($sql_get)){
				$menu_title=$get_rows['menu_title'];
				$menu_function=$get_rows['menu_function'];
				$menu_link=$get_rows['link'];
				
				echo '<a href="'.$menu_link.'" class="list-group-item" onclick="'.$menu_function.'">'.$menu_title.'</a>';
			}
		}
	}
  ?>
</div>
        </div> 
      </div>
	   <div class="col-md-7 tabcontents" style="height:450px;overflow-y:scroll;overflow-x:hidden;margin:0px;padding:0px">
	   
	   <div id="content">
	   
	   </div>

      </div>
	 
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  
  
  
  
  
 </body>
 <html>