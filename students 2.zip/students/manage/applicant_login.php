<?php
	if(isset($_GET['token'])){
		$token=$_GET['token'];
		include_once('../include/get_project_details.php');
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>..:ePortal&reg :<?php echo $projects_title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

	
  </head>
  <body>


  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand" href="#" style="color:green"><b> ePOrTAL&reg 2.1 </b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                 <!-- header menu -->
				<?php include_once('../include/links.php') ?>
				<!-- end header menu -->
				
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:10px;">
<div style="height:500px;">
	          <div class="top-content">

            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-sm-offset-0 form-box">
						
						<div class="col-sm-8">
						
						<div class="form-bottom">
							
			                    <div class="login-form">
			                    	
		<div class="panel panel-default">
  <div class="panel-heading">INSTRUCTION:
Please read the instruction carefully</div>
  <div class="panel-body">
		<ul>
		<li>
			<p>To complete your Application, Make sure you fill all your bio data, Upload your Olevel Result and other credentials. 
			<b>Enter your Application Number and Password to login.</b> </p>
		</li>
		<li>
			<p>If you are an Applicant and have not generate your Application form Invoice, Click on Prospctive Students Link</p>
		</li>
		<li>
			<p>If you are a New Student, Click on New Students Link</p>
		</li>
		<li>
			<p>For Returning student, Click on Returning Student Link</p>
		</li>
		<li>
			<p>For New and returning Students whose Account has been Activated, Login button on the menu</p>
		</li>
		
		
		
		<hr/>
		<li>
			<p>LOGIN: For any difficulty Click here or call our support line: </p>
		</li>
		
		
		<hr/>
		
	</ul>
  </div>
</div>
	
					
			                    </div>
		                    </div>
						
						
						
						
						
						
						</div>
						<div class="col-sm-4 form-box" id="content" style="background-color:#CCCCC">
						
						
						<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			 <center><img src="images/<?php echo $project_sm_logo; ?>" width="30%"></center>
									 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 Prospective Students >> My Application Form</span></h5>					
                            		
                        		</div>                       		
                            </div>
							
							<div class="form-bottom">
							
			                    <form role="form" class="login-form">
			                    	<div class="form-group">
			                    		<label for="username">Application Number</label>
			                        	<input id="username" type="text" name="form-username" placeholder="Application Number" class="form-control">
			                        </div>
			                        <div class="form-group">
			                        	<label for="password">Password</label>
			                        	<input id="password" type="password" name="form-password" placeholder="Password" class="form-control">
										<input id="token" type="hidden" value="<?php echo $system_code;?>">
			                        </div>
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button id="btn_login" onclick="applicant_portal_login()" class="btn btn-success" type="button">
                            Sign in
                        </button>
						<hr/><div id="error" style="color:red"></div>
						
						<center>
						<a role="button" style="margin-top:3px;" class="btn btn-info glyphicon glyphicon-home" href="http://<?php echo $website; ?>">School Website</a>

						
						<a role="button" style="margin-top:3px;" class="btn btn-danger glyphicon glyphicon-edit" href="account_reset.php">Reset Password</a></center>
                    </div>
			                    </form>
		                    </div>
						
						</div>
						
						
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  

 </body>
 <html>