<?php
	if(isset($_GET['token'])){
	    
	    $token=$_GET['token'];
		
		include_once("../include/connections.php");
		$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE system_code='$token' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$slider=$row['slider'];
					
				}
			}else{
			    
			    
		header('location:http://www.google.com');

			}
		}
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title><?php echo $projects_title; ?></title>
  <link href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/login.css">
</head>
<body style="overflow:hidden;">
  <main class="d-flex align-items-center min-vh-100 py-3 py-md-0">
    <div class="container">
      <div class="card login-card" style="margin-top:50px;">
        <div class="row no-gutters">
          <div class="col-md-5">
            <img src="assets/images/login.jpg" alt="login" class="login-card-img">
          </div>
          <div class="col-md-7">
            <div class="card-body">
              <div class="brand-wrapper">
                <!-- <img src="images/ibbul.jpg" alt="logo" class="logo"> -->
              </div>
              <p class="login-card-description">Sign into your account</p>
              <form action="#">
                  <div class="form-group">
                    <label for="email" class="sr-only">Registration Number</label>
                    <input type="text" name="username" id="username" class="form-control" placeholder="Enter your Registration Number">
                  </div>
                  <div class="form-group mb-4">
                    <label for="password" class="sr-only">Password</label>
                    <input type="password" name="password" id="password" class="form-control" placeholder="***********">
					<input id="token" type="hidden" value="<?php echo $system_code;?>">
                  </div>
                  <input name="login" id="login" class="btn-success btn-block login-btn mb-4" type="button" value="Login" onclick="student_portal_loginn()">
				  <hr/>
				  <div id="error" style="color:red"></div>
                </form>
                <a href="createAccont.php?token=812ed4562d3211363a7b813aa9cd2cf042b63bb2tt256e8190e474aatt256e8190e474aa" class="forgot-password-link"><h5 style="color:green">Don't have Account ? Register</h5></a>
               
            </div>
          </div>
        </div>
      </div>
     
    
    </div>
  </main>
  <script src="assets/js/jquery-3.4.1.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
   <script type="text/javascript" src="../js/script.js"></script>
</body>
</html>
