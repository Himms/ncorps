<style>
.body{
    border:1px solid ;
}
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>preview</title>
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="../images/admin_logo.png" type="image/x-icon" />
   <script type="text/javascript" src="../js/inner_script.js"></script>
   <script type="text/javascript" src="../pages/save.js"></script>
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">
	<link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.min.css">
	<link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap-theme.min.css">
	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.min.js"></script>
</head>
<body>
  <div class="container">
  <div class="row">
  <div class="col-md-12">
  <div class="row body">
  <div class="col-md-1">
  <img src="./images/logo.png" alt="">
  </div>
  <div class="col-md-10" align="center">
  <h4>JUSTICE FATI LAMI ,MINNA,NIGER STATE<br>2016/2017 Academic Session <br> COURSE REGISTRATION FORM</h4>
  </div>
  </div>
  
  </div>
  <div class="col-md-12">
  <div class="row body">
  <div class="col-md-12">
  <li>Basic Course Registration Info</li>
  <div class="col-md-12">
  <table class="table table-bordered">
  <tr>
  <td>Matriculation Number:</td>
  <td colspan="2">Name:</td>
  <td>level:</td>
  </tr>
  <tr>
  <td>Session:</td>
  <td>Status:</td>
  <td>Programme:</td>
  <td>Study Mode:</td>
  </tr>
  <tr>
  <td>Faculty:</td>
  <td>Department:</td>
  <td colspan="2">Course Of Study:</td>
  
  </tr>
  </table>
  <table class="table table-bordered">
  
  </table>
  </div>
  </div>
  </div>
  
  </div>
  </div>
  </div>  
</body>
</html>