<!DOCTYPE html>
<html>
  <head>
    <title>Student Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/account_reset.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="../images/admin_logo.png" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">
	<link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.min.css">
	<link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap-theme.min.css">
	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.min.js"></script>
	
  </head>
  <body>


  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#">STUDENT PORTAL 2.0</a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                <!-- /end of function nav bar /header menu -->
				<ul class="nav navbar-nav navbar-right">
					<li>
						<h6>
                        
                        </h6>
					
					</li>
			<li class="active"><a class="btn-group btn-group-xs" href="http://www.flailas-edu.net">Back to School Website</a></li>
				</ul>
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:10px;">

<div style="height:500px;">
	          <div class="top-content">

            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
						<div class="col-md-12">
									
								</div>
                        	<div class="form-top">
                        		<div class="form-top-center">
                        			<center><img src="images/logo.png" width="30%"></center>
									 <div class="alert alert-info" role="alert" style="margin-top:10px;">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only"></span>
  	Enter your Matric Number and Phone Number to Reset password:<br/>
</div>
                            		
                        		</div>
								
                        		<div class="form-top-right">
                        			<i class="fa fa-key"></i>
                        		</div>
                            </div>
                            <div class="form-bottom">
							
			                    <form role="form" class="login-form">
			                    	<div class="form-group">
			                    		<label class="sr-only" for="username">Matric Number</label>
			                        	<input id="matric_number" type="text" name="form-username" placeholder="Matric Number..." class="form-control">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="password">Phone Number</label>
			                        	<input id="phone_number" type="text" name="form-password" placeholder="Phone Number..." class="form-control">
			                        </div>
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button id="btn_login" onclick="student_portal_reset_password()" class="btn btn-success" type="button">
                            Reset Password
                        </button>
						<hr/><div id="error" style="color:red"></div>
						
						<center>
						<a role="button" style="margin-top:3px;" class="btn btn-info glyphicon glyphicon-home" href="http://www.flailas-edu.net">School Website</a>
						<a role="button" style="margin-top:3px;" class="btn btn-success" href="index.php">Sign in</a>
						<a role="button" style="margin-top:3px;" class="btn btn-danger glyphicon glyphicon-user" href="account.php">Create Account</a>

						</center>
                    </div>
			                    </form>
		                    </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  

 </body>
 <html>