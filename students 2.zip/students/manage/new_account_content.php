<div class="col-md-12" style="height:350px;">
    <h4 style="color:green;">Create New Account<hr/></h4>
</div>