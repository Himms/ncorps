<?php
	session_start();
	
	include_once("../include/connections.php");
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);

	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
		//$user_type= $_SESSION['student_user_type'];
		$email= $_SESSION['email'];
	}

$fileName = $_FILES["file1"]["name"]; // The file name
$fileTmpLoc = $_FILES["file1"]["tmp_name"]; // File in the PHP tmp folder
$fileType = $_FILES["file1"]["type"]; // The type of file it is
$fileSize = $_FILES["file1"]["size"]; // File size in bytes
$fileErrorMsg = $_FILES["file1"]["error"]; // 0 for false... and 1 for true
$file_ext=strtolower(end(explode('.',$_FILES['file1']['name'])));



$expensions= array("jpeg","jpg","png");

 if(in_array($file_ext,$expensions)=== false){
         echo "ERROR: extension not allowed, please choose a JPEG or PNG file.";
         exit();
      }
      
      if($file_size > 2097152){
         echo 'ERROR: File size must be excately 2 MB';
         exit();
      }

if (!$fileTmpLoc) { // if file not chosen
    echo "ERROR: Please browse for a file before clicking the upload button.";
    exit();
}

$file_name = $email.'.'.$file_ext;


 
if(move_uploaded_file($fileTmpLoc, "uploads/".$file_name)){
    echo "$fileName upload is complete";
	$sql = "UPDATE students_2020_2021 SET image='$file_name' WHERE email='$email'";
	
	$sqlRun=mysqli_query($con,$sql) or die(mysqli_error($con));
    
} else {
    echo "move_uploaded_file function failed";
}
?>