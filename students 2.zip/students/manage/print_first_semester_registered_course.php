<?php 
error_reporting(0);
session_start();
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	}else{
		header('location:logout.php');
	}
	

	require_once('../fpdf/fpdf.php');
include_once('../include/connections.php');
include_once('../php/get_student_profile.php');
			if($level == 'Applicant'){
				 $level = '100 Level';
			 }

	$pdf = new FPDF();
$pdf  -> AddPage();

$pdf  -> Image($crf_image,40,6);


$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"BIO-DATA",0,1,'l');

$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(70,8,"MATRICULATION NO: {$number}",1,0,'L');
$pdf  -> Cell(0,8,"NAME: {$first_name}",1,1,'L');


$pdf  -> Cell(0,5,"DEPARTMENT: {$department}",1,1,'L');
$pdf  -> Cell(0,5,"PROGRAMM: {$course}",1,1,'L');
$pdf  -> Cell(0,5,"LEVEL: {$level}",1,1,'L');

$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(70,15,"FIRST SEMESTER COURSES",0,1,'L');
$pdf  -> Cell(10,1,"_________________________________________________________________________________________________________________________",0,1,'L');



$pdf  -> SetFont("Arial","UB",30);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"SN",1,0,'L');
$pdf  -> Cell(50,5,"CODE",1,0,'L');
$pdf  -> Cell(100,5,"COURSE TITLE",1,0,'L');
$pdf  -> Cell(20,5,"UNIT",1,1,'L');

$pdf  -> SetFont("Arial","UB",25);
$pdf  -> Cell(0,1,"",0,1,'C');
$pdf  -> SetFont("Arial","",10);

$sn=1;
$course_unit_total=0;
include_once('../include/connections.php');
$sqlget=mysqli_query($con,"SELECT *FROM students_courses WHERE student_id='$student_portal_login_id' AND status='1' AND semester='First Semester'");
if($sqlget){
	$sqlget_row=mysqli_num_rows($sqlget);
	if($sqlget_row > 0){
		while($row=mysqli_fetch_array($sqlget)){
			
			$course_id=$row['course_id'];
			
		$sql_get_course=mysqli_query($con,"SELECT *FROM courses WHERE id='$course_id'");
		if($sql_get_course){
			$sql_get_course_row=mysqli_num_rows($sql_get_course);
			if($sql_get_course_row > 0){
				$ro=mysqli_fetch_array($sql_get_course);
					$course_title=$ro['title'];
					$course_code=$ro['code'];
					$course_unit=$ro['unit'];
				
			}
		}
		
$pdf  -> Cell(20,8,"{$sn}",1,0,'L');
$pdf  -> Cell(50,8,"{$course_code}",1,0,'L');
$pdf  -> Cell(100,8,"{$course_title}",1,0,'L');
$pdf  -> Cell(20,8,"{$course_unit}",1,1,'L');



$sn=$sn + 1;
$course_unit_total=$course_unit_total+ $course_unit;
		}
		

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"",1,0,'L');
$pdf  -> Cell(50,5,"",1,0,'L');
$pdf  -> Cell(100,5,"Total Unit",1,0,'L');
$pdf  -> Cell(20,5,"{$course_unit_total}",1,1,'L');

	}
}




$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(70,5,"__________________________________",0,0,'L');
$pdf  -> Cell(70,5,"__________________________________",0,0,'L');
$pdf  -> Cell(50,5,"________________________________",0,1,'L');

$pdf  -> Cell(70,5,"Signature of Student & Date",0,0,'L');
$pdf  -> Cell(70,5,"Signature of Academic Sec. & Date",0,0,'L');
$pdf  -> Cell(50,5,"Signature of Dean & Date",0,1,'L');








$pdf  -> SetFont("Arial","B",5);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"Source: Fati Lami Abubakar Institute of Legal and Administrative Studies, Minna Online Registration Portal, 2017/2018 Academic Session.",0,0,'l');

$pdf -> Output();




?>