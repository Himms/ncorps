<?php

include_once('../include/connections.php');
$dbServer = "ibbu.edu.ng";
$dbUser = "xbbue9x";
$dbPass = "^TOtallyquasing*ProgrammiNG(ifX=&,--_+.Rw";
$dbN = "xbbue9x_data_sync";
// create connection
$connn = new mysqli($dbServer, $dbUser, $dbPass, $dbN);

     $check_my_acc = mysqli_query($con,"SELECT *FROM hostel_allocation");
				if($check_my_acc){
				    $check_my_acc_row=mysqli_num_rows($check_my_acc);
					if($check_my_acc_row > 0){
						while($get_my_room_info = mysqli_fetch_array($check_my_acc)){
						$std_id = $get_my_room_info['std_id'];
						$room_info_room_id = $get_my_room_info['room_id'];
						$room_info_site_id = $get_my_room_info['hostel_site'];
					    $room_info_block_id = $get_my_room_info['hostel_categories'];
					    
					    
		$sql=mysqli_query($connn,"SELECT *FROM student_eligibility WHERE student_matric_number='$std_id' ");
								if($sql){
									$sql_row=mysqli_num_rows($sql);
									if($sql_row == 0){
										
								
					    
					    
					    
					    $mm = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_info_room_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_room = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_categories  WHERE id='$room_info_block_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_block = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$room_info_site_id' ");
						$ronn = mysqli_fetch_array($mm);
							$site_title = $ronn ['title'];
						
						$bedspace=$site_title.'-'.$title_block.'-'.$title_room;
						
						
					    echo $sn.' '.$std_id.' '.$bedspace.'<br/>';
					
					
					$sn=$sn + 1;
					
					
									}
								}			    
					    		
					
					
					
					
					
					}
				}
}


?>