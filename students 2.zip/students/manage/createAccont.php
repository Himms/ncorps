<?php
	$error="";
	if(isset($_GET['token'])){
	    
	    $token=$_GET['token'];
		
		include_once("../include/connections.php");
		$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE system_code='$token' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
				}
			}
		}
		
		
			if(isset($_POST['btn_Generate'])){
		$number=$_POST['number'];
		$fullname=$_POST['fullname'];
		$gender=$_POST['gender'];
		$phone_number=$_POST['phone_number'];
		$email=$_POST['email'];
		if(empty($number)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Matric Number</b></p>  
    </div>';
		}
		elseif(empty($fullname)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Fullname</b></p>  
    </div>';
		}
		elseif(empty($phone_number)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Phone Number</b></p>  
    </div>';
		}elseif(empty($email)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Email</b></p>  
    </div>';
		}else{
				//chk if the matric number already exist or not
		$sql_chk=mysqli_query($con,"SELECT *FROM student_2020_2021 WHERE number='$number' AND project_id='$project_id'");
			if($sql_chk){
				$sql_chk_row=mysqli_num_rows($sql_chk);
				if($sql_chk_row == 0){
					
					//chk if the email has been use or not
		$sql_chk_email=mysqli_query($con,"SELECT *FROM student_2020_2021 WHERE email='$email' AND project_id='$project_id'");
			if($sql_chk_email){
				$sql_chk_email_row=mysqli_num_rows($sql_chk_email);
				if($sql_chk_email_row == 0){
					
		//chk phone number
			$sql_chk_phone=mysqli_query($con,"SELECT *FROM student_2020_2021 WHERE phone_no='$phone_number' AND project_id='$project_id'");
			if($sql_chk_phone){
				$sql_chk_phone_row=mysqli_num_rows($sql_chk_phone);
				if($sql_chk_phone_row == 0){
				
		//create account
	$password=md5($phone_number);
		$u = substr($number, 0, 3);
		$fac = substr($number, 4, 3);
		if($fac=="FMS" || $fac=="FNS" || $fac=="FAT" || $fac=="FAG" || $fac=="FNS" || $fac="FAN"){
			
			$faculty='1';
		}elseif($fac=="FEA" ){
			
			$faculty='2';
		}else{
			$faculty='3';
			
		}
		
		if($u=="U17"){
			$level="100 Level";
			
		}elseif($u=="U16"){
			$level="200 Level";
			
		}elseif($u=="U15"){
			$level="300 Level";
			
		}elseif($u=="U14"){
			$level="400 Level";
			
		}elseif($u=="U13"){
			$level="500 Level";
			
		}else{
			
			$level="500 Level";
		}
		
		$platton = rand(1,9);
		$hostel = rand(1,5);
		$space = rand(1,20);
		$sead = rand(1,5);

		$bank = rand(1,5);

		
	$sql_create=mysqli_query($con,"INSERT INTO student_2020_2021(bank,bedspace,platoon,hostel,sead,number,email,phone_no,project_id,first_name,gender,password,user_status,level,faculty) VALUES('$bank','$space','$platton','$hostel','$sead','$number','$email','$phone_number','$project_id','$fullname','$gender','$password','1','$level','$faculty')");			
	if($sql_create){
		$error=' <div class="alert alert-success">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:green">Your account has been created successfully, Please login with your Matric number and your phone number</b></p>  
    </div>';
	}				
					
					
				}else{
					
					$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">This phone number has already been used</b></p>  
    </div>';
					
				}
			}
					
					
					
					
				}else{
					$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">This Email has already been used</b></p>  
    </div>';
					
				}
			}
					
					
					
					
				}else{
					
	$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">This Matric number has already been used </b></p>  
    </div>';				
					
				}
			}
				
				
				
		
		}
	}
	
	
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>..:ePortal&reg :<?php echo $projects_title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">



<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

	
  </head>
  <body>
  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand" href="#" style="color:green"><b> ePOrTAL&reg 2.1 </b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                <!-- header menu -->
				<?php include_once('../include/links.php') ?>
				<!-- end header menu -->
				
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:10px;">
<div style="height:500px;">
	          <div class="top-content">

            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-sm-offset-0 form-box">
						
						<div class="col-sm-8">
						
						<div class="form-bottom">
							
			                    <div class="login-form">
								<img src="assets/images/login.jpg" alt="login" class="login-card-img">
					
			                    </div>
		                    </div>
						
						
						
						
						
						
						</div>
						<div class="col-sm-4 form-box" id="content" style="background-color:#CCCCC">
						
						
						<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			<!-- <center><img src="images/<?php echo $project_sm_logo; ?>" width="30%"></center> -->
                            		 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 Create Account Here</span></h5>
                        		</div>                       		
                            </div>
							
							
							
							<div class="form-bottom">
							
			                    <form role="form" class="login-form" action="createAccont.php?token=<?php echo $token; ?>" method="POST">
			                    	<div class="form-group">
			                    		<label for="username">Enter Registration Number</label>
			                        	<input id="number" type="text" name="number" placeholder="Registration Number" class="form-control">
			                        </div>
									<div class="form-group">
			                    		<label for="username">Fullname (As it is writen on your Id Card or admission letter)</label>
			                        	<input id="fullname" type="text" name="fullname" placeholder="Fullname" class="form-control">
			                        </div>
									<div class="form-group">
			                    		<label for="gender">Gender</label>
			                        	<select class="form-control" id="gender" name="gender">
											<option></option>
											<option>Male</option>
											<option>Female</option>
										</select>
			                        </div>
									<div class="form-group">
			                        	<label for="password">Phone Number (Any valid Phone Number)</label>
			                        	<input id="phone_number" type="text" name="phone_number" placeholder="Phone Number" class="form-control">
			                        </div>
			                        <div class="form-group">
			                        	<label for="password">Email (Any valid Email)</label>
			                        	<input id="email" type="text" name="email" placeholder="Email" class="form-control">
			                        </div>
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button name="btn_Generate" class="btn btn-success" type="submit">
                            Create Account
                        </button>
						<hr/><div id="error" style="color:red"><?php echo $error; ?></div>
						
						<center>
						
					</div>
			                    </form>
								
		                    </div>
						
						</div>
						
						
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  

 </body>
 <html>