<?php
	if(isset($_GET['token'])){
		$token=$_GET['token'];
		include_once('../include/get_project_details.php');
		if(isset($_GET['number'])){
		  $App=$_GET['number'];
		  //g Applicant Name
		  $sql_get_name=mysqli_query($con,"SELECT *FROM students WHERE md5(number)='$App' AND project_id='$project_id'");
			
			if($sql_get_name){
				$sql_get_name_row=mysqli_num_rows($sql_get_name);
				if($sql_get_name_row > 0){
				$row=mysqli_fetch_assoc($sql_get_name);
				$app_name=$row['first_name'].' '.$row['other_names'];
				$phone_number=$row['phone_no'];
				$email=$row['email'];
				$number=$row['number'];
				$programme_id=$row['programme_id'];
				
				}
			}
		  
		  //set payment type to control the payment that will show
		   $sql_get_set_payment_fee=mysqli_query($con,"SELECT *FROM programmes WHERE project_id='$project_id' AND id='$programme_id'");
			if($sql_get_set_payment_fee){
				$sql_get_set_payment_fee_row=mysqli_num_rows($sql_get_set_payment_fee);
				if($sql_get_set_payment_fee_row > 0){
				$row=mysqli_fetch_assoc($sql_get_set_payment_fee);
				$amount=$row['programme_returning_student_fee'];
				
				
				}
			}
			
			
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
			//chk if the transaction ID has been Generated or not
			$sql_get_school_fee_payments=mysqli_query($con,"SELECT *FROM school_fee_payments WHERE project_id='$project_id'");
			if($sql_get_school_fee_payments){
				$school_fee_payments_row=mysqli_num_rows($sql_get_school_fee_payments);
				}
				
			$sql_get_school_fee_payments=mysqli_query($con,"SELECT *FROM school_fee_payments WHERE student_id='$App' AND project_id='$project_id'");
			if($sql_get_school_fee_payments){
				$sql_get_school_fee_payments_row=mysqli_num_rows($sql_get_school_fee_payments);
				if($sql_get_school_fee_payments_row > 0){
				$row=mysqli_fetch_assoc($sql_get_school_fee_payments);
				  $TID=$row['TID'];
				  
				}else{
				
				$n=$school_fee_payments_row;
				if($n < 10){
						$n="000".$n;
					}elseif($n < 100){
						$n="00".$n;
					}elseif($n < 1000){
						$n="0".$n;
					}elseif($n < 10000){
						$n=$n;
					}
					
					//rand no.
					$rand_no=rand(1000,9000);
					$TID=$project_code.$n.$rand_no.'-'.$n.'TID';
					
				    $sql=mysqli_query($con,"INSERT INTO school_fee_payments(student_id,TID,project_id) VALUES('$number','$TID','$project_id')");
				}
			}
			
			
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
		}
		
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>..:ePortal&reg :<?php echo $projects_title; ?></title>
<link href="../css/font_css.css" rel="stylesheet" type="text/css" />
<link href="../css/invoice.css" rel="stylesheet" type="text/css" />
    <style type="text/css">
        .auto-style1 {
            width: 63px;
            height: 79px;

        }
        .panel-heading{
            background:white;
        }
    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

</head>
<body>
    <form name="form1" method="post" action="" id="form1">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-lg-offset-1">    
                <div class="panel panel-default" id="invoice">
                    <div class="panel-heading" style="background:white">
                                                <div class="row">
                            <div class="col-lg-8">
                                <p><img src="images/<?php echo $project_sm_logo; ?>" title="Logo" ></p> 
                            </div>
                            <div class="col-lg-4 text-right">
                                                                <p><span class="label label-success">Pay onlin now</span></p>
                                                                
                                            </div>
                    <div class="panel-body">
                        
                        <div class="row">
                            <h3>Transaction ID <span class="badge"><span id="lblRRR"><?php echo $TID;?></span></span></h3>
                            <div class="col-xs-5">
                                <h4>Transaction Reference<span class="badge"><span id="lblTxnRef"></span></span></h4>
                                <h4>Invoice  <span class="badge"><span id="lblInvoiceNo">Ref/<?php echo $number;?></span></span></h4>
                                
                                <p>Invoice Date: <span id="lblDate"><?php echo date("Y/m/d");?></span></p>
                                </div>
                                <div class="col-xs-4">
                                    <h4>Invoiced To</h4>
                                    <p>
                                        <span id="lblFullname"><?php echo $app_name; ?></span><br> 
                                        <span id="lblTelephone"><?php echo $phone_number; ?></span><br>
                                        <span id="lblDepartment"><?php echo $email; ?></span>
                                                                            </p>
                                    
                                </div>
                                <div class="col-xs-3">
                                    <h4>Pay To</h4>
                                    <p><?php echo $projects_title ?>.<br>
<br>
                                    </p>
                                </div>
                            </div>
                        <br />
                            <table class="table table-bordered table-striped">
                                <tbody><tr>
                                    <th>SN</th>
									<th>Application Number</th>
                                    <th>Amount</th>
                                    <th>Payment Type</th>
                                </tr>
                                                                <tr>
                                    <td><span id="lblPaymentPurpose">1</span></td>
									 <td><span ><?php echo $number;?></span></td>
                                    <td><span id="lblAmount">=N=<?php echo $amount; ?></span></td>
                                    <td><span id="lblFeeType" style="font-weight:normal;">Returning Student School Fee</span></td>
                                </tr>
                                                                <tr>
                                    <td>&nbsp;</td>
                                    <td></td>
									 <td></td>
                                     <td></td>
                                </tr>

                                                                                                <tr>
                                    <td>&nbsp;</td>
                                    <td> </td>
									 <td></td>
									 
                                                                                                    <td></td>
                                </tr>
                                <tr class="info">
                                    <td>Total:</td>
                                    <td><span id="lbltotal" style="font-weight:bold;">=N=<?php echo $amount; ?></span></td>
                                    <td></td>
									 <td></td>
                                </tr>
                            </tbody></table>

                            
                            <h4></h4>
			<hr/>
			<table class="table table-bordered table-striped">
                                <tbody><tr>
                                    <th>SN</th>
									<th>Bank</th>
                                    <th>Account Name</th>
                                    <th>Account Number</th>
                                </tr>
							   
                         <?php
						 $sn=1;
		include_once('../include/connections.php');
		//set payment type to control the payment that will show
		  $sql_get_bank=mysqli_query($con,"SELECT *FROM bank_detail WHERE project_id='$project_id' AND status='1'");
			if($sql_get_bank){
				$sql_get_bank_row=mysqli_num_rows($sql_get_bank);
				if($sql_get_bank_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_bank)){
				   $Bank=$row['Bank'];
				   $Account_Name=$row['Account_Name'];
				   $Account_Number=$row['Account_Number'];
				   
				   echo '<tr>
                                    <td>'.$sn.'</td>
									<td>'.$Bank.'</td>
                                    <td>'.$Account_Name.'</td>
                                    <td>'.$Account_Number.'</td>
                                </tr>';
								
								$sn=$sn + 1;
				}
				
				
				
				}
			}
						 
						 ?>
						 </tbody></table>
                            <table class="table table-striped">
                                <tbody><tr>
                                    <td>
                                        <span id="lblInstruction"></span> </td>
                                </tr>
                                                                <tr>
                                    <td><span id="lblCategoryName" style="color:#FF3300;">Kindly ensure your payment is made with your Transaction ID generated from the Portal</span></td>
                                </tr>
                                                                <tr>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;</td>
                                </tr>
                                                           
                            </tbody></table>

                            
                            <p class="">Powered By itbeaz</p>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-lg-9 col-lg-offset-1 text-right" >
                    <a href="index.php?token=<?php echo $token; ?>" class="btn btn-link"><< Back</a><a href="#" class="btn btn-default btn-sm btn-success" onclick="printDiv('invoice')">Print Page</a>
                </div>
            </div>
        </div>
      </div>
	   </div>
    </form>

</body>
</html>
