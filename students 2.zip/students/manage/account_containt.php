<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			
                            		 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 Login here</span></h5>
                        		</div>                       		
                            </div>
			
							<div class="form-bottom">
			                    <form role="form" class="login-form">
			                    	<div class="form-group">
			                    		<label class="sr-only" for="username">User ID</label>
			                        	<input id="username" type="text" name="form-username" placeholder="User ID" class="form-control">
			                        </div>
			                        <div class="form-group">
			                        	<label class="sr-only" for="password">Password</label>
			                        	<input id="password" type="password" name="form-password" placeholder="Password..." class="form-control">
										<input id="token" type="hidden" value="<?php echo $system_code;?>">
			                        </div>
			                        <div class="form-actions" style="margin-top:20px;padding-bottom:20px;">
							
                        <button id="btn_login" onclick="student_portal_login()" class="btn btn-success" type="button">
                            Sign in
                        </button>
						<hr/><div id="error" style="color:red"></div>
					
						<center>
						<a role="button" style="margin-top:3px;" class="btn btn-info glyphicon glyphicon-home" href="http://<?php echo $website; ?>">School Website</a>

						
						<a role="button" style="margin-top:3px;" class="btn btn-danger glyphicon glyphicon-edit" href="#">Reset Password</a></center>
                    </div>
			                    </form>
		                    </div>