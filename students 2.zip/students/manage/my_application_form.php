<?php
$error ='';
	if(isset($_GET['token'])){
		 $contact_person="";
	    $token=$_GET['token'];
		include_once('../include/get_project_details.php');
		
if(isset($_POST['myApplicationForm'])){
		$first_name=$_POST['first_name'];
		$other_names=$_POST['other_names'];
		$email=$_POST['email'];
		$phone_number=$_POST['phone_number'];
		$course=$_POST['course'];
		$gender=$_POST['gender'];
		$fn=$first_name.' '.$other_names;
		if(empty($first_name)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your firstname</b></p>  
    </div>';
		}elseif(empty($other_names)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Other name</b></p>  
    </div>';
		}elseif(empty($gender)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Select your gender</b></p>  
    </div>';
		}
		
		
		elseif(empty($email)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Email</b></p>  
    </div>';
		}elseif(empty($phone_number)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Enter your Phone Number</b></p>  
    </div>';
		}elseif(empty($course)){
			$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Please Select the course you are applying for</b></p>  
    </div>';
		}else{
			
			
			$sql_generate=mysqli_query($con,"SELECT *FROM applicants WHERE email='$email' AND project_id='$project_id'");
			if($sql_generate){
				
				$sql_generate_row=mysqli_num_rows($sql_generate);
				if($sql_generate_row > 0){
					//the email exist
					$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">This email has been used, please use another email</b></p>  
    </div>';
				}else{
					//the email is available
					//chk id the phone number exist or not
			$sqlPhoneno=mysqli_query($con,"SELECT *FROM applicants WHERE phone_no='$phone_number' AND project_id='$project_id'");
			if($sqlPhoneno){
				
				$sqlPhoneno_row=mysqli_num_rows($sqlPhoneno);
				if($sqlPhoneno_row > 0){
					//phone number exist
					$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">This phone number has been used, please use another phone number</b></p>  
    </div>';
				}else{
					
					//phone number is available
					//generate the application number, application pin and serial
					//update the application table and send the details to the student's phone number
					
						
					$sql_chk=mysqli_query($con,"SELECT *FROM applicants WHERE project_id='$project_id'") or die(mysql_error());
					if($sql_chk){
						$sql_chk_row=mysqli_num_rows($sql_chk);
					
						if($sql_chk_row > 0){
							
							$n =$sql_chk_row + 1;
							
						}else{
							
							$n=1;
						}
					if($n < 10){
						$n="000".$n;
					}elseif($n < 100){
						$n="00".$n;
					}elseif($n < 1000){
						$n="0".$n;
					}elseif($n < 10000){
						$n=$n;
					}
					
					//gett project code
					
					//gett session year code
					 $dt_y=date("Y");
					$n=$project_code.'/APP/'.$dt_y.'/'.$n;
					
					//chk if the application number exist
					$sql_app_number=mysqli_query($con,"SELECT *FROM applicants WHERE number='$n' AND project_id='$project_id'");
			if($sql_app_number){
				$sql_app_number_row=mysqli_num_rows($sql_app_number);
				if($sql_app_number_row > 0){
					
					$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Sorry! something went wrong generating your application, Please try again.</b></p>  
    </div>';
				}else{
					
			//get the programme_id
			$sql_programme_id=mysqli_query($con,"SELECT *FROM programmes WHERE title='$course' AND project_id='$project_id'");
			if($sql_programme_id){
				$sql_programme_id_row=mysqli_num_rows($sql_programme_id);
				if($sql_programme_id_row > 0){
					$row_sql_programme_id=mysqli_fetch_array($sql_programme_id);
					$programme_id=$row_sql_programme_id['id'];
				}
			}
					//store applicatnt infor
			$dt=date("Y/m/d");
			$sql_store=mysqli_query($con,"INSERT INTO applicants(number,first_name,other_names,phone_no,gender,email,programme_id,date_added,project_id) VALUES('$n','$first_name','$other_names','$phone_number','$gender','$email','$programme_id','$dt','$project_id')");
			
				if($sql_store){
					$error=' <div class="alert alert-info">
        <button class="close" type="button" data-dismiss="alert">X</button>
        <p><b style="color:red">Your application has been submited, Your application number has been 
		sent to your mobile phone number, you can proceed to make your payment with your Application Number. 
		
		</b></p>  
    </div>';
	
	//send the sms
			//include_once('../includes/sms.php');
			//display the Application Id for the applicant to print
			$n=md5($n);
			header("location:invoice.php?token=$system_code&App=$n");
			//sms($phone_number,'Dear '.$fn.', Your Application number is:'.$n.' ');
			//$error=' <div class="alert alert-info">Your Application form has been Submited, Please generate your Application form payment invoice</div>	';
			

			}
				}
			}
					
					
					
					
					}
				}
			}
				}
			}
		}
		}
	}else{
		header('location:http://www.google.com');
	}
?>
<!DOCTYPE html>
<html>
  <head>
    <title>..:ePortal&reg :<?php echo $projects_title; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../login/css/docs.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="../js/script.js"></script>
	 <script type="text/javascript" src="../js/jquery.js"></script>
     <link rel="shortcut icon" href="images/<?php echo $project_sm_logo ?>" type="image/x-icon" />
   
    <link rel="stylesheet" href="../bootstrap-3.3.4/css/bootstrap.css">

	
	<script type="text/javascript" src="../bootstrap-3.3.4/js/bootstrap.js"></script>

	
  </head>
  <body>


  <div class="container ">


				<!-- header goes here -->
                <div id="header">
                	<div class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button class="navbar-toggle collapsed" data-target=".navbar-collapse" data-toggle="collapse" type="button">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>

				<a class="navbar-brand" href="#" style="color:green"><b> ePOrTAL&reg 2.1 </b></a>
			</div>
			<div class="navbar-collapse collapse" style="height: 1px;">
				
                <!-- header menu -->
                <ul class="nav navbar-nav">
                
                <!-- Print  The Function of header menu here -->
                
               

				</ul>
                
                 <!-- header menu -->
				<?php include_once('../include/links.php') ?>
				<!-- end header menu -->
			</div>
		</div>
</div>
                </div>
                
 
 <div class="row" style="margin-top:10px;">
<div style="height:500px;">
	          <div class="top-content">

            <div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-sm-offset-0 form-box">
						
						<div class="col-sm-8">
						  <div class="form-bottom">
							
			                    <div class="login-form">
			                    	
		<div class="panel panel-default">
  <div class="panel-heading">INSTRUCTION:
Please read the instruction carefully</div>
  <div class="panel-body">
		<ul>
		<li>
			<p>
			Please fill all the required fields to process your Application Form, Make sure you use a valid email and Phone Number, 
			Select the course you are Applying for and click submit button to generate your Invoice 
			</p>
		</li>
		<li>
			<p>Your Application Number will be on the invoice slip</p>
		</li>
		<li>
			<p>
			You can always re-print your Invoice Slip by clicking on the Prospective Student >>Reprint Invoice Slip to reprint the Slip 
			</p>
		</li>
		<li>
			<p>
			If you have already generated your Payment Invoice and you have made the payment, you should wait for twenty four (24) hour for your payment to be confirmed.  
			</p>
		</li>
		
		
		<li>
			<p>
			If you did not receive a confirmation message via your phone number, twenty four (24) hour after your payment, Please contact the administrator.
			</p>
		</li>
		
		<li>
			<p>
			As soon as your payment is confirmed, you will receive a confirmation message with your login details via the phone number provided earlier. 
			</p>
		</li>
		
		<li>
			<p>
			Click on Application Account to login and complete your Application. 
			</p>
		</li>
		<hr/>
		<li>
			<p style="color:green;"><b>LOGIN: For any difficulty Click here or call our support line: 07035503636,08034598639,08148046175</b></p>
		</li>
		
	</ul>
  </div>
</div>
	
					
			                    </div>
		                    </div>
						</div>
						<div class="col-sm-4 form-box" id="content" style="background-color:#CCCCC">
						
						
						<div class="form-top">
                        		<div class="form-top-center" style="width:100%;">
                        			<center><img src="images/<?php echo $project_sm_logo; ?>" width="30%"></center>
									 <h5><span class="label label-success">
									 <span class="glyphicon glyphicon-hand-right" aria-hidden="true"></span>
									 Prospective Students >> Generate Payment Invoice</span></h5>
                            		
                        		</div>                       		
                            </div>
							
							<div class="form-bottom">
  <div class="form-group">
	<div class="row">
	
	<form action="my_application_form.php?token=<?php echo $token;?>" method="POST">
  <div class="form-group">
	<div class="row">
  <div class="col-xs-6" style="padding-left:0px;padding-right:0px;">
    <input name="first_name" type="text" class="form-control" placeholder="First Name">
  </div>
  <div class="col-xs-6" style="padding-left:0px;padding-right:0px;">
    <input name="other_names" type="text" class="form-control" placeholder="Other Names">
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Gender</label>
	<select name="gender" class="form-control">
		<option></option>
		<option>Male</option>
		<option>Female</option>
	</select>
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Email</label>
	<input name="email" type="text" class="form-control" placeholder="Email">
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Applicant's Phone Number</label>
	<input name="phone_number" type="text" class="form-control" placeholder="Applicant's Phone Number">
  </div>
  <div class="col-xs-12" style="padding-top:5px;">
   <label class="control-label" for="inputSuccess2">Course Applying for</label>
	<select name="course" class="form-control">
		<option></option>
		
		<?php
		
		include_once('../include/connections.php');
		$sql_get_programme=mysqli_query($con,"SELECT *FROM programmes WHERE project_id='$project_id' AND status='1'");
		if($sql_get_programme){
			$sql_get_programme_row=mysqli_num_rows($sql_get_programme);
			if($sql_get_programme_row > 0){
				While($get_title=mysqli_fetch_array($sql_get_programme)){
					$p_title=$get_title['title'];
				
				echo '<option>'.$p_title.'</option>';
				}
				
			}
		}
		?>
	</select>
  </div>
  
 <div class="col-md-12"><?php echo $error; ?></div>
  <div class="col-xs-12" style="padding-top:5px;">
   <button type="submit" name="myApplicationForm" type="button" class="btn btn-success">Submit</button>
  </div>
  
</div>

</form>
	</h4>
  </h5>
</div>
    </div>
			                
		                    </div>
									
			
			                       
			                    
		                    </div>
						
						</div>
						
						
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 social-login">
                        
                        	<div class="social-login-buttons">
	                        	<a class="btn btn-link-1 btn-link-1-facebook" href="#">
	                        		<i class="fa fa-facebook"></i> Facebook
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-twitter" href="#">
	                        		<i class="fa fa-twitter"></i> Twitter
	                        	</a>
	                        	<a class="btn btn-link-1 btn-link-1-google-plus" href="#">
	                        		<i class="fa fa-google-plus"></i> Google Plus
	                        	</a>
                        	</div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
</div>
                </div>
				<!-- /tab menu -->
                
                <!-- footer -->
                <!-- /footer -->
		
			
	
	</div>
  

 </body>
 <html>