<?php 
error_reporting(0);
session_start();
	//get session

	include_once('../include/connections.php');
require_once('../fpdf/fpdf.php');
$programme_id='12';
$pdf = new FPDF();
	$sql_run = mysqli_query($con,"SELECT *FROM student_information WHERE programme_id='$programme_id' AND level='300 Level' AND cleared_status='0' ORDER BY number ");
		if($sql_run){
		    
	
		$no_of_rows=mysqli_num_rows($sql_run);
		if($no_of_rows > 0){
			 while($record = mysqli_fetch_assoc($sql_run)){
			$id=$record['id']; 
		$student_id=$record['id'];
		$img=$record['image'];
		$number=$record['number'];
		$program=$record['programme_id'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$first_name=$first_name.' '.$other_names;
		$level=$record['level'];
		$project_id=$record['project_id'];

        
		$faculty=$record['faculty'];
		$id=$record['id']; 
		$student_id=$record['id'];
		$img=$record['image'];
		$number=$record['number'];
		$program=$record['programme_id'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$first_name=$first_name.' '.$other_names;
		$level=$record['level'];
		$project_id=$record['project_id'];
		$hostel_eligibility=$record['hostel_eligibility'];
		$faculty=$record['faculty'];
		 
		
		
		$query=mysqli_query($con,"SELECT title,department_id FROM programmes WHERE id='$program'");
		$row=mysqli_fetch_assoc($query);
		$course=$row['title'];
		$department=$row['department_id'];
		//$address=$row['address'];
		
			$query=mysqli_query($con,"SELECT title FROM students_departments WHERE id='$department'");
		$row=mysqli_fetch_assoc($query);
		$department=$row['title'];
		
		
		
		$maritalstatus=$record['marital_status'];
		$gender=$record['gender'];
		$medication=$record['medi'];
		$H_status=$record['H_status'];
		$std_date=$record['dob'];
		$email=$record['email'];
		$address=$record['address'];
		$phone_no=$record['phone_no'];
		$sponsorship_name=$record['sponsorship_name'];
		$sponsorship_address=$record['sponsorship_address'];
		$sponsorship_number=$record['sponsor_number'];
		$state=$record['state_id'];
		$query=mysqli_query($con,"SELECT title FROM state WHERE id='$state'");
		$row=mysqli_fetch_assoc($query);
		$state=$row['title'];
		
		$lga=$record['lga_id'];
		$query=mysqli_query($con,"SELECT title FROM lga WHERE id='$lga'");
		$row=mysqli_fetch_assoc($query);
		
		$lga=$row['title'];
		$status=$record['marital_status'];
		$medication=$record['medi'];
		$blood_group=$record['blood_type'];
		$disability=$record['disability'];
		$mat_no=$record['number'];
		$student_type=$record['student_type'];
		
		$permenat_address=$record['permanent_address'];
		//$state_title=$record['state_title'];
		//$lga_title=$record['lga_title'];
		$religion=$record['religion'];
		
		
		$kin_address=$record['kin_address'];
		$kin_phone_number=$record['kin_phone_number'];
		$kin_relationship=$record['kin_relationship'];
		$kin_name=$record['kin_name'];
		
		
		$state_title="";
		$lga_title="";
	
				
	
	$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$header_image=$row['header_image'];
					$crf_image=$row['crf_image'];
					
					$header_image='images/'.$header_image;
					$crf_image='images/CRF2018.png';
				}
			}
		}
		
		
		
		
		
				$e = "images/f_e_header.png";
		
		$pdf  -> AddPage();

$pdf  -> Image($crf_image,40,6);



$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"BIO-DATA",0,1,'l');

$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(70,8,"MATRICULATION NO: {$number}",1,0,'L');
$pdf  -> Cell(0,8,"NAME: {$first_name}",1,1,'L');


$pdf  -> Cell(0,5,"DEPARTMENT: {$department}",1,1,'L');
$pdf  -> Cell(0,5,"PROGRAMM: {$course}",1,1,'L');
$pdf  -> Cell(0,5,"LEVEL: {$level}",1,1,'L');

$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(70,15,"Second Semester Course Registration",0,1,'L');
$pdf  -> Cell(10,1,"_________________________________________________________________________________________________________________________",0,1,'L');




$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"SN",1,0,'L');
$pdf  -> Cell(50,5,"CODE",1,0,'L');
$pdf  -> Cell(100,5,"COURSE TITLE",1,0,'L');
$pdf  -> Cell(20,5,"UNIT",1,1,'L');

$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,1,"",0,1,'C');
$pdf  -> SetFont("Arial","",10);

$sn=1;
$course_unit_total=0;

include_once('include/DBConnections.php');

$sqlget=mysqli_query($con,"SELECT *FROM programmes_courses WHERE level='300 Level' AND programme_id='$programme_id' AND session_id='4' AND semester='2'");

if($sqlget){
	$sqlget_row=mysqli_num_rows($sqlget);
	if($sqlget_row > 0){
		while($row=mysqli_fetch_array($sqlget)){
			
			$course_id=$row['course_id'];
			
		$sql_get_course=mysqli_query($con,"SELECT *FROM courses WHERE id='$course_id'");
		if($sql_get_course){
			$sql_get_course_row=mysqli_num_rows($sql_get_course);
			if($sql_get_course_row > 0){
				$ro=mysqli_fetch_array($sql_get_course);
					$course_title=$ro['title'];
					$course_code=$ro['code'];
					$course_unit=$ro['unit'];
			
			
			        	$rC .=$course_code.',';	
			}
		}
		

$pdf  -> Cell(20,8,"{$sn}",1,0,'L');
$pdf  -> Cell(50,8,"{$course_code}",1,0,'L');
$pdf  -> Cell(100,8,"{$course_title}",1,0,'L');
$pdf  -> Cell(20,8,"{$course_unit}",1,1,'L');



$sn=$sn + 1;
$course_unit_total=$course_unit_total+ $course_unit;
		}
		

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"",1,0,'L');
$pdf  -> Cell(50,5,"",1,0,'L');
$pdf  -> Cell(100,5,"Total Unit",1,0,'L');
$pdf  -> Cell(20,5,"{$course_unit_total}",1,1,'L');

	}
}





$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(70,5,"__________________________________",0,0,'L');
$pdf  -> Cell(70,5,"__________________________________",0,0,'L');
$pdf  -> Cell(50,5,"________________________________",0,1,'L');

$pdf  -> Cell(70,5,"Signature of Student & Date",0,0,'L');
$pdf  -> Cell(70,5,"Signature of Academic Sec. & Date",0,0,'L');
$pdf  -> Cell(50,5,"Signature of Dean & Date",0,1,'L');






$pdf  -> SetFont("Arial","B",5);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"Source: Fati Lami Abubakar Institute of Legal and Administrative Studies, Minna Online Registration Portal, 2016/2017 Academic Session.",0,0,'l');










$pdf  -> AddPage();


$pdf  -> Image($e,40,6);

//$pdf  -> Image($path,165,25,30,30);
$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"Second Semester",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(50,5,"MATRICULATION NO: {$number}",1,0,'L');
$pdf  -> Cell(50,5,"NAME: {$first_name}",1,0,'L');
$pdf  -> Cell(0,5,"Programme: {$course}",1,1,'L');


$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> Cell(0,10,"Registered Courses",0,1,'l');


$pdf  -> multiCell(0,5,"{$rC}");

$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,2,"",0,1,'C');

$pdf  -> Cell(190,5,"DOS AND DON'T",1,1,'C');
$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,1,"",0,1,'C');

$pdf  -> Cell(0,5,"1. Candidates MUST be in the vicinity of the examination room 10 Minutes before the examination is due to begin.",0,1,'l');
$pdf  -> Cell(0,5,"2. Students MUST sit according to the sitting arrangement set out by the college exams committee which could be by ",0,1,'l');
$pdf  -> Cell(0,5,"  i.	Sitting at the desks with numbers corresponding to those on their admission cards and these desks MUST NOT be moved from",0,1,'l');
$pdf  -> Cell(0,5,"  their original positions",0,1,'l');

$pdf  -> Cell(0,5,"  ii. Or asking students to be a single file while they enter in turn and are placed on seats randomly by the invigilators or members.",0,1,'l');
$pdf  -> Cell(0,5,"  of the exams committee",0,1,'l');

$pdf  -> Cell(0,5,"3. Papers of any kind MUST NOT be brought into the exams room. All bags containing textbooks, handouts, magazines etc must be",0,1,'l');
$pdf  -> Cell(0,5,"deposited outside the exam room before students enter. Bags and wallets containing valuables should be kept in front of the room.",0,1,'l');


$pdf  -> multiCell(0,5,"4. Candidate's exams number MUST be written on the front page of the answer sheet and on each separate sheet in the booklet");

$pdf  -> multiCell(0,5,"Candidate's Matric number, Course code, course title, department,semester and date of examination must be filled in as provided on the answer sheet.");


$pdf  -> multiCell(0,5,"5. A candidate arriving late shall be admitted up to 30 minutes after the start of the examination but shall not be allowed extra time. If he arrives more than 30 minutes late before one half of the total duration of the examination, it will be left to examination officer to admit him/her if he is certified that the candidate has good reasons for his lateness and provided that no candidates has already left the room");


$pdf  -> multiCell(0,5,"6. A candidate will NOT be permitted to leave the exam room earlier than 30 minutes after the commencement of the examination.");

$pdf  -> multiCell(0,5,"7. Candidates are required to hand in their examination booklet to the invigilator in an orderly manner, sign the attendance sheet and move out of the examination room quietly.");

$pdf  -> multiCell(0,5,"8. No smoking or chewing when exam is in progress.");

$pdf  -> multiCell(0,5,"9. Under no circumstances must students exchange anything or exam materials such as rulers, pen, eraser etc during the examination. If a candidate must borrow anything this should be done through the invigilator.  Talking of any kind is not allowed. All questions should be directed to the invigilator. Any one who needs the attention of the invigilator should signify by rising up his/her hand. Absolute silence MUST be maintained during exams.");

$pdf  -> multiCell(0,5,"10.	Students MUST NOT write anything on their exam question paper any rough work should be done in the sheet which could be neatly crossed out later. ");




$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"[     ]  I {$first_name} have read the  Exam rules and regulations carefully and i will abide by the rules and regulations stated.",0,1,'l');
$pdf-> Ln(2);


$pdf  -> Cell(0,15,"________________________________",0,1,'R');

$pdf  -> Cell(0,5,"Signature of Dean & Stamp",0,1,'R');	

$rC="";
		 
			 }
			 
			 
		$pdf -> Output();
		}
		}else{
		    echo "Nill";
		}
		
		
		
	?>