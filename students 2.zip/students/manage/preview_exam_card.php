<?php 
//error_reporting(0);
session_start();
require_once('../fpdf/fpdf.php');
include_once("../php/get_student_profile.php");

$sql_get_sessions=mysqli_query($con,"SELECT *FROM sessions WHERE status='1' AND project_id='$project_id'");
		if($sql_get_sessions){
			$sql_get_sessions_row=mysqli_num_rows($sql_get_sessions);
			if($sql_get_sessions_row > 0){
				$row2=mysqli_fetch_assoc($sql_get_sessions);
					$current_semester=$row2['current_semester'];
					$title=$row2['title'];
					if($current_semester==1){
					   $current_semester="First Semester";
					}elseif($current_semester==2){
					   $current_semester="Second Semester";
					}
				
			}
		}
		
if($img =="" ){
		$path = "uploads/0.png";
	}else{
		$path = "uploads/".$img;
	}
	
	$e = "images/f_e_header.png";
	
	
	$pdf = new FPDF();
$pdf  -> AddPage();

$pdf  -> Image($e,40,6);

$pdf  -> Image($path,165,25,30,30);
$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,40,"",0,1,'C');
$pdf  -> Cell(0,10,"Second Semester",0,1,'l');

$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(50,5,"MATRICULATION NO: {$number}",1,0,'L');
$pdf  -> Cell(50,5,"NAME: {$first_name}",1,0,'L');
$pdf  -> Cell(0,5,"Programme: {$course}",1,1,'L');



$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,2,"",0,1,'C');

$pdf  -> Cell(190,5,"DOS AND DON'T",1,1,'C');
$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,1,"",0,1,'C');

$pdf  -> Cell(0,5,"1. Candidates MUST be in the vicinity of the examination room 10 Minutes before the examination is due to begin.",0,1,'l');
$pdf  -> Cell(0,5,"2. Students MUST sit according to the sitting arrangement set out by the college exams committee which could be by ",0,1,'l');
$pdf  -> Cell(0,5,"  i.	Sitting at the desks with numbers corresponding to those on their admission cards and these desks MUST NOT be moved from",0,1,'l');
$pdf  -> Cell(0,5,"  their original positions",0,1,'l');

$pdf  -> Cell(0,5,"  ii. Or asking students to be a single file while they enter in turn and are placed on seats randomly by the invigilators or members.",0,1,'l');
$pdf  -> Cell(0,5,"  of the exams committee",0,1,'l');

$pdf  -> Cell(0,5,"3. Papers of any kind MUST NOT be brought into the exams room. All bags containing textbooks, handouts, magazines etc must be",0,1,'l');
$pdf  -> Cell(0,5,"deposited outside the exam room before students enter. Bags and wallets containing valuables should be kept in front of the room.",0,1,'l');


$pdf  -> multiCell(0,5,"4. Candidate's exams number MUST be written on the front page of the answer sheet and on each separate sheet in the booklet");

$pdf  -> multiCell(0,5,"Candidate's Matric number, Course code, course title, department,semester and date of examination must be filled in as provided on the answer sheet.");


$pdf  -> multiCell(0,5,"5. A candidate arriving late shall be admitted up to 30 minutes after the start of the examination but shall not be allowed extra time. If he arrives more than 30 minutes late before one half of the total duration of the examination, it will be left to examination officer to admit him/her if he is certified that the candidate has good reasons for his lateness and provided that no candidates has already left the room");


$pdf  -> multiCell(0,5,"6. A candidate will NOT be permitted to leave the exam room earlier than 30 minutes after the commencement of the examination.");

$pdf  -> multiCell(0,5,"7. Candidates are required to hand in their examination booklet to the invigilator in an orderly manner, sign the attendance sheet and move out of the examination room quietly.");

$pdf  -> multiCell(0,5,"8. No smoking or chewing when exam is in progress.");

$pdf  -> multiCell(0,5,"9. Under no circumstances must students exchange anything or exam materials such as rulers, pen, eraser etc during the examination. If a candidate must borrow anything this should be done through the invigilator.  Talking of any kind is not allowed. All questions should be directed to the invigilator. Any one who needs the attention of the invigilator should signify by rising up his/her hand. Absolute silence MUST be maintained during exams.");

$pdf  -> multiCell(0,5,"10.	Students MUST NOT write anything on their exam question paper any rough work should be done in the sheet which could be neatly crossed out later. ");




$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"[     ]  I {$first_name} have read the  Exam rules and regulations carefully and i will abide by the rules and regulations stated.",0,1,'l');
$pdf-> Ln(2);


$pdf  -> Cell(0,15,"________________________________",0,1,'R');

$pdf  -> Cell(0,5,"Signature of Exam Officer & Stamp",0,1,'R');

$pdf  -> SetFont("Arial","B",9);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> multiCell(0,10,"NOTE: Bring along with you to the exam hall, your Institute's ID Card, Institute's original Receipt, Payment Teller(s) And your course registration form.");


$pdf -> Output();




?>