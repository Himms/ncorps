<?php
	
$mat=$_POST['mat'];
$email=$_POST['email'];
$phone_number=$_POST['phone_number'];
$tid_type=$_POST['tid_type'];

$dt="1";
//get current session
$session="2016-2017";

//get fee amont
$amount="40,000";

if(!empty($mat) && !empty($email) && !empty($phone_number)){
	include_once("../include/connections.php");
	$sql = "SELECT *FROM students WHERE number='$mat' AND email='$email' AND phone_no='$phone_number'";
		$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){	
		
			
			$record = mysqli_fetch_assoc($sql_run);
			$student_id=$record['id'];
			//chk if u hav generated Tid
			$sql = "SELECT *FROM school_fee_payments WHERE student_id='$student_id' AND session='$session' AND payment_type='$tid_type'";
			$sql_run = mysqli_query($con, $sql);
			if($no_of_rows=mysqli_num_rows($sql_run) > 0){
				echo'
			 <div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  	Your TID already Exist, Please Make sure you are using your information to generate your Tid, Contact the Administrator for more information.<br/>
  <a href="">TRY AGAIN</a> 
</div>
			 ';
			}else{
			
				$tid="";
				$c1=mt_rand(100,900);
				
				$tid.=$mat.'-'.$c1;
				$tid.="2016";
				
				$sql = "INSERT INTO school_fee_payments(student_id,session,payment_type,TID,amount,date_added) 		VALUES('$student_id','$session','$tid_type','$tid','$amount','$dt')";
		$sql_run = mysqli_query($con, $sql);
		if($sql_run ){
			echo'
			 <div class="alert alert-success" role="alert">
  <span class="glyphicon glyphicon-exclamation-ok" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
 	Your TID has been Generated Successfully, You can now pay your fee using the TID as the depositor. See the detail bellow

</div>
<div class="list-group">
  <a href="#" class="list-group-item disabled">
    Your TID Detail 
  </a>
  <a href="#" class="list-group-item">MATRIC NUMBER: '.$mat.' </a>
  <a href="#" class="list-group-item">PHONE NUMBER: '.$phone_number.'</a>
  <a href="#" class="list-group-item">EMAIL: '.$email.'</a>
  <a href="#" class="list-group-item">TID: '.$tid.'</a>
</div>
<div class="list-group">
  <a href="#" class="list-group-item disabled">
    School Account Detail
  </a>
 ';
  	
  	//get school account detail
  	$i=1;
  	$sql = "SELECT *FROM bank_detail";
	$sql_run = mysqli_query($con, $sql);
		if($no_of_rows=mysqli_num_rows($sql_run) > 0){
			while($record = mysqli_fetch_assoc($sql_run)){
				$bank_name=$record['bank_name'];
				$bank_name=$record['account_name'];
				$account_number=$record['account_number'];
				
				echo '<a href="#" class="list-group-item">	
  				('.$i.') Bank Name: '.$bank_name.'-- Account Name: ' .$account_name.' -- Account Number: '.$account_number.
					'</a>';
					
					
					$i=$i +1;
			}
			
		}else{
			echo '<a href="#" class="list-group-item">No Bank Detail Uploaded yet </a>';
		}
  	 

  echo '  

</div>	
 <hr/><br/> <center><a href="">Click to go back</a> </center>
			 ';
		}else{
		
			echo'
			 <div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
	Something went wrong generating your TID, Please Make sure you are having internet connection.
  <hr/><br/><a href="">TRY AGAIN</a> 
</div>
			 ';
		}
				
				
				
				
				
				
				
				
			}
			
		}else{
		
		echo'
			 <div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  Please Enter Valid Data, Your Matric Number, Phone Number And Email Must be Valid, For more infomation on this, Please Contact the Administrator<br/>
  <a href="">TRY AGAIN</a> 
</div>
			 ';
		}
		
	

}else{

	echo'
			 <div class="alert alert-danger" role="alert">
  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
  <span class="sr-only">Error:</span>
  Please Enter required data
  <br/>
   <a href="">TRY AGAIN</a> 
</div>
			 ';
}

?>