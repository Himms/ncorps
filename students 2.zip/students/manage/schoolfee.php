<?php

include_once('../include/connections.php');
$dbServer = "ibbu.edu.ng";
$dbUser = "xbbue9x";
$dbPass = "^TOtallyquasing*ProgrammiNG(ifX=&,--_+.Rw";
$dbN = "xbbue9x_data_sync";
// create connection
$connn = new mysqli($dbServer, $dbUser, $dbPass, $dbN);


	$dbServerName = "portals.ibbu.edu.ng";
$dbUsername = "portalsi_syncdba";
$dbPassword = "765QWE119ssjXxxX";
$dbName = "portalsi_UGRegSyncDB";
// create connection
$conn = new mysqli($dbServerName, $dbUsername, $dbPassword, $dbName);




$sn=1;

     $check_my_acc = mysqli_query($con,"SELECT *FROM hostel_allocation");
				if($check_my_acc){
				    $check_my_acc_row=mysqli_num_rows($check_my_acc);
					if($check_my_acc_row > 0){
						while($get_my_room_info = mysqli_fetch_array($check_my_acc)){
						$std_id = $get_my_room_info['std_id'];
						$room_info_room_id = $get_my_room_info['room_id'];
						$room_info_site_id = $get_my_room_info['hostel_site'];
					    $room_info_block_id = $get_my_room_info['hostel_categories'];
					    
					    
	$sqli_chk_school_fee=mysqli_query($conn,"SELECT *FROM student_payment_list WHERE jamb_matric_no='$std_id'");
	if($sqli_chk_school_fee){
		$sqli_chk_school_fee_row=mysqli_num_rows($sqli_chk_school_fee);
		if($sqli_chk_school_fee_row > 0){
		    $payment="School fee payment Confirmed";
		}else{
		    $payment="School fee payment Not Confirmed";
		}
	}
					    
		$sql=mysqli_query($connn,"SELECT *FROM student_eligibility WHERE student_matric_number='$std_id' AND payment_status='0' AND p='0'");
								if($sql){
									$sql_row=mysqli_num_rows($sql);
									if($sql_row > 0){
									    
									if($payment=='School fee payment Not Confirmed'){
									    $mm = mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_info_room_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_room = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_categories  WHERE id='$room_info_block_id'");
							$ronn = mysqli_fetch_array($mm);
							$title_block = $ronn ['title'];
							
						$mm = mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$room_info_site_id' ");
						$ronn = mysqli_fetch_array($mm);
							$site_title = $ronn ['title'];
						
						$bedspace=$site_title.'-'.$title_block.'-'.$title_room;
						
						
					    echo $sn.' - '.$std_id.' - '.$bedspace.' - '.$payment.'<br/>';
					
					    //deallocate
					     
					$sn=$sn + 1;
									}
					    
					
					
									}
								}	
								
								
								
								
	
								
					    		
					
					
					
					
					
					}
				}
}


?>