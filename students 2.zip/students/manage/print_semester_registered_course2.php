<?php 
error_reporting(0);
session_start();
if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	}else{
		header('location:logout.php');
	}
	//get session
	$token_sm=$_GET['token_sm'];
		$token=$_GET['token'];
	include_once('../include/connections.php');
	include_once("../include/GetCurrentSession.php");
	$current_session=str_replace("/","_",$session_title);
	
	
	$sql_getSession=mysqli_query($con,"SELECT *FROM sessions WHERE md5(id)='$token'");
					if($sql_getSession){
						$sql_getSession_row=mysqli_num_rows($sql_getSession);
						if($sql_getSession_row > 0){
							
							$get_session=mysqli_fetch_array($sql_getSession);
							$session_id=$get_session['id'];
							$session_title=$get_session['title'];
							$semester=$get_session['semester'];
						}
					}
					


	
require_once('../fpdf/fpdf.php');
include_once('../include/connections.php');
include_once("../include/connections.php");

	if(isset($_SESSION['student_portal_login_id'])){
		$student_portal_login_id= $_SESSION['student_portal_login_id'];
	$userType= $_SESSION['student_user_type'];
	$project_id= $_SESSION['project_id'];
	$email= $_SESSION['email'];
	}
	
	include_once("../include/GetCurrentSession.php");
$current_session=str_replace("/","_",$session_title);
	
		if($userType==1){
		$sql = "SELECT *FROM students_".$current_session." WHERE email='$email' AND  status='1'";
	}else{
		 $sql = "SELECT *FROM applicants_".$current_session." WHERE email='$email' AND user_status='1'";
	}
		
		$sql_run = mysqli_query($con, $sql);
		$no_of_rows=mysqli_num_rows($sql_run);
		if( $no_of_rows > 0){
			 $record = mysqli_fetch_assoc($sql_run);
		$id=$record['id']; 
		$student_id=$record['id'];
		$img=$record['image'];
		$number=$record['number'];
		$surname=$record['surname'];
		$first_name=$record['first_name'];
		$other_names=$record['other_names'];
		$full_name=$surname.' '.$first_name.' '.$other_names;
		$project_id=$record['project_id'];
		$hostel_eligibility=$record['hostel_eligibility'];
		$maritalstatus=$record['marital_status'];
		$gender=$record['gender'];
		$medication=$record['medi'];
		$H_status=$record['H_status'];
		$std_date=$record['dob'];
		$email=$record['email'];
		$address=$record['address'];
		$phone_no=$record['phone_no'];
		$sponsorship_name=$record['sponsorship_name'];
		$sponsorship_address=$record['sponsorship_address'];
		$sponsorship_number=$record['sponsor_number'];
		$state=$record['state_id'];
		$programme_id=$record['programme_id'];
		$programmeid=$record['programme_id'];
		
		
		if($userType==0){
			$search=$number;
		}else{
			$application_number=$record['application_number'];
			$search=$application_number;
		}
		
		//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM programmes WHERE id='$programme_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$course=$row['title'];
		$department_id=$row['department_id'];
		$programmetype=$row['type'];
		
		
		
		//get programme
		$query_programme=mysqli_query($con,"SELECT  *FROM students_departments WHERE id='$department_id'");
		$row=mysqli_fetch_assoc($query_programme);
		$department=$row['title'];
		
		
		
		//$faculty=$record['faculty'];
		//$hostel_faculty=$record['faculty'];
		
		$query=mysqli_query($con,"SELECT title FROM state WHERE id='$state'");
		$row=mysqli_fetch_assoc($query);
		$state=$row['title'];
		
		$lga=$record['lga_id'];
		$query=mysqli_query($con,"SELECT title FROM lga WHERE id='$lga'");
		$row=mysqli_fetch_assoc($query);
		
		$lga=$row['title'];
		$status=$record['marital_status'];
		$medication=$record['medi'];
		$blood_group=$record['blood_type'];
		$disability=$record['disability'];
		
		//$mat_no=$record['jamb_no'];
		//$student_type=$record['student_type'];
		
		$permenat_address=$record['permanent_address'];
		$level=$record['level'];
		//$lga_title=$record['lga_title'];
		//$religion=$record['religion'];
		
		
		$kin_address=$record['kin_address'];
		$kin_phone_number=$record['kin_phone_number'];
		$kin_relationship=$record['kin_relationship'];
		$kin_name=$record['kin_name'];
		
		
		$state_title="";
		$lga_title="";
		
		
		$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					$header_image=$row['header_image'];
					$crf_image=$row['crf_image'];
					$refree_image=$row['refree_image'];
					
					$header_image='images/'.$header_image;
					$crf_image='images/'.$crf_image;
					$refree_image='images/'.$refree_image;
					
					
				}
			}
		}
		
		
		}

		
		if($programmetype="DIP"){
			$ss="2019/2020";
		}else{
			$ss="2018/2019";
		}
		
	$pdf = new FPDF();
$pdf  -> AddPage();

$pdf  -> Image($crf_image,40,6);

$pdf  -> SetFont("Arial","UB",12);

$pdf  -> Cell(0,70,"{$ss} Session",0,1,'l');

$pdf  -> SetFont("Arial","UB",12);
$pdf  -> Cell(0,1,"",0,1,'C');
$pdf  -> Cell(0,5,"BIO-DATA",0,1,'l');

$pdf  -> SetFont("Arial","",10);
$pdf  -> Cell(70,8,"ADMISION NO: {$number}",1,0,'L');
$pdf  -> Cell(0,8,"NAME: {$full_name}",1,1,'L');


$pdf  -> Cell(0,5,"DEPARTMENT: {$department}",1,1,'L');
$pdf  -> Cell(0,5,"PROGRAMM: {$course}",1,1,'L');
$pdf  -> Cell(0,5,"LEVEL: {$level}",1,1,'L');

$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(70,15,"{$semester} Courses",0,1,'L');
$pdf  -> Cell(10,1,"_________________________________________________________________________________________________________________________",0,1,'L');




$pdf  -> SetFont("Arial","UB",30);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"SN",1,0,'L');
$pdf  -> Cell(50,5,"CODE",1,0,'L');
$pdf  -> Cell(100,5,"COURSE TITLE",1,0,'L');
$pdf  -> Cell(20,5,"UNIT",1,1,'L');

$pdf  -> SetFont("Arial","UB",25);
$pdf  -> Cell(0,1,"",0,1,'C');
$pdf  -> SetFont("Arial","",10);

$sn=1;
$course_unit_total=0;
include_once('../include/connections.php');
$sqlget=mysqli_query($con,"SELECT *FROM students_courses_".$current_session." WHERE student_id='$student_portal_login_id' AND status='1' AND md5(session)='$token' AND semester='2'");
if($sqlget){
	$sqlget_row=mysqli_num_rows($sqlget);
	if($sqlget_row > 0){
		while($row=mysqli_fetch_array($sqlget)){
			
			$course_id=$row['course_id'];
			
		$sql_get_course=mysqli_query($con,"SELECT *FROM courses WHERE id='$course_id'");
		if($sql_get_course){
			$sql_get_course_row=mysqli_num_rows($sql_get_course);
			if($sql_get_course_row > 0){
				$ro=mysqli_fetch_array($sql_get_course);
					$course_title=$ro['title'];
					$course_code=$ro['code'];
					$course_unit=$ro['unit'];
				
			}
		}
		

$pdf  -> Cell(20,8,"{$sn}",1,0,'L');
$pdf  -> Cell(50,8,"{$course_code}",1,0,'L');
$pdf  -> Cell(100,8,"{$course_title}",1,0,'L');
$pdf  -> Cell(20,8,"{$course_unit}",1,1,'L');



$sn=$sn + 1;
$course_unit_total=$course_unit_total+ $course_unit;
		}
		

$pdf  -> SetFont("Arial","UB",10);
$pdf  -> Cell(0,5,"",0,1,'C');
$pdf  -> SetFont("Arial","B",7);
$pdf  -> Cell(20,5,"",1,0,'L');
$pdf  -> Cell(50,5,"",1,0,'L');
$pdf  -> Cell(100,5,"Total Unit",1,0,'L');
$pdf  -> Cell(20,5,"{$course_unit_total}",1,1,'L');

	}
}





$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> SetFont("Arial","B",8);
$pdf  -> Cell(70,5,"__________________________________",0,0,'L');
$pdf  -> Cell(70,5,"__________________________________",0,0,'L');
$pdf  -> Cell(50,5,"________________________________",0,1,'L');

$pdf  -> Cell(70,5,"Signature of Student & Date",0,0,'L');
$pdf  -> Cell(70,5,"Signature of Academic Programme Officer. & Date",0,0,'L');
$pdf  -> Cell(50,5,"Signature of Director & Date",0,1,'L');






$pdf  -> SetFont("Arial","B",5);
$pdf  -> Cell(0,10,"",0,1,'C');
$pdf  -> Cell(0,10,"Source: IBRAHIM BADAMASI BABANGIDA UNIVERSITY, LAPAI",0,0,'l');

$pdf -> Output();




?>