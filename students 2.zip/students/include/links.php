<?php
	//get project id
	$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE system_code='$token' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				$row=mysqli_fetch_assoc($sql_get);
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
				
			}
		}

?>
<ul class="nav navbar-nav navbar-right">

            <!--<li>
				<a href="#" style="color:green;" class="btn btn-success btn-lg-xs" data-toggle="modal" data-target="#myModal" style="color:#fff">Apply Now</a>
			</li>-->
			  <li>
				<a href="index.php?token=812ed4562d3211363a7b813aa9cd2cf042b63bb2tt256e8190e474aatt256e8190e474aa" style="color:green;" class="btn btn-success btn-lg-xs" style="color:#fff">Login</a>
			</li>
			
		<li class="active">
				<a class="btn-group btn-group-xs" href="#">Back to School Website</a>
		</li>
		
</ul>