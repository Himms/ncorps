<?
	function get_project_info($project_token){
		$project=$project_token;
	
		return $project;
	}

?>