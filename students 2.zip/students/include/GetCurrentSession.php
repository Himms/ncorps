<?php

		$sql_getCurrentSession=mysqli_query($con,"SELECT *FROM sessions WHERE current_session='1'");
		if($sql_getCurrentSession){
			$sql_getCurrentSession_row=mysqli_num_rows($sql_getCurrentSession);
			if($sql_getCurrentSession_row > 0){
				$row=mysqli_fetch_assoc($sql_getCurrentSession);
					$session_title=$row['title'];
			}
		}
	
	

?>