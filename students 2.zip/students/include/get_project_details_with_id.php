<?php
	
		include_once("../include/connections.php");
		$sql_get=mysqli_query($con,"SELECT *FROM projects WHERE project_id='$project_id' AND status='1'");
		if($sql_get){
			$sql_get_row=mysqli_num_rows($sql_get);
			if($sql_get_row > 0){
				while($row=mysqli_fetch_assoc($sql_get)){
					$project_sm_logo=$row['project_sm_logo'];
					$system_code=$row['system_code'];
					$project_id=$row['project_id'];
					$projects_title=$row['projects_title'];
					$project_code=$row['project_code'];
					$website=$row['website'];
					$contact_person=$row['contact_person'];
					
					
					
				}
			}
		}
	


?>