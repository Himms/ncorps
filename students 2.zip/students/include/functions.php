<?php
include_once("connections.php");
	$sql_getCurrentSession=mysqli_query($con,"SELECT *FROM sessions WHERE current_session='1'") or die(mysqli_error($con));
		if($sql_getCurrentSession){
			$sql_getCurrentSession_row=mysqli_num_rows($sql_getCurrentSession);
			if($sql_getCurrentSession_row > 0){
				$row=mysqli_fetch_assoc($sql_getCurrentSession);
					$session_title=$row['title'];
			}
		}
	$current_session=str_replace("/","_",$session_title);
	 function get_time_ago($time)
        {
            $time_difference = time() - $time;
        
            if( $time_difference < 1 ) { return 'less than 1 second ago'; }
            $condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
                        30 * 24 * 60 * 60       =>  'month',
                        24 * 60 * 60            =>  'day',
                        60 * 60                 =>  'hour',
                        60                      =>  'minute',
                        1                       =>  'second'
            );
        
            foreach( $condition as $secs => $str )
            {
                $d = $time_difference / $secs;
        
                if( $d >= 1 )
                {
                    $t = round( $d );
                    return $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
                }
            }
        }
		


?>