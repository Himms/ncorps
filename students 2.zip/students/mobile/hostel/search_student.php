<?php
	header("Access-Control-Allow-Origin: *");
						
				include_once('connection.php');
				
	//get current session
	$sql_get_Session=mysqli_query($con,"SELECT *FROM sessions WHERE current_session='1'");
		if($sql_get_Session){
			$sql_get_SessionRow=mysqli_num_rows($sql_get_Session);
			if($sql_get_SessionRow > 0){
				$row=mysqli_fetch_assoc($sql_get_Session);
					$title	=$row['title'];
					
					$session_t=str_replace("/","_",$title);
			}
		}			
				
				
	$matric_no=$_POST['token'];
	
	$sql_get_alloc=mysqli_query($con,"SELECT *FROM students_".$session_t." std INNER JOIN hostel_allocation hall ON std.number=hall.std_id WHERE std.number='$matric_no'");
		if($sql_get_alloc){
			$sql_get_alloc_row=mysqli_num_rows($sql_get_alloc);
			if($sql_get_alloc_row > 0){
				$row=mysqli_fetch_assoc($sql_get_alloc);
					$student_id	=$row['id'];
					$matric_no=$row['number'];
					$surname=$row['surname'];
					$othername=$row['other_names'];
					$level=$row['level'];
					$phone_no=$row['phone_no'];
					
					$room_id=$row['room_id'];
					$hostel_categories=$row['hostel_categories'];
					$hostel_site=$row['hostel_site'];
					
					$chk_in_date_time=$row['chk_in_date_time'];
					
					//get site
					$get_Data=mysqli_query($con,"SELECT *FROM hostel_sites WHERE id='$hostel_site'");
							if($get_Data){
								$get_Data_row=mysqli_num_rows($get_Data);
								if($get_Data_row > 0){
									$row=mysqli_fetch_assoc($get_Data);
										$site_title=$row['title'];	
								}
							}	
							
							
							//get block
					$get_Data=mysqli_query($con,"SELECT *FROM hostel_categories WHERE id='$hostel_categories'");
							if($get_Data){
								$get_Data_row=mysqli_num_rows($get_Data);
								if($get_Data_row > 0){
									$row=mysqli_fetch_assoc($get_Data);
										$Block_title=$row['title'];	
								}
							}	
							
							//get room
					$get_Data=mysqli_query($con,"SELECT *FROM hostel_rooms WHERE id='$room_id'");
							if($get_Data){
								$get_Data_row=mysqli_num_rows($get_Data);
								if($get_Data_row > 0){
									$row=mysqli_fetch_assoc($get_Data);
										$Rooms_title=$row['title'];	
								}
							}	
					
					
					echo '
					<div class="col-md-12" style="width:100%;">
					<table class="table">
	<tr>
		<td valign="top"></td>
		<td valign="top">
			<table class="table">
				<tr>
					<td><b style="font-size:16px;color:green">Matric: '.$matric_no.'</b></td>
				</tr>
				<tr>
					<td><b style="font-size:16px;color:green">Fullname: '.$surname.' '.$othername.'</b></td>
				</tr>
				<tr>
					<td><b style="font-size:16px;color:green">Level: '.$level.'</b></td>
				</tr>
			</table>
		</td>
	</tr>
 </table>
 </div>';
 
					//chk if the student has made payment or not
					$paymentStatus=mysqli_query($con,"SELECT *FROM payments_".$session_t." WHERE payment_type='Accommodation Fee' AND number='$matric_no' AND status='1'");
							if($paymentStatus){
								$paymentStatusRow=mysqli_num_rows($paymentStatus);
								if($paymentStatusRow > 0){
									echo '
					<div class="col-md-12" style="width:100%;">
					<table class="table">
	<tr>
		<td valign="top"></td>
		<td valign="top">
			<table class="table">
				<tr>
					<td><b style="font-size:16px;color:green">Site: '.$site_title.'</b></td>
				</tr>
				<tr>
					<td><b style="font-size:16px;color:green">Block: '.$Block_title.'</b></td>
				</tr>
				<tr>
					<td><b style="font-size:16px;color:green">Room: '.$Rooms_title.'</b></td>
				</tr>
			</table>
		</td>
	</tr>
 </table><center>';
 
  //chk if checked in or not
 if($chk_in_date_time==""){
	  echo'<div class="col-md-12" style="width:100%;"><a href="#" onclick="chkInStudent('.$student_id.')" class="btn btn-info btn-sm">
                            Check in Student
                        </a></div>';
 }else{
	 echo '<p><b style="color:red;font-size:16px;">Checked in @ ' .$chk_in_date_time.'</b></p>';
 }
 
 
 echo'</center></div>';
 


								}else{
									echo '<div class="col-md-12" style="width:100%;"><center><p style="color:red;">Payment Not Confirm yet</p></center></div>';
								}
							}
 
 
					
					
			}else{
			echo '<div class="col-md-12" style="width:100%;"><center><p style="color:red;margin-top:20px;">Allocation Record Not Found</p></center></div>';
			}
		}
						
?> 
 