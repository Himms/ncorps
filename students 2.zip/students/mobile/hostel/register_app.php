<?php
	header("Access-Control-Allow-Origin: *");
	include_once('connection.php');
	$staff_no=$_POST['staff_no'];
	$email=$_POST['email'];
	$phone_no=$_POST['phone_no'];
	$pin=$_POST['pin'];
	$fullname=$_POST['fullname'];
		
		
	$pin=md5($pin);
		
	//chk if the staff number already exist
	$sql_get_users=mysqli_query($con,"SELECT *FROM staff WHERE number ='$staff_no'");
		if($sql_get_users){
			$sql_get_users_row=mysqli_num_rows($sql_get_users);
			if($sql_get_users_row == 0){
			$sql_add_user=mysqli_query($con,"INSERT INTO staff(number,username,first_name,phone_number,password) VALUES('$staff_no','$staff_no','$fullname','$phone_no','$pin')");
	if($sql_add_user){
		echo "1";
	}else{
		echo "Sorry, Something went wrong adding user, Please Try Againo";
	}
			}else{
				echo "This user already Exist";
			}
		}
?>