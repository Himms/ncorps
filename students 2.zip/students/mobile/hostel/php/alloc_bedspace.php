<?php
	header("Access-Control-Allow-Origin: *");
	include_once('../connection.php');
	$student_id=$_GET['student_id'];
	$room_id=$_GET['room_id'];


		//chk if the student has been allocated
		$sql_chk=mysqli_query($con,"SELECT *FROM hostel_bedspace WHERE student_id='$student_id' AND status='1'");
		if($sql_chk){
			$sql_chk_row=mysqli_num_rows($sql_chk);
			if($sql_chk_row > 0){
				echo "Student has been allocated a bedspace";
			}else{
				//chk bedspace
				$chk_bedspace=mysqli_query($con,"SELECT *FROM hostel_room WHERE status='1' AND room_id='$room_id'");
							if($chk_bedspace){
								$chk_bedspace_row=mysqli_num_rows($chk_bedspace);
								if($chk_bedspace_row > 0){
									while($row=mysqli_fetch_assoc($chk_bedspace)){
										$room_id=$row['room_id'];
										$bedspace=$row['bedspace'];
									}
								}
							}
							
	//get number of student in this room already
	$sql_get_bedspaces=mysqli_query($con,"SELECT *FROM hostel_bedspace WHERE status='1' AND room_id='$room_id'") or die(mysqli_error($con));
		if($sql_get_bedspaces){
			$sql_get_bedspaces_row=mysqli_num_rows($sql_get_bedspaces);
			}
			
				
			if($sql_get_bedspaces_row < $bedspace){
					$sql_eligibility=mysqli_query($con,"INSERT INTO hostel_bedspace(student_id,room_id) values('$student_id','$room_id')");
	if($sql_eligibility){
		echo "Bedspace Allocated Successfully";
	}else{
		echo "Something went wrong, Please try again";
	}
			}else{
			
				echo 'Sorry, This room is filled up';
			}



				
			
		}
		
		

	
}
?> 
 