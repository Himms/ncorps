<?php
	header("Access-Control-Allow-Origin: *");
	include_once('../connection.php');
	$token=$_GET['token'];
	$sql_payment=mysqli_query($con,"UPDATE students_data SET confirm_payment_status='1' WHERE student_id='$token'");
	if($sql_payment){
		echo "Payment confirmed successfully";
	}else{
		echo "Something went wrong, Please try again";
	}
?> 
 