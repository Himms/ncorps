<?php
	header("Access-Control-Allow-Origin: *");
	include_once('../connection.php');
	$username=$_GET['username'];
	$fullname=$_GET['fullname'];
	$phone_number=$_GET['phone_number'];
	$user_type=$_GET['user_type'];
	$password=md5($phone_number);
	
	if($user_type=="Sub admin"){
		$user_type='1';
	}elseif($user_type=="Portal"){
		$user_type='2';
	}elseif($user_type=="Bursary"){
		$user_type='3';
	}
	
	$sql_get_users=mysqli_query($con,"SELECT *FROM user_login WHERE status='1' AND username ='$username'");
		if($sql_get_users){
			$sql_get_users_row=mysqli_num_rows($sql_get_users);
			if($sql_get_users_row == 0){
			$sql_add_user=mysqli_query($con,"INSERT INTO user_login(username,fullname,phone_number,user_type,password) VALUES('$username','$fullname','$phone_number','$user_type','$password')");
	if($sql_add_user){
		echo "User Added Successfully";
	}else{
		echo "Sorry, Something went wrong adding user, Please Try Againo";
	}
			}else{
				echo "This user already Exist";
			}
		}
?> 
 