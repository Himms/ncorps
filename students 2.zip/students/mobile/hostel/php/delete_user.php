<?php
	header("Access-Control-Allow-Origin: *");
	include_once('../connection.php');
	$token=$_GET['token'];
	$sql_delete=mysqli_query($con,"UPDATE user_login SET status='0' WHERE user_login_id='$token'");
	if($sql_delete){
		echo "User deleted Successfully";
	}else{
		echo "Something went wrong, Please try again";
	}
?> 
 