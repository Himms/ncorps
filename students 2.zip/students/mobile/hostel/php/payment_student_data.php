<?php
	header("Access-Control-Allow-Origin: *");
						
				include_once('../connection.php');
	$matric_no=$_GET['matric_no'];
	$sql_get_payment=mysqli_query($con,"SELECT *FROM students_data WHERE matric_no='$matric_no'");
		if($sql_get_payment){
			$sql_get_payment_row=mysqli_num_rows($sql_get_payment);
			if($sql_get_payment_row > 0){
				$row=mysqli_fetch_assoc($sql_get_payment);
					$student_id	=$row['student_id'];
					$matric_no=$row['matric_no'];
					$surname=$row['surname'];
					$othername=$row['othername'];
					$level=$row['level'];
					$phone_no=$row['phone_no'];
					$image=$row['image'];
					
					
					echo '
					<table class="table">
	<tr>
		<td valign="top"></td>
		<td valign="top">
			<table class="table">
				<tr>
					<td>Matric: '.$matric_no.'</td>
				</tr>
				<tr>
					<td>Fullname: '.$surname.' '.$othername.'</td>
				</tr>
				<tr>
					<td>Phone: '.$phone_no.'</td>
				</tr>
				<tr>
					<td>Level: '.$level.'</td>
				</tr>
			</table>
		</td>
	</tr>
 </table>
 
						<a href="#" onclick="confirm_payment('.$student_id.')" class="btn btn-info btn-sm">
                            Confirm Payment
                        </a>
					';
					
			}else{
			echo '<p>Student do not exist</p>';
			}
		}
						
?> 
 