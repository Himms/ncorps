 <?php
	session_start();
	header("Access-Control-Allow-Origin: *");
	include_once('connection.php');
	
	
	//get the values from the javascript
		$username=$_POST['staff_number'];
		$password=$_POST['sign_in_pin'];
		
		$password=md5($password);
	//chk if the username and the password is currect
	$sql_chk=mysqli_query($con,"SELECT * FROM staff WHERE number='$username' AND password='$password'");
	//chk if the query exe or not
	if($sql_chk){
		//count how many rows the query returned
		$sql_chk_row=mysqli_num_rows($sql_chk);
		
		//chk if the row returned is more then 0 that is the user login detail exist in the database, in 
		//another word the record is found 
		if($sql_chk_row > 0){
			//return 1 to the javascript
			echo '1';
		}else{
			//return 0 to the javascript
			echo '0';
		}
	}


?> 