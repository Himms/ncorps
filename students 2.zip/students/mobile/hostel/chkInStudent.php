<?php
	header("Access-Control-Allow-Origin: *");
						
				include_once('connection.php');
			
$allocation_id=$_POST['allocation_id'];	
$Date=date('Y/m/d h:m:s');		
	//get current session
	$sql_chk=mysqli_query($con,"UPDATE hostel_allocation SET  chk_in_date_time='$Date' WHERE allocation_id='$allocation_id'");
		if($sql_chk){
			echo "Student Checkin Successfully";
		}			
				
				
	
	
	
	?>