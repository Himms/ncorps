<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Eligibility</div>
                <div class="panel-body" id="load_existing_users">
                    <div class="col-sm-11">

                    </div>
                    <div class="col-sm-1">
                        <a href="#" data-toggle="modal" data-target=".bs-add-eligible" class="btn btn-info btn-sm">
                            <image src="images/add.png" width="20px" height="20px" />
                        </a>
                    </div>

					<div class="col-sm-12">
						<table class="table">
                        <thead>
                            <tr>
                                <th>S/N</th>
								<th>Matric No</th>
                                <th>Fullname</th>
                                <th>Phone No.</th>
								<th>Level</th>
                                <th>Eligibility Status</th>
								
                                <th></th>
        
                                
                            </tr>
                        </thead>
						<?php
				include_once('../connection.php');
				$sn=1;
	$sql_get_eligibility=mysqli_query($con,"SELECT *FROM students_data");
		if($sql_get_eligibility){
			$sql_get_eligibility_row=mysqli_num_rows($sql_get_eligibility);
			if($sql_get_eligibility_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_eligibility)){
					$student_id	=$row['student_id'];
					$matric_no=$row['matric_no'];
					$surname=$row['surname'];
					$othername=$row['othername'];
					$level=$row['level'];
					$phone_no=$row['phone_no'];
					$image=$row['image'];
					$h_eligible=$row['h_eligible'];
					$fullname=$surname.' '.$othername;
					
					if($h_eligible=="1"){
						$eligibility_status='Eligible';
					}elseif($h_eligible=="0"){
						$eligibility_status='<p style="color:red">Not Eligible</p>';
					}
					
					echo '<tr>
                            <td>'.$sn.'</td>
							<td>'.$matric_no.'</td>
                            <td>'.$fullname.'</td>
                            <td>'.$phone_no.'</td>
                            <td>'.$level.'</td>
							<td>'.$eligibility_status.'</td>
							
                            <td><a href="#" onclick="eligible_user('.$student_id.')">Make Eligible</a></td>
                        </tr>';
						$sn=$sn + 1;
				}
					
				}
				
			}
		
						
						?>
                        
                        
                    </table>
					</div>
                </div>
            </div>