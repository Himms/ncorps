<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
        <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Reports</div>
            <div class="panel-body">
				<div class="col-sm-2">
                   
				</div>
				<div class="col-sm-6">
					<select class="form-control" id="reports" style="font-size:20px; font-family: 'Times New Roman', Times, serif">
						<option></option>
						<option>Hostel Allocation Report</option>
						<option>Hostel Payment Report</option>
					</select>                  
				</div>
				<div class="col-sm-4">
                    <button onclick="get_report()" type="button"  class="btn btn-info">Search</button>
				</div>
				
				
				<form class="form-horizontal" id="form_report">
				<div class="col-sm-12" id="load_report"></div>
				</form>
			</div>
						
		</div>
 </div>