<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Rooms</div>
                <div class="panel-body">
                    <div class="col-sm-11">

                    </div>
                    <div class="col-sm-1">
                        <a href="#" data-toggle="modal" data-target=".bs-new-user" class="btn btn-default btn-sm">
                            <image src="images/add.png" width="20px" height="20px" />
                        </a>
                    </div>

					<div class="col-sm-12">
			<div class="panel">
               
                <div class="panel-body">
                   <?php
							include_once('../connection.php');

							// Get block
							$token=$_GET['token'];
							$sql_get=mysqli_query($con,"SELECT *FROM hostel_room WHERE status='1' AND block_id='$token'");
							if($sql_get){
								$sql_get_row=mysqli_num_rows($sql_get);
								if($sql_get_row > 0){
									while($row=mysqli_fetch_assoc($sql_get)){
										$room_id=$row['room_id'];
										$room_title=$row['room_title'];
										
							
				//get total bedspaces
				$total_bedspace=0;
					$get_total_bedspace=mysqli_query($con,"SELECT *FROM hostel_room WHERE status='1' AND room_id='$room_id'");
							if($get_total_bedspace){
								$get_total_bedspace_row=mysqli_num_rows($get_total_bedspace);
								if($get_total_bedspace_row){
									while($row=mysqli_fetch_assoc($get_total_bedspace)){
										$bedspace=$row['bedspace'];
										$total_bedspace=$total_bedspace + $bedspace;
									}
								}
							}							
										
						echo'<a href="#" onclick="load_bedspace('.$room_id.')">
							<div class="panel col-sm-6">
								<div class="panel-heading">'.$room_title.'</div>
                        <div class="panel-body">
							<div class="list-group">
								<a href="#" class="list-group-item">
									<span class="badge">'.$total_bedspace.'</span>
								Total Bedspace
								</a>
								<a href="#" class="list-group-item">
									<span class="badge"></span>
								Remaining Bedspace
								</a>
							</div>
                        </div>
						 </div>
						</a>';
									}
								}
							}
						?>
                   
               
            </div>
						
					</div>
                </div>
            </div>