<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Hostel Allocation Report</div>
                <div class="panel-body" id="load_existing_users">

					<div class="col-sm-12">
						<table class="table">
                        <thead>
                            <tr>
                                <th>S/N</th>
								<th>Matric No</th>
                                <th>Fullname</th>
                                <th>Phone No</th>
                                <th>Level</th>
                            </tr>
                        </thead>
						<?php
				include_once('../connection.php');
				$sn=1;
	$sql_get_payment=mysqli_query($con,"SELECT *FROM students_data");
		if($sql_get_payment){
			$sql_get_payment_row=mysqli_num_rows($sql_get_payment);
			if($sql_get_payment_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_payment)){
					$student_id	=$row['student_id'];
					$matric_no=$row['matric_no'];
					$surname=$row['surname'];
					$othername=$row['othername'];
					$fullname=$surname.' '.$othername;
					$phone_no=$row['phone_no'];
					$level=$row['level'];
										
					echo '<tr>
                            <td>'.$sn.'</td>
							<td>'.$matric_no.'</td>
                            <td>'.$fullname.'</td>
							<td>'.$phone_no.'</td>
							<td>'.$level.'</td>
                                                      
                        </tr>';
						$sn=$sn + 1;
				}
				
			}
		}
						
						?>
                        
                        
                    </table>
					</div>
                </div>
            </div>