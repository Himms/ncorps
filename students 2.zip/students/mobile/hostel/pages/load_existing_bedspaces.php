<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Bedspaces</div>
                <div class="panel-body" id="load_existing_users">
                    <div class="col-sm-10">

                    </div>
                    <div class="col-sm-2">
                        <a href="#" data-toggle="modal" data-target=".bs-allocate-room" class="btn btn-info btn-sm">
                            Allocate Room
                        </a>
                    </div>

					<div class="col-sm-12">
						<table class="table">
                        <thead>
                            <tr>
                                <th>S/N</th>
								<th>Matric No</th>
                                <th>Fullname</th>
                                <th>Phone No.</th>
                                <th>Level</th>
                               
                                <th></th>
        
                                
                            </tr>
                        </thead>
						<?php
				include_once('../connection.php');
				$sn=1;
				$token=$_GET['token'];
	$sql_get_bedspaces=mysqli_query($con,"SELECT *FROM students_data sd INNER JOIN hostel_bedspace hb on sd.student_id=hb.student_id WHERE hb.status='1' AND hb.room_id='$token'") or die(mysqli_error($con));
		if($sql_get_bedspaces){
			$sql_get_bedspaces_row=mysqli_num_rows($sql_get_bedspaces);
			if($sql_get_bedspaces_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_bedspaces)){
				
					$student_id=$row['student_id'];
					$bedspace_id=$row['bedspace_id'];
					$matric_no=$row['matric_no'];
					$fullname=$row['surname'].' '.$row['othername'];
					$phone_no=$row['phone_no'];
					$level=$row['level'];
					
					echo '<tr>
                            <td>'.$sn.'</td>
							
                            <td>'.$matric_no.'</td>
                            <td>'.$fullname.'</td>
                            <td>'.$phone_no.'</td>
							<td>'.$level.'</td>
                           
                            <td><a href="#" onclick="remove_bedspace('.$student_id.')">Remove</a></td>
                           
                        </tr>';
						$sn=$sn + 1;
				}
				
			}
		}
						
						?>
                        
                        
                    </table>
					</div>
                </div>
            </div>