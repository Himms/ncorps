<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Payments</div>
                <div class="panel-body" id="load_existing_users">
                    <div class="col-sm-11">

                    </div>
                    <div class="col-sm-1">
                        <a href="#" data-toggle="modal" data-target=".bs-confirm-payment" class="btn btn-info btn-sm">
                            <image src="images/add.png" width="20px" height="20px" />
                        </a>
                    </div>

					<div class="col-sm-12">
						<table class="table">
                        <thead>
                            <tr>
                                <th>S/N</th>
								<th>Matric No</th>
                                <th>Fullname</th>
                                <th>Payment Status</th>
                                <th>Payment Date</th>
								<th>Confirm Payment Status</th>
        
                                
                            </tr>
                        </thead>
						<?php
				include_once('../connection.php');
				$sn=1;
	$sql_get_payment=mysqli_query($con,"SELECT *FROM students_data");
		if($sql_get_payment){
			$sql_get_payment_row=mysqli_num_rows($sql_get_payment);
			if($sql_get_payment_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_payment)){
					$student_id	=$row['student_id'];
					$matric_no=$row['matric_no'];
					$fullname=$surname.' '.$othername;
					$surname=$row['surname'];
					$othername=$row['othername'];
					$payment_status=$row['payment_status'];
					$payment_date=$row['payment_date'];
					$confirm_payment_status=$row['confirm_payment_status'];
					
					if($payment_status=="1"){
						$payment_status='Paid';
					}elseif($payment_status=="0"){
						$payment_status='Not Paid';
					}
					if($confirm_payment_status=="1"){
						$confirm_payment_status='Confirmed';
					}elseif($confirm_payment_status=="0"){
						$confirm_payment_status='<p style="color:red">Not Confirmed</p>';
					}
					
					echo '<tr>
                            <td>'.$sn.'</td>
							<td>'.$matric_no.'</td>
                            <td>'.$fullname.'</td>
							<td>'.$payment_status.'</td>
							<td>'.$payment_date.'</td>
							<td>'.$confirm_payment_status.'</td>
                                                      
                        </tr>';
						$sn=$sn + 1;
				}				
			}
		}
						
						?>
                        
                        
                    </table>
					</div>
                </div>
            </div>