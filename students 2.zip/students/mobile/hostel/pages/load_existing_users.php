<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Users</div>
                <div class="panel-body" id="load_existing_users">
                    <div class="col-sm-11">

                    </div>
                    <div class="col-sm-1">
                        <a href="#" data-toggle="modal" data-target=".bs-new-user" class="btn btn-info btn-sm">
                            <image src="images/add-user.png" width="20px" height="20px" />
                        </a>
                    </div>

					<div class="col-sm-12">
						<table class="table">
                        <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Fullname</th>
                                <th>Username</th>
                                <th>Phone No.</th>
                                <th>User Type</th>
                               
                                <th></th>
        
                                
                            </tr>
                        </thead>
						<?php
				include_once('../connection.php');
				$sn=1;
	$sql_get_users=mysqli_query($con,"SELECT *FROM user_login WHERE status='1' AND user_type !='0' ORDER BY user_login_id");
		if($sql_get_users){
			$sql_get_users_row=mysqli_num_rows($sql_get_users);
			if($sql_get_users_row > 0){
				while($row=mysqli_fetch_assoc($sql_get_users)){
				
					$user_login_id=$row['user_login_id'];
					$fullname=$row['fullname'];
					$phone_number=$row['phone_number'];
					$username=$row['username'];
					$user_type=$row['user_type'];
					
					if($user_type=="1"){
		$user_type='Sub Admin';
	}elseif($user_type=="2"){
		$user_type='Portal';
	}elseif($user_type=="3"){
		$user_type='Bursary';
	}
					
					echo '<tr>
                            <td>'.$sn.'</td>
                            <td>'.$fullname.'</td>
                            <td>'.$username.'</td>
                            <td>'.$phone_number.'</td>
							<td>'.$user_type.'</td>
                           
                            <td><a href="#" onclick="delete_user('.$user_login_id.')">Delete</a></td>
                           
                        </tr>';
						$sn=$sn + 1;
				}
				
			}
		}
						
						?>
                        
                        
                    </table>
					</div>
                </div>
            </div>