<?php
	header("Access-Control-Allow-Origin: *");


?> 
 <div class="panel">
                <div class="panel-heading" style="font-size:20px; font-family: 'Times New Roman', Times, serif">Manage Hostels</div>
                <div class="panel-body">
                    <div class="col-sm-11">

                    </div>
                    <div class="col-sm-1">
                        <a href="#" data-toggle="modal" data-target=".bs-new-user" class="btn btn-info btn-sm">
                            <image src="images/add.png" width="20px" height="20px" />
                        </a>
                    </div>

					<div class="col-sm-12">
			<div class="panel">
               
                <div class="panel-body">
                   <?php
							include_once('../connection.php');
							// Get site
							$sql_get=mysqli_query($con,"SELECT *FROM hostel_site WHERE status='1'");
							if($sql_get){
								$sql_get_row=mysqli_num_rows($sql_get);
								if($sql_get_row > 0){
									while($row=mysqli_fetch_assoc($sql_get)){
										$site_id=$row['site_id'];
										$site_title=$row['title'];
										
										
				//get total blocks
					$get_total_block=mysqli_query($con,"SELECT *FROM hostel_block WHERE status='1' AND site_id='$site_id'");
							if($get_total_block){
								$get_total_block_row=mysqli_num_rows($get_total_block);
							}

				//get total rooms
					$get_total_room=mysqli_query($con,"SELECT *FROM hostel_room WHERE status='1' AND site_id='$site_id'");
							if($get_total_room){
								$get_total_room_row=mysqli_num_rows($get_total_room);
							}
							
				//get total bedspaces
				$total_bedspace=0;
					$get_total_bedspace=mysqli_query($con,"SELECT *FROM hostel_room WHERE status='1' AND site_id='$site_id'");
							if($get_total_bedspace){
								$get_total_bedspace_row=mysqli_num_rows($get_total_bedspace);
								if($get_total_bedspace_row){
									while($row=mysqli_fetch_assoc($get_total_bedspace)){
										$bedspace=$row['bedspace'];
										$total_bedspace=$total_bedspace + $bedspace;
									}
								}
							}							
										
						echo'<a href="#" onclick="load_block('.$site_id.')">
							<div class="panel col-sm-6">
								<div class="panel-heading">'.$site_title.'</div>
								<div class="panel-body">
									<div class="list-group">
		  
										<a href="#" class="list-group-item">
											<span class="badge">'.$get_total_block_row.'</span>
										Total Blocks
										</a>
										<a href="#" class="list-group-item">
											<span class="badge">'.$get_total_room_row.'</span>
										Total Rooms
										</a>
										<a href="#" class="list-group-item">
											<span class="badge">'.$total_bedspace.'</span>
										Total Bedspace
										</a>
										<a href="#" class="list-group-item">
											<span class="badge"></span>
										Remaining Bedspace
										</a>
									</div>
								</div>
							</div>
							</a>';
									}
								}
							}
						?>
                   
               
            </div>
						
					</div>
                </div>
            </div>