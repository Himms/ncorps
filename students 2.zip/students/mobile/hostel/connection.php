 <?php

	$servername = "localhost";
	$username = "xbbue9x";
	$password = "+=!~GugoolPhazEbOoK--</>e7&signCOtaNgEnT6^&(";
	
    $db = "xbbue9x_smartschool";

 //create login connection and login
$con = new mysqli($servername,$username,$password,$db);

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

  
  ?> 