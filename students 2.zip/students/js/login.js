function student_portal_login(){
    alert();
	document.getElementById("error").innerHTML='<br/><center><p style="color:blue"><img src="../images/icons/info_loader.gif"></center><p>';
    var username=$('#username').val();
    var password=$('#password').val();
    if(username=='' || password=='')
    {
        $('#error').html("field(s) cannot be empty");
    }
    else
    {
         $.post('php/student_portal_login.php',{username:username,password:password},
         function(response,status)
         {
			 alert(response);
              if(response==1){
				  
                 window.location.href="flailas/desktop.php";
             }
             else if(response==0){
			 document.getElementById("error").innerHTML='<div class="alert alert-info" role="alert" style="margin-top:10px;"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only"></span>Wrong login details<br/></div>';
             }
         })
    }
   
}