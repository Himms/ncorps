function create_Account(project_id){
	document.getElementById("error").innerHTML='<center><p style="color:blue"><img src="../images/info_loader.gif"></center><p>';
	var surname=document.getElementById("surname").value;
	var firstname=document.getElementById("firstname").value;
	var othernames=document.getElementById("othernames").value;
	var gender=document.getElementById("gender").value;
	var phonenumber=document.getElementById("phonenumber").value;
	
	var email=document.getElementById("email").value;
	var password=document.getElementById("password").value;
	var password1=document.getElementById("password1").value;
	
	if(surname =="" && firstname=="" && othernames=="" && gender=="" && phonenumber=="" && email=="" && password=="" && password1==""){
		document.getElementById("error").innerHTML='Provide all the requred Informations';
	}else{
		if(password != password1){
			document.getElementById("error").innerHTML='Password not thesame'; 
		}else{
			//
	surname=$.trim(surname);
	firstname=$.trim(firstname);
	othernames=$.trim(othernames);
	gender=$.trim(gender);
	phonenumber=$.trim(phonenumber);
	email=$.trim(email);
	password=$.trim(password);
	password1=$.trim(password1);
	
	$.post("../../php/create_Account.php",{password1:password1,password:password,email:email,project_id :project_id,surname:surname,firstname:firstname,othernames:othernames,gender:gender,phonenumber:phonenumber},
	function(response,status){ // Required Callback Function
		document.getElementById("error").innerHTML =response;
	});	
	
		}
	}

}
function student_portal_loginn(){


	document.getElementById("error").innerHTML='<center><p style="color:blue"><img src="images/info_loader.gif"></center><p>';
	var username=document.getElementById("username").value;
	var password=document.getElementById("password").value;

	var dataString = 'username=' + username + '&password=' + password;
if($.trim(username).length>0 && $.trim(password).length>0)
{
	$.ajax({
type: "POST",
url: "../php/student_portal_login.php",
data: dataString,
cache: false,
success: function(data){
	//alert(data);
	if(data=="1"){
	$("body").load("desktop.php").hide().fadeIn(1500).delay(6000);
//or

window.location.href = "desktop.php";	

	}else{
		document.getElementById("error").innerHTML='<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span>Invalid username or password</div>';		
		
		
	}
	
}
});
}else{
	document.getElementById("error").innerHTML='<p style="color:red;">Error: Enter Username and Password</p>';
	
}


}



function applicant_portal_login(){
	document.getElementById("error").innerHTML='<center><p style="color:blue"><img src="images/info_loader.gif"></center><p>';
	var username=document.getElementById("username").value;
	var password=document.getElementById("password").value;
	
	
	var dataString = 'username=' + username + '&password=' + password;
if($.trim(username).length>0 && $.trim(password).length>0)
{
	$.ajax({
type: "POST",
url: "../php/applicant_portal_login.php",
data: dataString,
cache: false,
success: function(data){
    alert(data);
	if(data=="1"){
	$("body").load("dashboard.php").hide().fadeIn(1500).delay(6000);
//or

window.location.href = "dashboard.php";	

	}else{
		document.getElementById("error").innerHTML='<div class="alert alert-danger" role="alert"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span><span class="sr-only">Error:</span>Invalid username or password</div>';		
		
		
	}
	
}
});
}else{
	document.getElementById("error").innerHTML='<p style="color:red;">Error: Enter Username and Password</p>';
	
}

}

function nextcreateAccount(){
    	var matricNumber=$('#matricNumber').val();
    	var emailAddress=$('#emailAddress').val();
    	var password1=$('#password1').val();
    	var password2=$('#password2').val();
    	
    
    	
    	if(matricNumber ==""){
    	    alert("Enter Matric Number");
    	}else if(emailAddress==""){
    	    alert("Enter Email Address");
    	}else if(password1==""){
    	    alert("Enter Password");
    	}else if(password2==""){
    	    alert("Re-enter Password");
    	}else if(password1 == password2){
    	    document.getElementById("Createerror").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/createAccommodationAccont.php",{number:matricNumber,email:emailAddress,password1:password1},
	function(response,status){ // Required Callback Function
	    document.getElementById("errorCreateAccount").innerHTML =response;
	    document.getElementById("Createerror").innerHTML='';
		
	});
    	   
    	}else{
    	 alert("Password Mis-match");
    
    	}
}

function ActivateAccount(){
    
    	var phoneNumber=$('#phoneNumber').val();
    	var mat=$('#mat').val();
    	var email=$('#email').val();
    	var password1=$('#password1').val();
    	
    	if(phoneNumber==""){
    	    alert("Enter Phone Number");
    	}else if(mat=="" || email=="" || password1==""){
    	    alert("Missing Information");
    	}
    	else{
    	    //proceed
    	     document.getElementById("proceed").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/activateAccommodationAccount.php",{phoneNumber:phoneNumber,mat:mat,email:email,password1:password1},
	function(response,status){ // Required Callback Function
	    document.getElementById("proceed").innerHTML=response;
		
	});
    	}
}

