function student_portal_reset_password(){
document.getElementById("error").innerHTML='<br/><center><p style="color:blue"><img src="../images/icons/info_loader.gif"></center><p>';
    var phone_number=$('#phone_number').val();
    var matric_number=$('#matric_number').val();
    if(phone_number=='' || matric_number=='')
    {
        $('#error').html("field(s) cannot be empty");
    }
    else
    {
         $.post('../php/account_reset.php',{phone_number:phone_number,matric_number:matric_number},
         function(response,status)
         {
            $('#error').html(response);
			
         })
    }



}