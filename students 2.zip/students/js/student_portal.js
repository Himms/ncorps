function add_olevelresult(token){
		
}

function result_uploaded_table(){
			$.post('../php/result_uploaded_table_refresh.php',
				function(response,error){
				
					$("#result_uploaded_table_wrap").html(response);
					
			});
	}
	
	
function upload_docFile(){	
			var file = document.getElementById("doc").files[0];
			var formdata = new FormData();
			formdata.append("doc", file);
			var ajax = new XMLHttpRequest();
			ajax.open("POST", "../php/upload_documents.php");
			ajax.addEventListener("load", completeHandler, false);
			 ajax.addEventListener("error" , errorHandler, false);
			ajax.send(formdata);
		
}
	
function errorHandler(evt)
{
	alert(evt.target.responseText);
}
	
	function completeHandler(event){
		
					if(event.target.responseText == 1){
						var document_title = $("#document_title").val();
							if(document_title != ''){
									$.post('../php/upload_documents_title.php',{document_title:document_title},
								function(response){
									$("#document_title").val('');
									$("#doc").val('');
										document_uploaded_table(2);
								});
							}else{
									alert('please provide the document title');
									document_uploaded_table(2);
							}
					}else{
						alert(event.target.responseText);
					}
				
	}

	function document_uploaded_table(token){
			$.post('../php/document_uploaded_table.php',{token:token},
				function(response,error){
					$("#document_uploaded_table").html(response);
					
			});
	}