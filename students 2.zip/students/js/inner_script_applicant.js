$(document).ready(function(){
	biodata();
});

function preview_biodata_applicant(){
	document.getElementById("p").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/preview_biodata_applicant.php",
	function(response,status){ // Required Callback Function
		document.getElementById("p").innerHTML =response;
	});
	
	
	
}

function logout(token){
	document.getElementById("error").innerHTML='<center><p style="color:red">Signing you out<br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/logout.php",{token:token},
function(response,status){ // Required Callback Function
if(response==1){
	$("body").load("index.php").hide().fadeIn(1500).delay(6000);
	window.location.href = "index.php";
}else{
	document.getElementById("error").innerHTML="";
}
});
}

function biodata(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/profile_application.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function course_registration(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/course_registration_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function my_result(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/my_result_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function other_uploads(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/other_uploads.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function library_form(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/library_form_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function accommodation(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/accommodation_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function update_applicant_profile(){
		var email=$('#email').val();
		var phone_no=$('#phone_no').val();
		var maritalstatus=$('#maritalstatus').val();
		var gender=$('#gender').val();
		var dob=$('#dob').val();
		var address=$('#address').val();
		var name_of_guardian=$('#name_of_guardian').val();
		var address_gaurdian=$('#address_gaurdian').val();
		var medication=$('#medication').val();
		var H_status=$('#H_status').val();
		var disability=$('#disability').val();
		var blood_type=$('#blood_type').val();
		var no_guardian=$('#no_guardian').val();
		var level=$('#level').val();
		var program=$('#program').val();
		var permenat_address=$('#permenat_address').val();
		var kin_name=$('#kin_name').val();
		var kin_relationship=$('#kin_relationship').val();
		var kin_phone_number=$('#kin_phone_number').val();
		var kin_address=$('#kin_address').val();
		var state=$('#state').val();
		var lga=$('#lga').val();
		
	document.getElementById("profile_error").innerHTML='<center>Saving Profile, Please wait<br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/update_applicant_profile.php",{state:state,lga:lga,kin_name:kin_name,kin_relationship:kin_relationship,kin_phone_number:kin_phone_number,kin_address:kin_address,permenat_address:permenat_address,program:program,level:level,no_guardian:no_guardian,blood_type:blood_type,disability:disability,H_status:H_status,medication:medication,email:email,phone_no:phone_no,maritalstatus:maritalstatus,gender:gender,dob:dob,address:address,name_of_guardian:name_of_guardian,address_gaurdian:address_gaurdian},
	function(response,status){ // Required Callback Function
		document.getElementById("profile_error").innerHTML =response;
	});
}

//load lga
function load_lga(){

	var state = $('#state').val();
		
$.post("../php/load_lga.php",{state:state},
function(response,status){ // Required Callback Function
document.getElementById("lga").innerHTML = response;
});
		
	
	
}

function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }