$(document).ready(function(){
	biodata();
	//get_side_menu();
	//load_election();
	
});
function load_election(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/load_election.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function get_candidates(office_id){
	document.getElementById("load_candidate").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/get_candidates.php",{office_id:office_id},
	function(response,status){ // Required Callback Function
		document.getElementById("load_candidate").innerHTML =response;
	});
}

function vote(candidate_id,office_id){
	document.getElementById("load_candidate").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/vote.php",{office_id:office_id,candidate_id:candidate_id},
	function(response,status){ // Required Callback Function
		document.getElementById("load_candidate").innerHTML =response;
	});
}

function load_my_bedspace(){
	$('#myModal').modal('hide')
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/load_my_bedspace.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function select_room(std_id,room_id){
document.getElementById("content").innerHTML ='<table class="table" style="align:center;"><tr><td><center><h4><p style="color:red;">Please Wait...</p></h4></center></td></tr></table>';
	$.post("../php/select_room.php",{id:std_id,room_id:room_id},
function(response,status){ // Required Callback Function
alert(response);
accommodation();
});
}

function preview_biodata(){
	document.getElementById("p").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/preview_biodata.php",
	function(response,status){ // Required Callback Function
		document.getElementById("p").innerHTML =response;
	});	
}

function fee_payments(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/FeePayment.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});	
}
function submit_payment_detail(){
	var payment_type=$('#payment_type').val();
	var session=$('#session').val();
	var bank=$('#bank').val();
	var branch=$('#branch').val();
	var payment_date=$('#payment_date').val();
	var teller=$('#teller').val();
	var depositor=$('#depositor').val();
	$.post("../php/submit_payment_detail.php",{payment_type:payment_type,session:session,teller:teller,bank:bank,branch:branch,payment_date:payment_date,depositor:depositor},
	function(response,status){ // Required Callback Function
		alert(response);
	});	
	fee_payments();
}


function logout(token){
	document.getElementById("error").innerHTML='<center><p style="color:red">Signing you out<br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/logout.php",{token:token},
function(response,status){ // Required Callback Function
if(response==1){
	$("body").load("index.php").hide().fadeIn(1500).delay(6000);
	window.location.href = "index.php";
}else{
	document.getElementById("error").innerHTML="";
}
});
}
function uniapplication_form(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/uni_application_form.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function get_course_of_study_details(){
	document.getElementById("courseofstudiesdetails").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	var program=$('#program').val();
	$.post("../php/get_course_of_study_details.php",{program:program},
	function(response,status){ // Required Callback Function
		document.getElementById("department").value=response;
		document.getElementById("courseofstudiesdetails").innerHTML='';
	});
	
}

function save_application_form(){
	var program=$('#program').val();
	document.getElementById("courseofstudiesdetails").innerHTML='<center><p style="color:red;">Saving update, Please wait...</p></center><p>';
	$.post("../php/save_application_form.php",{program:program},
	function(response,status){ // Required Callback Function
		document.getElementById("courseofstudiesdetails").innerHTML=response;
	});
}

function biodata(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/profile.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function my_payments(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/my_payments.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
	
}



function get_profile_detail(){
	document.getElementById("profiledetail").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/get_profile_detail.php",
	function(response,status){ // Required Callback Function
		document.getElementById("profiledetail").innerHTML =response;
	});
}

function loan_application(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/loan_application.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
	
}


function load_add_load(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/load_add_load.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
	
}

function course_registration(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/course_registration_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function my_result(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/result_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function exam_card(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/exam_card_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function library_form(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/library_form_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}
function accommodation(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/accommodation_page.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function add_new_loan(){
	var loan_type=$('#loan_type').val();
	var amount_needed=$('#amount_needed').val();
	
	if(loan_type==""){
		alert("Please Select loan Type");
	}else if(amount_needed==""){
		alert("Please Select the  Amount you need");
	}else{
		//submit load
		document.getElementById("loan_error").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/add_new_loan.php",{loan_type:loan_type,amount_needed:amount_needed},
	function(response,status){ // Required Callback Function
	alert(response);
		document.getElementById("loan_error").innerHTML ="";
		loan_application();
	});
	}
	
}

function delete_loan(token){
	
	$.post("../php/delete_loan.php",{token:token},
	function(response,status){ // Required Callback Function
	alert(response);
		//document.getElementById("loan_error").innerHTML ="";
		loan_application();
	});
	}
	


function update_student_profile(user_type){
		if(user_type=="1"){
			var first_name=$('#first_name').val();
		var other_name=$('#other_name').val();
		var email=$('#email').val();
		var phone_no=$('#phone_no').val();
		var maritalstatus=$('#maritalstatus').val();
		var gender=$('#gender').val();
		var dob=$('#dob').val();
		var address=$('#address').val();
		var name_of_guardian=$('#name_of_guardian').val();
		var address_gaurdian=$('#address_gaurdian').val();
		var medication=$('#medication').val();
		var H_status=$('#H_status').val();
		var disability=$('#disability').val();
		var blood_type=$('#blood_type').val();
		var no_guardian=$('#no_guardian').val();
		var level=$('#level').val();
		var program=$('#program').val();
		var permenat_address=$('#permenat_address').val();
		var kin_name=$('#kin_name').val();
		var kin_relationship=$('#kin_relationship').val();
		var kin_phone_number=$('#kin_phone_number').val();
		var kin_address=$('#kin_address').val();
		
	
		
	document.getElementById("profile_error").innerHTML='<center>Saving Profile, Please wait<br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/update_student_profile.php",{user_type:user_type,first_name:first_name,other_name:other_name,kin_name:kin_name,kin_relationship:kin_relationship,kin_phone_number:kin_phone_number,kin_address:kin_address,permenat_address:permenat_address,program:program,level:level,no_guardian:no_guardian,blood_type:blood_type,disability:disability,H_status:H_status,medication:medication,email:email,phone_no:phone_no,maritalstatus:maritalstatus,gender:gender,dob:dob,address:address,name_of_guardian:name_of_guardian,address_gaurdian:address_gaurdian},
	function(response,status){ // Required Callback Function
		document.getElementById("profile_error").innerHTML =response;
	});
		}else{
			var first_name=$('#first_name').val();
		var other_name=$('#other_name').val();
		var email=$('#email').val();
		var phone_no=$('#phone_no').val();
		var maritalstatus=$('#maritalstatus').val();
		var gender=$('#gender').val();
		var dob=$('#dob').val();
		var address=$('#address').val();
		var name_of_guardian=$('#name_of_guardian').val();
		var address_gaurdian=$('#address_gaurdian').val();
		var medication=$('#medication').val();
		var H_status=$('#H_status').val();
		var disability=$('#disability').val();
		var blood_type=$('#blood_type').val();
		var no_guardian=$('#no_guardian').val();
		var level=$('#level').val();
		var program=$('#program').val();
		var permenat_address=$('#permenat_address').val();
		var kin_name=$('#kin_name').val();
		var kin_relationship=$('#kin_relationship').val();
		var kin_phone_number=$('#kin_phone_number').val();
		var kin_address=$('#kin_address').val();
		var state=$('#state').val();
		var lga=$('#lga').val();
		var course=$('#course').val();
		var state=$('#state').val();
		
		var ref1=$('#ref1').val();
		var ref2=$('#ref2').val();
		var ref3=$('#ref3').val();
		
		
	document.getElementById("profile_error").innerHTML='<center>Saving Profile, Please wait<br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/update_student_profile.php",{ref1:ref1,ref2:ref2,ref3:ref3,state:state,user_type:user_type,course:course,first_name:first_name,other_name:other_name,lga:lga,kin_name:kin_name,kin_relationship:kin_relationship,kin_phone_number:kin_phone_number,kin_address:kin_address,permenat_address:permenat_address,program:program,level:level,no_guardian:no_guardian,blood_type:blood_type,disability:disability,H_status:H_status,medication:medication,email:email,phone_no:phone_no,maritalstatus:maritalstatus,gender:gender,dob:dob,address:address,name_of_guardian:name_of_guardian,address_gaurdian:address_gaurdian},
	function(response,status){ // Required Callback Function
		document.getElementById("profile_error").innerHTML =response;
	});
		}
		
}

//load lga
function load_lga(){

	var state = $('#state').val();
		
$.post("../php/load_lga.php",{state:state},
function(response,status){ // Required Callback Function
document.getElementById("lga").innerHTML = response;
});
		
	
	
}

function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
		
function addNewResult(){
	var exam_type   = $("#exam_type").val();
		var exam_year   = $("#exam_year").val();
		var exam_month  = $("#exam_month").val();
		var subject     = $("#subject_id").val();
		var sub_grade   = $("#sub_grade").val();
		var exam_number   = $("#exam_number").val();
		
			$.post('../php/upload_o_level_result.php',{exam_number:exam_number,exam_type:exam_type,exam_year:exam_year,exam_month:exam_month,subject:subject,sub_grade:sub_grade},
				function(response,error){
					result_uploaded_table();
					
					
			});
}
function result_uploaded_table(){
			$.post('../php/result_uploaded_table.php',
				function(response,error){
				
					$("#result_uploaded_table_wrap").html(response);
					
			});
	}
	
function remove_olevel(token){
	$.post('../php/remove_olevel.php',{token},
				function(response,error){
				alert(response);
					result_uploaded_table();
					
			});
}
		
function other_uploads(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/other_uploads.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}	

function remove_certificate(token){
	$.post('../php/remove_certificate.php',{token},
				function(response,error){
				alert(response);
					other_uploads();
					
			});
}


function saveUpdateQualification(token){
	var qualification = $("#qualification").val();
	var specify = $("#specify").val();
	var class_off_qualification = $("#class_off_qualification").val();
	var institution = $("#institution").val();
	var yearOfGraduation = $("#yearOfGraduation").val();
	
	document.getElementById("saveError").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/saveUpdateQualification.php",{token:token,qualification:qualification,specify:specify,class_off_qualification:class_off_qualification,institution:institution,yearOfGraduation:yearOfGraduation},
	function(response,status){ // Required Callback Function
		document.getElementById("saveError").innerHTML =response;
	});
}

function feepayment(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/FeePayment.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function siwesApplication(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/siwesApplication.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}

function submitAppication(){
	document.getElementById("errorSubmit").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	var organization = $("#organization").val();
	var startDate = $("#startDate").val();
	var endDate = $("#endDate").val();
	var description = $("#description").val();
	
		if(organization==""){
			document.getElementById("errorSubmit").innerHTML ='<b class="alert alert-danger" role="alert">Please Select Organization</b>';
		}else if(startDate==""){
			document.getElementById("errorSubmit").innerHTML ='<b class="alert alert-danger" role="alert">Please Select Start Date</b>';
		}else if(endDate==""){
			document.getElementById("errorSubmit").innerHTML ='<b class="alert alert-danger" role="alert">Please Select End Date</b>';
		}else if(description==""){
			document.getElementById("errorSubmit").innerHTML ='<b class="alert alert-danger" role="alert">Please Select End Date</b>';
		}
		else{
	$.post("../php/submitAppication.php",{organization:organization,startDate:startDate,endDate:endDate,description:description},
	function(response,status){ // Required Callback Function
		document.getElementById("errorSubmit").innerHTML =response;
	});

		}
}

function tunitinAppication(){
	document.getElementById("errorSubmit").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../php/turnitinsubmitAppication.php",
	function(response,status){ // Required Callback Function
		document.getElementById("errorSubmit").innerHTML =response;
	});
}

function changeAppication(){
	document.getElementById("errorSubmit").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	var organization = $("#organization").val();
	
		if(organization==""){
			document.getElementById("errorSubmit").innerHTML ='<b class="alert alert-danger" role="alert">Please Select Organization</b>';
		}
		else{
	$.post("../php/changeAppication.php",{organization:organization},
	function(response,status){ // Required Callback Function
		document.getElementById("errorSubmit").innerHTML =response;
	});

		}
}

function changeofsiwesplacement(){
	document.getElementById("load_reprt").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/changeofsiwesplacement.php",
	function(response,status){ // Required Callback Function
		document.getElementById("load_reprt").innerHTML =response;
	});
}




function load_Notification(){
	document.getElementById("content").innerHTML='<center><br/><img src="images/info_loader.gif"></center><p>';
	$.post("../pages/load_Notification.php",
	function(response,status){ // Required Callback Function
		document.getElementById("content").innerHTML =response;
	});
}