$(document).ready(function(){

		$(document).on('mouseenter','.layer_wrap',function(){
			var id = $(this).attr("id");
			var img = $("#img_"+id);
			var con = $("#con_"+id);
			$(img).animate({height: '80%',display:'block'});
			$(con).animate({height: '20%'});

			
		});
		$(document).on('mouseleave','.layer_wrap',function(){
			var id = $(this).attr("id");
			var img = $("#img_"+id);
			var con = $("#con_"+id);
			$(img).animate({height: '0%',display:'none'});
			$(con).animate({height: '100%'});

			
		});
 });
	