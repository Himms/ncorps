function firstregistercourse(course_id,semester_id,session_id,project_id){
	
	  $.post("../pages/add_delete_course.php",{course_id:course_id,semester_id:semester_id,session_id:session_id,project_id:project_id},
	function(response,status){ // Required Callback Function
		
		if(response==1){
			alert("Course Added Successfully");
			$('#r'+course_id).css("background-color","#CCC");
			$('#'+course_id).html('<i class="glyphicon glyphicon-remove"></i> Delete');
		}else{
			alert("Course Deleted Successfully");
			$('#r'+course_id).css("background-color","#FFF");
			$('#'+course_id).html('<i class="glyphicon glyphicon-add"></i> Add');
		}
	});
}


function registercourse(course_id,semester_id,session_id,project_id){
	
	  $.post("../pages/add_delete_course.php",{course_id:course_id,semester_id:semester_id,session_id:session_id,project_id:project_id},
	function(response,status){ // Required Callback Function
		
		if(response==1){
			alert("Course Added Successfully");
			$('#r'+course_id).css("background-color","#CCC");
			$('#'+course_id).html('<i class="glyphicon glyphicon-remove"></i> Delete');
		}else{
			alert("Course Deleted Successfully");
			$('#r'+course_id).css("background-color","#FFF");
			$('#'+course_id).html('<i class="glyphicon glyphicon-add"></i> Add');
		}
	});
}