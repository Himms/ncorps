function generate_TID(){
	document.getElementById("error").innerHTML='<br/><center><p style="color:blue"><img src="../images/icons/info_loader.gif"></center><p>';
    var mat=$('#mat').val();
    var email=$('#email').val();
	var phone_number=$('#phone_number').val();
    var tid_type=$('#tid_type').val();
	var surname=$('#surname').val();
    var othernames=$('#othernames').val();
	

	$.post('../php/generate_TID.php',{mat:mat,email:email,phone_number:phone_number,tid_type:tid_type,surname:surname,othernames:othernames},
         function(response,status)
         {
			 document.getElementById("registration_content").innerHTML=response;   
         });
		 
}